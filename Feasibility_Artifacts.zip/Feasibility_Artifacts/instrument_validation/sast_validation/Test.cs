using System.Security.Cryptography;
public class InsecureHash { public byte[] Hash(byte[] input) { return MD5.HashData(input); } }
