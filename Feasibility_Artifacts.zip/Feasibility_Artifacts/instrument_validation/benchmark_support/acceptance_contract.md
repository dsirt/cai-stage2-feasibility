# Controlled ERP benchmark: task and fixture contract

These tasks use a purpose-built .NET 8 ERP fixture and generated synthetic records. They are controlled repository exercises; they contain no participant data and do not constitute a human study. The three task prompts are candidate-facing. This contract is for fixture construction and evaluation. Freeze the baseline, prompts, and checks before generating or assessing any candidate patches.

## Shared rules

- Use only the .NET 8 SDK/runtime and repository-local projects. No package restore beyond the SDK-provided framework is needed.
- Start every candidate from the same baseline revision. The baseline public tests must pass; tests for capabilities explicitly requested by a task may fail on the unchanged baseline.
- Treat the baseline service signatures, documented business validations, exception types, and transaction behavior as authoritative. Do not silently invent extra validations or alter errors to simplify an implementation.
- Use injected actor and UTC clock values for deterministic audit assertions. Compare decimal values exactly; do not use binary floating-point money.
- Distinguish invalid input, unavailable resources, cancellation, business rejection, and infrastructure failure according to the baseline API.
- A cancellation observed before any commit leaves business state unchanged. If cancellation occurs after a commit, the caller must be able to identify that the business change committed; do not report an unqualified rollback or hide the audit disposition.
- Candidate-facing prompts contain requirements, not seeded-defect descriptions, hidden test details, score thresholds, or expected experimental outcomes.

## T1 acceptance requirements

1. `PurchaseOrderService` has no direct dependency on `IDatabaseSession` or an infrastructure implementation. The application project has no reference to the infrastructure project or infrastructure namespace.
2. Purchase-order repository and unit-of-work contracts are owned by application/domain code. Infrastructure implements those contracts, and the composition root wires them.
3. Each previously transactional service operation retains its original commit boundary. All writes in that operation participate in the same unit of work; partial changes must not survive a pre-commit failure.
4. Existing success, not-found, validation, cancellation, and persistence-failure behavior is preserved. Read-only operations must not add writes or commits.
5. The service public API remains source-compatible. The refactored program builds and its existing public tests pass.

## T2 acceptance requirements

1. Every committed business update is associated with one stable audit event identity. The event contains the old state, new state, actor, and a UTC timestamp captured for that change.
2. Audit records and their nested state cannot be mutated through caller-owned objects or returned collections. Mutating an order later cannot alter a queued or delivered event.
3. Queue submission occurs after the business update commits. The audit submission does not execute inside or extend the committed business transaction.
4. The operation awaits queue acceptance or its failure. It does not use unobserved tasks, discarded tasks, or fire-and-forget submission for the required outcome.
5. Business success and audit success are distinguishable. An enqueue or delivery exception does not roll back or repeat the committed business update. A retryable failure preserves the event and exposes `PendingRetry`, the event identity, and failure information to the caller or an explicitly queryable status API.
6. Snapshot/restore includes accepted pending events and failed events awaiting retry. Restoring a fresh queue instance and processing it produces the same original event identities and payloads. A snapshot is a deep independent value.
7. Retrying a pending event preserves its old/new values, actor, and timestamp; it does not execute the business update again. Repeated retry/delivery of one event identity cannot create multiple delivered records.
8. Invalid, rejected, pre-commit failed, or pre-commit cancelled business updates produce no audit event claiming a successful business change.
9. Cancellation after commit cannot make the committed update or its audit status disappear. The implementation must report the committed result and expose pending audit work if delivery is incomplete.
10. “Durable” in this fixture means retention in the supplied process-local store and complete snapshot/restore. It does not claim persistence through an operating-system crash, machine loss, or an unsaved process restart.

## T3 acceptance requirements

1. For any completed execution, final available quantity equals initial available quantity minus the sum of quantities belonging to successful reservations. Rejected, invalid, cancelled-before-commit, and failed-before-commit requests subtract nothing.
2. No committed state has a negative available quantity. A successful request decrements stock once and yields one successful reservation result.
3. Two overlapping operations cannot both commit changes based on the same obsolete stock state. Correctness must hold across separate service instances sharing one session/store.
4. `AfterReadAsync` remains usable as the existing deterministic test hook. The implementation must not depend on test-specific timing, record identities, request quantities, or a fixed number of callers.
5. The implementation respects cancellation while waiting or retrying and terminates ordinary finite contention scenarios. Invalid requests retain the baseline rejection behavior and do not change stock.
6. Sequential success, insufficient-stock behavior, missing-item behavior, validation, and the public method signature remain compatible with the baseline.

## Fixture choices

The companion JSON fixes synthetic identifiers and representative normal-operation data. It deliberately defines semantic roles rather than new C# signatures, so the fixture author can bind the data to the baseline API. Inventory revision starts at zero only if the baseline represents revisions; the semantic requirement is stale-state protection, not a mandatory field or algorithm. The hidden concurrent test implementation belongs to the evaluator and is not embedded in these task files.
