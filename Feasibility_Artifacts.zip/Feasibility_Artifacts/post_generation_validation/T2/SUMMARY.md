# T2 retrospective validation results

All 8 frozen T2 heads built and passed the same nine evaluator-authored cases, giving 72/72 passing candidate-case observations. There were no behavioral failures, unsupported APIs, or non-evaluable candidate cases in the corrected campaign. The unchanged baseline built, but its requested asynchronous queue API was absent, giving nine separately labelled unsupported_api observations.

This is retrospective and unblinded AI-authored validation. It does not establish exhaustive task correctness, independent human adjudication, branch coverage, or mutation adequacy. The checks cover exact event payloads, post-commit awaited acceptance, retry preservation, accepted/failed snapshot restoration and isolation, rejection, pre/postcommit cancellation, and the absence of a duplicate stored event after the tested acknowledgement-loss and retry sequence. See CASE_DEFINITIONS.md for exact scope.

A first full campaign exposed a harness-constructor ambiguity for T2R03. The two affected results were retained, diagnosed as evaluator binding failures, and followed by a newly frozen corrected campaign on all heads. ADAPTER_CORRECTION.md records concrete source evidence and hashes. No candidate source was repaired or changed.

Final harness SHA-256: 46913f297aac05470b830a0406d3749eb0e72b2bdfde242c147d233f05d605ca

Frozen UTC: 2026-09-21T21:06:39.550619+00:00

| Head | Passed | Failed | Unsupported | Not evaluable |
| --- | ---: | ---: | ---: | ---: |
| baseline | 0 | 0 | 9 | 0 |
| T2R01 | 9 | 0 | 0 | 0 |
| T2R02 | 9 | 0 | 0 | 0 |
| T2R03 | 9 | 0 | 0 | 0 |
| T2R04 | 9 | 0 | 0 | 0 |
| T2R05 | 9 | 0 | 0 | 0 |
| T2R06 | 9 | 0 | 0 | 0 |
| T2R07 | 9 | 0 | 0 | 0 |
| T2R08 | 9 | 0 | 0 | 0 |

For T2.09, the harness checks final stored-event and business-commit counts after an acknowledgement-loss fault and two retry calls. It does not assert retry outcomes or count sink attempts. This result is not evidence of successful acknowledgement recovery or general idempotency. The frozen source and recorded results remain unchanged.
