# Constructor binding correction

The retained T2R03 source at commit recorded in heads.json exposes these two public constructors in source order:

```csharp
public SalesOrderService(IDatabaseSession session, IAuditSink auditSink, IClock clock)
public SalesOrderService(IDatabaseSession session, IAuditQueue auditQueue, IClock clock)
```

Both have three parameters. The initial evaluator selected the first constructor after sorting by parameter count alone. It therefore created a fresh internal queue through the sink overload and did not pass the evaluator's queue interceptor. The enqueue barrier was never reached in T2.02, which timed out, and the injected enqueue outage was never exercised in T2.03, which observed Delivered. Neither result established a failure in the candidate's queue handling.

The shared corrected adapter first prefers constructors with a parameter named IAuditQueue by type and then chooses maximal parameter count. This same rule is applied to every head. Semantic assertions, business state, failure injection, timeouts, and candidate source were unchanged. The complete initial campaign is retained under attempt3, followed by the newly frozen attempt4 campaign.

Initial harness SHA-256: 29497c73e9d5b73af3524ebc1b620663ec1b12e06b9a5ec7b77b3d9c167ee9e1

Corrected harness SHA-256: 46913f297aac05470b830a0406d3749eb0e72b2bdfde242c147d233f05d605ca

The initial source is attempt3/harness_source.cs. The corrected source is harness/Program.cs. Both versions' freezes and command/result logs are retained.
