# T2 post-generation validation

Read CASE_DEFINITIONS.md before interpreting the results. This is retrospective AI-authored semantic validation, without human adjudication or preregistration. Original candidate commits were not repaired or altered.

Authoritative campaign files are under attempt4. The campaign's harness_freeze.json records source hashes and its UTC freeze time. Its logs/<head>/execution.json records full commands, commit identity, timestamps, return codes, and per-case outcomes. Per-command stdout and stderr logs are retained. results.json aggregates the same nine cases for eight heads plus the separately labelled baseline.

Bindings are source adapters only. They do not modify candidate semantics. See bindings/*.json and CASE_DEFINITIONS.md. Earlier unsuccessful infrastructure attempts and the complete attempt3 campaign are retained for audit. In attempt3, T2R03 had two evaluator-binding failures because equal-length constructors were not resolved by the injected queue interface. The corrected shared rule prefers IAuditQueue constructors for every head. No candidate was repaired. See attempt_history.md. The baseline lacks the requested queue API, which is reported as unsupported_api, not as an executed behavioral assertion.

## Replay

Use .NET SDK 8.0.425, git, and Python 3.12+. No external NuGet package is required. Clone the benchmark bundle provided in the main feasibility supplement, retaining its objects, then run:

```sh
git clone /path/to/benchmark.bundle /tmp/t2-retained-repo
python run_validation.py --repo /tmp/t2-retained-repo --dotnet /path/to/dotnet --output /tmp/t2-new-validation
```

The output directory must be new. The runner reconstructs the exact nine commit hashes in heads.json through git archive, compiles an external harness referencing copied Domain/Application/Infrastructure projects, and records each run. It uses one MSBuild worker and disables the compiler server. Build and execution timings are provenance only and must not be mixed with the original Stage 2 timing study.

Candidate source copies, bin, and obj directories are disposable replay products and are excluded from the deliverable. Retained head sources are reconstructible from the original bundle and heads.json. All source, bindings, source freezes, commands, and result logs needed to reproduce the validation are included.

## Scope of the acknowledgement-loss check

T2.09 records no duplicate stored event after the tested acknowledgement-loss and retry sequence. Its assertions concern the final stored-event and business-commit counts. It does not assert the retry outcomes or count sink attempts, so it does not prove successful acknowledgement recovery or general idempotency. This is a reporting clarification only. The frozen harness, source hashes, and results are unchanged.
