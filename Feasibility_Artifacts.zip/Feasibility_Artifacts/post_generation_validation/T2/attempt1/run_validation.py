import datetime,hashlib,io,json,pathlib,subprocess,tarfile,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
DOTNET=ROOT/'dotnet/dotnet'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bindings={
'T2R01':dict(Queue='InMemoryAuditQueue',Storage=None,SnapshotTarget='queue',Snapshot='SnapshotAsync',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False),
'T2R02':dict(Queue='InMemoryAuditQueue',Storage=None,SnapshotTarget='queue',Snapshot='SnapshotAsync',Deliver='DeliverAsync',RetryArgument='outcome',EnqueueIncludesDelivery=False),
'T2R03':dict(Queue='InMemoryAuditQueue',Storage=None,SnapshotTarget='queue',Snapshot='SnapshotAsync',Deliver='RetryAsync',RetryArgument='event',EnqueueIncludesDelivery=True),
'T2R04':dict(Queue='AuditQueue',Storage='AuditQueueStorage',SnapshotTarget='Storage',Snapshot='SnapshotAsync',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False),
'T2R05':dict(Queue='AwaitableAuditQueue',Storage=None,SnapshotTarget='queue',Snapshot='SnapshotAsync',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False),
'T2R06':dict(Queue='AuditQueue',Storage=None,SnapshotTarget='queue',Snapshot='Snapshot',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False),
'T2R07':dict(Queue='InMemoryAuditQueue',Storage='InMemoryAuditQueueStorage',SnapshotTarget='Storage',Snapshot='Snapshot',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False),
'T2R08':dict(Queue='AwaitableAuditQueue',Storage='InMemoryAuditQueueStorage',SnapshotTarget='queue',Snapshot='SnapshotAsync',Deliver='DeliverAsync',RetryArgument='event',EnqueueIncludesDelivery=False)}
bindings['baseline']=bindings['T2R01']|{'expected_missing_queue_feature':True}
for head,binding in bindings.items():
    p=OUT/'bindings'/f'{head}.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(binding,indent=2))
sources=[OUT/'harness/Program.cs',pathlib.Path(__file__).resolve(),*sorted((OUT/'bindings').glob('*.json'))]
freeze={'frozen_utc':utc(),'design':'retrospective post-generation evaluator-authored AI-assisted behavioral checks','limitations':['Not preregistered or hidden during candidate generation.','Evaluator inspected source and candidate tests to bind public APIs.','Bindings only select API names, constructors, snapshot mechanisms, and retry argument.','Not independent human adjudication, coverage, mutation analysis, or exhaustive task acceptance.','Frozen candidate worktrees remain unchanged.'],'files':{str(p.relative_to(OUT)):sha(p) for p in sources}}
freeze_path=OUT/'harness_freeze.json'
if freeze_path.exists():raise SystemExit('Refusing to overwrite freeze or existing evaluation')
freeze_path.write_text(json.dumps(freeze,indent=2))
all_results=[]
for head in ['baseline']+sorted(k for k in bindings if k!='baseline'):
    src=ROOT/('benchmark' if head=='baseline' else 'agent_runs/'+head)
    commit=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()
    copy=OUT/'candidate_copies'/head;copy.mkdir(parents=True)
    archive=subprocess.check_output(['git','-C',str(src),'archive','HEAD'])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tf:tf.extractall(copy)
    harness=copy/'external_harness';harness.mkdir()
    (harness/'Program.cs').write_bytes((OUT/'harness/Program.cs').read_bytes())
    (harness/'ExternalChecks.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup><ItemGroup><ProjectReference Include="../src/Infrastructure/Benchmark.Infrastructure.csproj" /></ItemGroup></Project>')
    logdir=OUT/'logs'/head;logdir.mkdir(parents=True)
    records=[]
    commands=[('build',[str(DOTNET),'build',str(harness/'ExternalChecks.csproj'),'-c','Release','--nologo','-p:UseSharedCompilation=false']),('run',[str(DOTNET),str(harness/'bin/Release/net8.0/ExternalChecks.dll'),head,str(OUT/'bindings'/f'{head}.json')])]
    for phase,cmd in commands:
        start=utc();t=time.perf_counter();r=subprocess.run(cmd,cwd=copy,text=True,capture_output=True,timeout=180)
        (logdir/f'{phase}.stdout.log').write_text(r.stdout);(logdir/f'{phase}.stderr.log').write_text(r.stderr)
        records.append({'phase':phase,'command':cmd,'cwd':str(copy),'started_utc':start,'ended_utc':utc(),'wall_seconds':time.perf_counter()-t,'returncode':r.returncode})
        if r.returncode:break
    result={'head':head,'commit':commit,'commands':records}
    if len(records)==2 and records[-1]['returncode']==0:
        result|=json.loads((logdir/'run.stdout.log').read_text())
    (logdir/'execution.json').write_text(json.dumps(result,indent=2));all_results.append(result)
    print(head,[(x['phase'],x['returncode']) for x in records],{s:sum(c['status']==s for c in result.get('checks',[])) for s in ['pass','fail']},flush=True)
(OUT/'results.json').write_text(json.dumps({'freeze':freeze,'completed_utc':utc(),'results':all_results},indent=2))
