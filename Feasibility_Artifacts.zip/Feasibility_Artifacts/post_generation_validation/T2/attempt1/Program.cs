using System.Collections;
using System.Reflection;
using System.Text.Json;
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;

public static class Program
{
    static readonly DateTimeOffset Stamp = new(2026, 8, 19, 10, 11, 12, TimeSpan.Zero);
    static string Head = "";
    static Binding Bind = null!;
    static readonly List<object> Results = new();
    static Type AppType(string name) => typeof(SalesOrderService).Assembly.GetType("Benchmark.Application." + name, true)!;
    static object? Prop(object obj, string name) => obj.GetType().GetProperty(name)?.GetValue(obj);
    static object Audit(object result) => Prop(result, "Audit") ?? throw new Exception("Audit outcome unavailable");
    static AuditRecord Event(object outcome) => (AuditRecord)(Prop(outcome, "Event") ?? throw new Exception("Event missing"));
    static string State(object outcome) => (Prop(outcome, "Status") ?? Prop(outcome, "State"))?.ToString() ?? "missing";
    static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    static string Json(object value) => JsonSerializer.Serialize(value, value.GetType());
    static async Task<object?> Call(object target, string method, params object?[] supplied)
    {
        var m = target.GetType().GetMethods().Single(x => x.Name == method && x.GetParameters().Length >= supplied.Length);
        var args = m.GetParameters().Select((p,i) => i < supplied.Length ? supplied[i] : p.ParameterType == typeof(CancellationToken) ? CancellationToken.None : p.DefaultValue).ToArray();
        object? value;
        try { value = m.Invoke(target, args); }
        catch (TargetInvocationException error) { throw error.InnerException!; }
        if (value is Task task) { await task; return task.GetType().GetProperty("Result")?.GetValue(task); }
        return value;
    }
    static SalesOrder Original() => new() { Id = "external-T2", Code = "EXT-T2", Description = "original", Amount = 17.25m, Version = 1 };
    static object Queue(IAuditSink sink, object? snapshot = null)
    {
        var queueType = AppType(Bind.Queue);
        object? state = snapshot;
        if (Bind.Storage is not null)
        {
            var storageType = AppType(Bind.Storage);
            state = snapshot is null ? Activator.CreateInstance(storageType) : snapshot is string text
                ? storageType.GetMethod("Restore", BindingFlags.Public | BindingFlags.Static)!.Invoke(null, new object[]{text})
                : Activator.CreateInstance(storageType, snapshot);
        }
        return Activator.CreateInstance(queueType, sink, state)!;
    }
    static object Service(TrackingSession db, IAuditSink sink, object queue)
    {
        var ctor = typeof(SalesOrderService).GetConstructors().OrderByDescending(x => x.GetParameters().Length).First();
        return ctor.Invoke(ctor.GetParameters().Select(p => p.ParameterType.Name switch {
            "IDatabaseSession" => (object)db, "IAuditSink" => sink, "IAuditQueue" => queue, "IClock" => new Clock(), _ => throw new Exception("Unknown constructor binding") }).ToArray());
    }
    static async Task<object> Snapshot(object queue)
    {
        var target = Bind.SnapshotTarget == "Storage" ? Prop(queue,"Storage")! : queue;
        return (await Call(target,Bind.Snapshot))!;
    }
    static async Task<object> Retry(object service, object audit)
    {
        var argument = Bind.RetryArgument == "outcome" ? audit : Event(audit);
        return (await Call(service,"RetryAuditAsync",argument))!;
    }
    static Task<object?> Change(object service, CancellationToken token = default, decimal amount = 29.50m)
        => Call(service,"ChangeAmountWithAuditAsync",Original().Id,amount,"external-evaluator",1,token);
    static async Task<Fixture> Setup(Func<AuditRecord,CancellationToken,Task>? behavior = null)
    {
        var db = new TrackingSession(); await db.SaveAsync(Original());
        var sink = new RecordingSink(behavior); var queue = Queue(sink); return new(db,sink,queue,Service(db,sink,queue));
    }
    static void FailedOutcome(object audit)
    {
        Check(State(audit) != "Delivered", "Failure reported as delivered");
        Check(!string.IsNullOrWhiteSpace(Event(audit).Id), "Failure lost stable event identity");
        Check(!string.IsNullOrWhiteSpace(Prop(audit,"Error")?.ToString()), "Failure information not exposed");
    }
    static async Task Run(string name, Func<Task> action)
    {
        var started = DateTimeOffset.UtcNow;
        try { await action().WaitAsync(TimeSpan.FromSeconds(15)); Results.Add(new {head=Head, test=name, status="pass", started_utc=started, ended_utc=DateTimeOffset.UtcNow}); }
        catch(TypeLoadException e) { Results.Add(new {head=Head, test=name, status="unsupported_api", started_utc=started, ended_utc=DateTimeOffset.UtcNow,error=e.ToString()}); }
        catch(Exception e) { Results.Add(new {head=Head, test=name, status="fail", started_utc=started, ended_utc=DateTimeOffset.UtcNow,error=e.ToString()}); }
    }
    public static async Task Main(string[] args)
    {
        Head=args[0]; Bind=JsonSerializer.Deserialize<Binding>(File.ReadAllText(args[1]),new JsonSerializerOptions{PropertyNameCaseInsensitive=true})!;
        await Run("T2.01_event_payload_and_later_state_independence", async () => {
            var f=await Setup(); var result=(await Change(f.Service))!; var audit=Audit(result); var record=Event(audit);
            Check(record.Actor=="external-evaluator" && record.OccurredAt==Stamp,"Actor or UTC timestamp mismatch");
            Check(JsonSerializer.Deserialize<SalesOrder>(record.BeforeJson)==Original(),"Old state mismatch");
            var updated=await f.Db.FindAsync<SalesOrder>(Original().Id);
            Check(JsonSerializer.Deserialize<SalesOrder>(record.AfterJson)==updated,"New state mismatch");
            var saved=Json(record);
            await Call(f.Service,"UpdateDescriptionWithAuditAsync",Original().Id,"subsequent","later-actor",2,CancellationToken.None);
            Check(Json(record)==saved,"Later business mutation altered earlier event");
            Check(f.Sink.Records.Select(x=>x.Id).Distinct().Count()==2,"Distinct updates lack distinct identities");
        });
        await Run("T2.02_enqueue_is_postcommit_and_awaited", async () => {
            var f=await Setup(); var entered=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously); var release=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var proxy=InterceptQueue(f.Queue,async () => {
                Check(!f.Db.IsTransactionActive,"Enqueue began during transaction");
                Check((await f.Db.FindAsync<SalesOrder>(Original().Id))!.Version==2,"Enqueue began before visible commit");
                entered.SetResult(); await release.Task;
            });
            var service=Service(f.Db,f.Sink,proxy); var change=Change(service);
            await entered.Task.WaitAsync(TimeSpan.FromSeconds(3)); Check(!change.IsCompleted,"Operation did not await acceptance");
            release.SetResult(); await change; Check(f.Db.Commits==1,"Unexpected business commit count");
        });
        await Run("T2.03_enqueue_failure_preserves_commit_and_retry",async()=>{
            var f=await Setup(); bool fail=true;
            var proxy=InterceptQueue(f.Queue,()=>fail?Task.FromException(new InvalidOperationException("external enqueue outage")):Task.CompletedTask);
            var service=Service(f.Db,f.Sink,proxy); var audit=Audit((await Change(service))!); FailedOutcome(audit);
            Check((await f.Db.FindAsync<SalesOrder>(Original().Id))!.Amount==29.50m,"Enqueue failure rolled back committed state");
            var saved=Json(Event(audit)); fail=false; var retried=await Retry(service,audit); await Retry(service,audit);
            Check(State(retried)=="Delivered" && Json(Event(retried))==saved,"Retry altered event or failed to deliver");
            Check(f.Db.Commits==1 && f.Sink.Records.Count==1,"Retry repeated business change or delivery");
        });
        await Run("T2.04_delivery_failure_snapshot_restore_and_idempotency",async()=>{
            var f=await Setup((_,_)=>Task.FromException(new InvalidOperationException("external sink outage")));
            var audit=Audit((await Change(f.Service))!); FailedOutcome(audit); var originalEvent=Json(Event(audit));
            var snapshot=await Snapshot(f.Queue); var frozen=Json(snapshot); var healthy=new RecordingSink(); var restored=Queue(healthy,snapshot); var service=Service(f.Db,healthy,restored);
            var retry=await Retry(service,audit); await Retry(service,audit);
            Check(State(retry)=="Delivered" && healthy.Records.Count==1,"Restore/repeated retry failed or duplicated delivery");
            Check(Json(healthy.Records.Single())==originalEvent,"Restore altered original payload");
            Check(Json(snapshot)==frozen && Json(await Snapshot(f.Queue))==frozen,"Snapshot or original queue changed through restored queue");
            Check(f.Db.Commits==1 && (await f.Db.FindAsync<SalesOrder>(Original().Id))!.Version==2,"Restore repeated business write");
        });
        await Run("T2.05_rejected_and_precancelled_changes_have_no_event",async()=>{
            var f=await Setup(); bool invalid=false;
            try { await Change(f.Service,default,-1m); } catch(DomainValidationException) { invalid=true; }
            Check(invalid,"Invalid amount was not rejected");
            using var cts=new CancellationTokenSource(); cts.Cancel(); bool cancelled=false;
            try { await Change(f.Service,cts.Token); } catch(OperationCanceledException) { cancelled=true; }
            Check(cancelled,"Pre-cancelled operation did not preserve cancellation");
            Check((await f.Db.FindAsync<SalesOrder>(Original().Id))==Original(),"Rejected change modified order");
            Check(f.Sink.Records.Count==0 && !Json(await Snapshot(f.Queue)).Contains("external-T2"),"Rejected change created audit event");
        });
        await Run("T2.06_cancellation_immediately_before_commit_rolls_back",async()=>{
            var f=await Setup(); using var cts=new CancellationTokenSource(); f.Db.BeforeCommit=cts.Cancel; bool cancelled=false;
            try { await Change(f.Service,cts.Token); } catch(OperationCanceledException) {cancelled=true;}
            Check(cancelled && (await f.Db.FindAsync<SalesOrder>(Original().Id))==Original(),"Precommit cancellation did not roll back");
            Check(f.Sink.Records.Count==0 && !Json(await Snapshot(f.Queue)).Contains("external-T2"),"Precommit cancellation emitted successful event");
        });
        await Run("T2.07_postcommit_cancellation_exposes_retryable_event",async()=>{
            var f=await Setup(); using var cts=new CancellationTokenSource(); f.Db.AfterCommit=cts.Cancel;
            var result=(await Change(f.Service,cts.Token))!; var audit=Audit(result); FailedOutcome(audit);
            Check((await f.Db.FindAsync<SalesOrder>(Original().Id))!.Amount==29.50m,"Postcommit cancellation lost committed change");
            var retried=await Retry(f.Service,audit);
            Check(State(retried)=="Delivered" && f.Db.Commits==1 && f.Sink.Records.Count==1,"Postcancel retry failed or repeated commit");
        });
        await Run("T2.08_accepted_pending_snapshot_is_independent",async()=>{
            var entered=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously); var release=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var sink=new RecordingSink(async(_,_)=>{entered.TrySetResult();await release.Task;}); var queue=Queue(sink);
            var record=new AuditRecord("external-pending","SalesOrder",Original().Id,"Changed","external-evaluator",Stamp,1,2,Json(Original()),Json(Original() with {Version=2}));
            var enqueued=Call(queue,"EnqueueAsync",record,CancellationToken.None);
            if(Bind.EnqueueIncludesDelivery) await entered.Task.WaitAsync(TimeSpan.FromSeconds(3)); else await enqueued;
            var snapshot=await Snapshot(queue); var frozen=Json(snapshot); var healthy=new RecordingSink(); var restored=Queue(healthy,snapshot);
            await Call(restored,Bind.Deliver,record.Id,CancellationToken.None);
            Check(healthy.Records.Count==1 && healthy.Records[0]==record,"Pending restoration lost payload or identity");
            Check(Json(snapshot)==frozen && Json(await Snapshot(queue))==frozen,"Pending snapshot shares mutable queue state");
            release.SetResult(); await enqueued;
        });
        await Run("T2.09_ambiguous_delivery_uses_candidate_sink_deduplication",async()=>{
            var db=new TrackingSession();await db.SaveAsync(Original());var actualSink=new InMemoryAuditSink();bool first=true;
            var sink=new RecordingSink(async(record,token)=>{await actualSink.AppendAsync(record,token);if(first){first=false;throw new InvalidOperationException("external acknowledgement loss");}});
            var queue=Queue(sink);var service=Service(db,sink,queue);var audit=Audit((await Change(service))!);FailedOutcome(audit);
            await Retry(service,audit);await Retry(service,audit);
            Check((await actualSink.ReadAllAsync()).Count==1 && db.Commits==1,"Acknowledgement-loss retry duplicated event or commit");
        });
        Console.WriteLine(JsonSerializer.Serialize(new {head=Head,checks=Results},new JsonSerializerOptions{WriteIndented=true}));
    }
    static object InterceptQueue(object inner,Func<Task> before)
    {
        var proxy=DispatchProxy.Create(AppType("IAuditQueue"),typeof(QueueProxy));
        ((QueueProxy)proxy).Inner=inner;((QueueProxy)proxy).BeforeEnqueue=before;return proxy;
    }
    public record Binding(string Queue,string? Storage,string SnapshotTarget,string Snapshot,string Deliver,string RetryArgument,bool EnqueueIncludesDelivery);
    record Fixture(TrackingSession Db,RecordingSink Sink,object Queue,object Service);
    sealed class Clock:IClock {public DateTimeOffset UtcNow=>Stamp;}
    sealed class RecordingSink(Func<AuditRecord,CancellationToken,Task>? behavior=null):IAuditSink
    {
        public List<AuditRecord> Records {get;}=new();
        public async Task AppendAsync(AuditRecord record,CancellationToken cancellationToken=default){if(behavior is not null)await behavior(record,cancellationToken);Records.Add(record);}
        public Task<IReadOnlyList<AuditRecord>> ReadAllAsync(CancellationToken cancellationToken=default)=>Task.FromResult<IReadOnlyList<AuditRecord>>(Records.ToArray());
    }
    sealed class TrackingSession:IDatabaseSession
    {
        readonly InMemoryDatabaseSession inner=new();public bool IsTransactionActive {get;private set;}public int Commits{get;private set;}
        public Action? BeforeCommit{get;set;}public Action? AfterCommit{get;set;}
        public Task<T?> FindAsync<T>(string id,CancellationToken token=default)where T:BusinessDocument=>inner.FindAsync<T>(id,token);
        public Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken token=default)where T:BusinessDocument=>inner.ListAsync<T>(token);
        public Task SaveAsync<T>(T doc,CancellationToken token=default)where T:BusinessDocument=>inner.SaveAsync(doc,token);
        public Task DeleteAsync<T>(string id,CancellationToken token=default)where T:BusinessDocument=>inner.DeleteAsync<T>(id,token);
        public Task<bool> TryReplaceAsync<T>(T doc,int version,CancellationToken token=default)where T:BusinessDocument=>inner.TryReplaceAsync(doc,version,token);
        public async Task<T> InTransactionAsync<T>(Func<CancellationToken,Task<T>> action,CancellationToken token=default)
        {IsTransactionActive=true;T result;try{result=await inner.InTransactionAsync(async ct=>{var value=await action(ct);BeforeCommit?.Invoke();return value;},token);}finally{IsTransactionActive=false;}Commits++;AfterCommit?.Invoke();return result;}
    }
}
public class QueueProxy:DispatchProxy
{
    public object Inner=null!;public Func<Task> BeforeEnqueue=null!;
    protected override object? Invoke(MethodInfo? method,object?[]? args)
    {
        if(method!.Name!="EnqueueAsync")return method.Invoke(Inner,args);
        return typeof(QueueProxy).GetMethod(nameof(Intercept),BindingFlags.Instance|BindingFlags.NonPublic)!.MakeGenericMethod(method.ReturnType.GetGenericArguments()[0]).Invoke(this,new object?[]{method,args});
    }
    async Task<T> Intercept<T>(MethodInfo method,object?[]? args){await BeforeEnqueue();return await (Task<T>)method.Invoke(Inner,args)!;}
}
