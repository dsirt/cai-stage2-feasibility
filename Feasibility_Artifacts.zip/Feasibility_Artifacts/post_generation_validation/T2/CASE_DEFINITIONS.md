# Retrospective T2 semantic checks

These checks were written after the eight original T2 heads were frozen. The evaluator is an AI coding agent and inspected implementation and candidate test source while creating API bindings. This is a separate evaluator-authored harness, not a blinded or independent human assessment. It supplies bounded behavioral evidence and is not a complete task-acceptance oracle.

The common Program.cs defines the same nine assertions for each head. Binding JSON files only identify queue and storage constructors, snapshot methods, the delivery/retry method, and whether retry takes the original event or its outcome. T2R03 combines acceptance and delivery in EnqueueAsync, so its pending snapshot case blocks the sink while observing accepted state. Other heads separate acceptance and delivery. Assertions and pass criteria are unchanged across heads.

| Case | Assertion and contract basis |
| --- | --- |
| T2.01 | A committed amount change carries exact old/new state, injected actor and UTC timestamp. A subsequent description change does not mutate the first event. Distinct committed changes have distinct event identities. |
| T2.02 | An injected queue barrier observes an already committed order outside the transaction. The service call remains incomplete until queue acceptance is released. |
| T2.03 | An injected enqueue exception exposes event identity and error, leaves the committed order intact, and permits retry of the same event without another business commit or duplicate delivery. |
| T2.04 | A sink exception exposes retryable work. Restoring its snapshot into a fresh queue delivers the original event once. Repeated retry does not repeat the business write. The snapshot and original queue remain unchanged when the restored queue progresses. |
| T2.05 | A negative amount and an already-cancelled token leave business state unchanged and produce no queued or delivered successful-change event. |
| T2.06 | Cancellation injected immediately before transaction commit rolls back the update and produces no successful-change event. |
| T2.07 | Cancellation injected immediately after commit still returns an identifiable audit outcome with error and event identity. Retrying this event succeeds without repeating the business commit. |
| T2.08 | An accepted pending event can be restored and delivered with its original identity and payload. Progressing the restored queue does not mutate the saved snapshot or original queue. |
| T2.09 | The candidate's actual InMemoryAuditSink stores one event, and business storage records one commit, after the tested acknowledgement-loss fault and two subsequent retry calls. This case checks that no duplicate stored event appears in that sequence. |

A pass only covers the stated scenario. A fail records an executed assertion failure or timeout. An unsupported_api result records a missing required queue type before a scenario can execute. A failed build is not_evaluable, not a behavioral failure. The unchanged baseline lacks the requested asynchronous queue API, so its unsupported_api results are expected and are not evidence of nine separately executed defects.

There are nine cases per candidate, giving 72 candidate-case observations across eight retained heads. Baseline observations are separate. No branch-coverage, mutation-adequacy, human false-alarm, or missed-defect rates are inferred. Retryable statuses with API-specific names are treated semantically, without requiring the literal enum spelling PendingRetry.

The tests cover amount and description updates and synthetic failure/cancellation conditions. They do not exhaust every create/submit path, every possible race, operating-system crash persistence, malformed snapshots, arbitrary external sinks, or unbounded contention. The in-memory snapshot contract does not imply disk durability.

T2.09 does not assert the outcomes returned by the two retry calls or count sink append attempts. Its passing result therefore does not establish successful acknowledgement recovery or general idempotency. It establishes only that the stored-event count remains one and the business-commit count remains one after the tested sequence. This reporting clarification does not change the frozen harness or any recorded result.
