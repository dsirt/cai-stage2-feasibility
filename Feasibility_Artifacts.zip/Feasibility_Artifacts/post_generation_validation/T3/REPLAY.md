# Portable replay of the retained T3 checks

`replay.py` is an additive preparation wrapper. It does not replace or alter the originally frozen `run_validation.py`, harness, specification, or results. It reconstructs the baseline and eight T3 commits from the supplied Git bundle, rewrites only the local input paths into a new manifest, verifies the evaluator hashes against `freeze.json`, checks the pinned SDK, and invokes the original runner in a fresh output directory.

Requirements are Python 3.12, Git, an installed .NET host with SDK 8.0.425, and a Linux filesystem supporting symbolic links. No network package download is required for these package-free projects. The SDK is not included in the artifact archive. The original runner uses the SDK directory through a local symbolic link, so `--dotnet` must point to an installed host whose resolved parent contains its SDK and runtime directories.

From the extracted artifact root, use the location where this T3 directory is packaged:

```sh
python3 post_generation_validation/T3/replay.py \
  --bundle benchmark.bundle \
  --manifest records/experiment_manifest.json \
  --dotnet /absolute/path/to/dotnet \
  --output /absolute/path/to/new-t3-replay
```

Add `--prepare-only` to construct the nine clean input snapshots and verify the evaluator and SDK without running tests. This writes `preparation.json`, including the exact runner command. Running that recorded command later executes the frozen evaluator against the prepared inputs. The wrapper refuses an existing output path and never overwrites earlier evidence.

Outputs are written under `validation/`. They include a new replay freeze timestamp, all per-case JSON and CSV results, source commit identities, build and execution logs, exact commands, and integrity verification. A replay timestamp documents the new replay and does not replace the original freeze. Paths and source-manifest hashes naturally differ after relocation. The original manifest hash and original freeze hash remain recorded in `preparation.json`.

The ten common task checks and two conditional-update probes retain their original definitions. A conditional probe that does not exercise that port is `not_exercised`, not a task failure. Baseline conservation failures are expected negative-control outcomes. The wrapper's exit code indicates whether the runner completed, so read the result JSON for individual check outcomes.

This reproduces selected retrospective behavioral checks on retained changes. It does not regenerate agent changes, provide human adjudication, measure branch coverage or mutation score, or rerun the original Stage 2 latency experiment. Timing fields in these replay logs describe only this replay and should not be pooled with the original gate timing data.

Timeout-recording clarification: A per-case timeout is recorded as fail with TimeoutException in Error. A runner-level timeout is recorded as process_timeout. No timeouts occurred in the reported campaign.
