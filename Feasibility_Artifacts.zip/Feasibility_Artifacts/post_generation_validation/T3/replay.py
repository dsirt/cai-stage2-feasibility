#!/usr/bin/env python3
"""Portable preparation wrapper for the unchanged retrospective T3 runner."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def call(args, cwd=None, env=None):
    completed = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True)
    if completed.returncode:
        raise RuntimeError(f"Command failed: {args!r}\n{completed.stdout}\n{completed.stderr}")
    return completed.stdout.strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', required=True, type=Path, help='Retained benchmark.bundle containing baseline and T3 commits')
    parser.add_argument('--manifest', required=True, type=Path, help='Original experiment_manifest.json')
    parser.add_argument('--dotnet', required=True, type=Path, help='Installed .NET host executable with SDK 8.0.425')
    parser.add_argument('--output', required=True, type=Path, help='New output directory that does not already exist')
    parser.add_argument('--prepare-only', action='store_true', help='Reconstruct inputs, verify hashes and SDK, and print the runner command without executing tests')
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    bundle, manifest_path, sdk, output = [p.resolve() for p in (args.bundle, args.manifest, args.dotnet, args.output)]
    for path in (bundle, manifest_path, sdk):
        if not path.is_file():
            parser.error(f'Input file does not exist: {path}')
    if output.exists():
        parser.error(f'Output already exists. Preserve existing evidence and choose a new directory: {output}')
    if not os.access(sdk, os.X_OK):
        parser.error(f'.NET host is not executable: {sdk}')
    if shutil.which('git') is None:
        parser.error('Git must be installed and available on PATH.')
    frozen = json.loads((here / 'freeze.json').read_text())
    for name, expected in frozen['files_sha256'].items():
        if sha(here / name) != expected:
            parser.error(f'Original frozen evaluator file does not match its recorded hash: {name}')
    source_manifest = json.loads(manifest_path.read_text())
    changes = sorted((c for c in source_manifest['changes'] if c['task_id'] == 'T3'), key=lambda c: c['change_id'])
    if len(changes) != 8 or len({c['change_id'] for c in changes}) != 8:
        parser.error('Expected exactly eight unique T3 changes in the original manifest.')
    baselines = {c['parent_commit'] for c in changes}
    if len(baselines) != 1:
        parser.error('Expected a single shared baseline commit.')
    retained = {r['run_id']: r['commit'] for r in frozen['baseline_and_heads']}
    if retained.get('BASELINE') != changes[0]['parent_commit'] or any(retained.get(c['change_id']) != c['head_commit'] for c in changes):
        parser.error('Manifest commit identities differ from the retained T3 validation freeze.')

    output.mkdir(parents=True)
    work = output / 'work'
    work.mkdir()
    repo = work / 'repository.git'
    call(['git', 'clone', '--bare', str(bundle), str(repo)])
    bundle_verification = call(['git', '-C', str(repo), 'bundle', 'verify', str(bundle)])
    baseline = work / 'benchmark'
    call(['git', '-C', str(repo), 'worktree', 'add', '--detach', str(baseline), changes[0]['parent_commit']])
    reconstructed = []
    for change in changes:
        head = work / 'agent_runs' / change['change_id']
        head.parent.mkdir(parents=True, exist_ok=True)
        call(['git', '-C', str(repo), 'worktree', 'add', '--detach', str(head), change['head_commit']])
        reconstructed.append({
            'change_id': change['change_id'], 'task_id': 'T3',
            'parent_commit': change['parent_commit'], 'head_commit': change['head_commit'],
            'parent_path': str(baseline), 'head_path': str(head),
        })
    relocated_manifest = {
        'repository_id': source_manifest.get('repository_id'),
        'changes': reconstructed,
        'replay_note': 'T3 subset with local paths reconstructed from immutable bundle commits. Source manifest SHA-256 is recorded in preparation.json.',
    }
    (work / 'experiment_manifest.json').write_text(json.dumps(relocated_manifest, indent=2) + '\n')
    (work / 'dotnet').symlink_to(sdk.parent, target_is_directory=True)
    env = os.environ.copy()
    env['DOTNET_ROOT'] = str(sdk.parent)
    env['DOTNET_CLI_TELEMETRY_OPTOUT'] = '1'
    version = call([str(sdk), '--version'], cwd=baseline, env=env)
    if version != '8.0.425':
        raise RuntimeError(f'Pinned SDK 8.0.425 is required. Observed SDK: {version}')
    checked = {}
    for name, path, expected in [('BASELINE', baseline, changes[0]['parent_commit'])] + [(c['change_id'], Path(c['head_path']), c['head_commit']) for c in reconstructed]:
        observed = call(['git', '-C', str(path), 'rev-parse', 'HEAD'])
        status = call(['git', '-C', str(path), 'status', '--porcelain', '--untracked-files=no'])
        if observed != expected or status:
            raise RuntimeError(f'Reconstructed snapshot verification failed for {name}.')
        checked[name] = observed
    runner = [sys.executable, str(here / 'run_validation.py'), '--work-root', str(work), '--output-root', str(output / 'validation')]
    preparation = {
        'prepared_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'mode': 'prepare_only' if args.prepare_only else 'execute',
        'bundle_sha256': sha(bundle), 'source_manifest_sha256': sha(manifest_path),
        'original_freeze_sha256': sha(here / 'freeze.json'),
        'wrapper_sha256': sha(Path(__file__).resolve()),
        'sdk_version': version, 'verified_clean_heads': checked,
        'frozen_evaluator_hashes_verified': True,
        'bundle_verification_stdout': bundle_verification,
        'runner_command': runner,
        'classification': 'replay of retained retrospective external T3 checks, not a new agent-generation experiment',
    }
    (output / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
    print(json.dumps(preparation, indent=2), flush=True)
    if args.prepare_only:
        return 0
    completed = subprocess.run(runner, env=env)
    return completed.returncode


if __name__ == '__main__':
    raise SystemExit(main())
