#!/usr/bin/env python3
"""Retrospective task-specific checks. Never edits the original experiment."""
import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def command(args, cwd=None):
    return subprocess.check_output(args, cwd=cwd, text=True).strip()


def tracked_fingerprint(path):
    files = subprocess.check_output(['git', '-C', str(path), 'ls-files', '-z']).decode().split('\0')
    return {name: sha(path / name) for name in files if name}


def main():
    parser = argparse.ArgumentParser()
    here = Path(__file__).resolve().parent
    parser.add_argument('--work-root', type=Path, default=here.parents[1])
    parser.add_argument('--output-root', type=Path, default=here)
    args = parser.parse_args()
    work, out = args.work_root.resolve(), args.output_root.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'results.json').exists() or (out / 'freeze.json').exists():
        raise SystemExit('Existing freeze or results found. Preserve them and use a fresh --output-root.')
    manifest = json.loads((work / 'experiment_manifest.json').read_text())
    changes = sorted((c for c in manifest['changes'] if c['task_id'] == 'T3'), key=lambda c: c['change_id'])
    rows = [dict(run_id='BASELINE', path=Path(changes[0]['parent_path']), commit=changes[0]['parent_commit'])]
    rows += [dict(run_id=c['change_id'], path=Path(c['head_path']), commit=c['head_commit']) for c in changes]
    before = {}
    for row in rows:
        row['path'] = row['path'].resolve()
        current = command(['git', '-C', str(row['path']), 'rev-parse', 'HEAD'])
        if current != row['commit']:
            raise RuntimeError(f"Unexpected original HEAD for {row['run_id']}")
        status = command(['git', '-C', str(row['path']), 'status', '--porcelain', '--untracked-files=no'])
        if status:
            raise RuntimeError(f"Original tracked changes for {row['run_id']}: {status}")
        before[row['run_id']] = {'head': current, 'tracked_sha256': tracked_fingerprint(row['path'])}
    if out != here:
        shutil.copytree(here / 'harness', out / 'harness')
        shutil.copy2(here / 'README.md', out / 'README.md')
        shutil.copy2(__file__, out / 'run_validation.py')
    for name in ['global.json', 'NuGet.Config']:
        shutil.copy2(work / 'benchmark' / name, out / name)
    frozen_names = ['harness/Program.cs', 'harness/T3Validation.csproj', 'README.md', 'run_validation.py', 'global.json', 'NuGet.Config']
    freeze = {
        'frozen_at_utc': utc(),
        'classification': 'retrospective external behavioral validation, after candidate generation and original gate timing',
        'files_sha256': {name: sha(out / name) for name in frozen_names},
        'baseline_and_heads': [{k: str(v) for k, v in row.items()} for row in rows],
        'manifest_sha256': sha(work / 'experiment_manifest.json'),
        'case_count': 12,
        'common_task_cases': 10,
        'conditional_api_probes': 2,
    }
    (out / 'freeze.json').write_text(json.dumps(freeze, indent=2) + '\n')
    (out / 'original_inputs_before.json').write_text(json.dumps(before, indent=2) + '\n')
    sdk = str(work / 'dotnet' / 'dotnet')
    env = os.environ.copy()
    env['DOTNET_ROOT'] = str(work / 'dotnet')
    env['DOTNET_CLI_TELEMETRY_OPTOUT'] = '1'
    env['DOTNET_NOLOGO'] = '1'
    results = []
    for row in rows:
        run = out / 'runs' / row['run_id']
        snapshot = run / 'snapshot'
        snapshot.mkdir(parents=True)
        archive = subprocess.check_output(['git', '-C', str(row['path']), 'archive', row['commit']])
        with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
            tar.extractall(snapshot, filter='data')
        shutil.copytree(out / 'harness', run / 'harness')
        shutil.copy2(out / 'global.json', run / 'global.json')
        shutil.copy2(out / 'NuGet.Config', run / 'NuGet.Config')
        build = [sdk, 'build', str(run / 'harness' / 'T3Validation.csproj'), '-c', 'Release', '--nologo', '--disable-build-servers', '-m:1', '-p:UseSharedCompilation=false', f'-p:SnapshotRoot={snapshot}']
        start = time.monotonic()
        built = subprocess.run(build, cwd=run, env=env, text=True, capture_output=True, timeout=180)
        (run / 'build.stdout.log').write_text(built.stdout)
        (run / 'build.stderr.log').write_text(built.stderr)
        record = {'run_id': row['run_id'], 'source_commit': row['commit'], 'original_path': str(row['path']), 'snapshot_path': str(snapshot), 'started_at_utc': utc(), 'build_command': build, 'build_returncode': built.returncode, 'build_elapsed_seconds': time.monotonic() - start}
        if built.returncode:
            record.update(status='build_failure', total=0, passed=0, failed=0, not_exercised=0, results=[])
        else:
            execution = [sdk, str(run / 'harness' / 'bin' / 'Release' / 'net8.0' / 'T3Validation.dll')]
            record['execution_command'] = execution
            try:
                ran = subprocess.run(execution, cwd=run, env=env, text=True, capture_output=True, timeout=150)
                (run / 'execution.stdout.log').write_text(ran.stdout)
                (run / 'execution.stderr.log').write_text(ran.stderr)
                observed = json.loads(ran.stdout)
                record.update(observed)
                record['execution_returncode'] = ran.returncode
                record['status'] = 'evaluated'
            except subprocess.TimeoutExpired as error:
                record.update(status='process_timeout', total=0, passed=0, failed=0, not_exercised=0, results=[], error=str(error))
        (run / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
        results.append(record)
        print(json.dumps({k: record[k] for k in ['run_id', 'status', 'passed', 'failed', 'not_exercised']}), flush=True)
    after = {}
    for row in rows:
        after[row['run_id']] = {'head': command(['git', '-C', str(row['path']), 'rev-parse', 'HEAD']), 'tracked_sha256': tracked_fingerprint(row['path'])}
    original_preserved = before == after
    frozen_preserved = all(sha(out / name) == value for name, value in freeze['files_sha256'].items())
    verification = {'verified_at_utc': utc(), 'original_commits_and_tracked_files_unchanged': original_preserved, 'frozen_harness_unchanged': frozen_preserved}
    (out / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
    (out / 'results.json').write_text(json.dumps({'freeze': freeze, 'verification': verification, 'runs': results}, indent=2) + '\n')
    with (out / 'case_results.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['run_id', 'source_commit', 'case_id', 'scope', 'status', 'duration_ms', 'evidence_json', 'error'])
        writer.writeheader()
        for run in results:
            for result in run['results']:
                writer.writerow({'run_id': run['run_id'], 'source_commit': run['source_commit'], 'case_id': result['Id'], 'scope': result['Scope'], 'status': result['Status'], 'duration_ms': result['DurationMs'], 'evidence_json': json.dumps(result['Evidence']), 'error': result['Error']})
    summary = [
        '# Retrospective external T3 validation results', '',
        'This harness was authored after candidate generation. Results are automated observations, not human adjudication or a confirmatory acceptance study.', '',
        '| Snapshot | Passed | Failed | Conditional probe not exercised |',
        '|---|---:|---:|---:|',
    ]
    for r in results:
        summary.append(f"| {r['run_id']} | {r['passed']} | {r['failed']} | {r['not_exercised']} |")
    summary.extend(['', f"Original commits and tracked files unchanged: {original_preserved}.", f"Frozen harness files unchanged: {frozen_preserved}.", '',
        'The seed baseline is a negative control for the lost-update defect. Conditional-update probes are algorithm-specific and are not counted as failures when that port is not exercised. The ten common task cases are separate from those probes. No complete correctness, branch-coverage, mutation-score or false-positive claim follows from these selected tests.', ''])
    (out / 'summary.md').write_text('\n'.join(summary))
    if not (original_preserved and frozen_preserved):
        raise SystemExit('Integrity verification failed.')


if __name__ == '__main__':
    main()
