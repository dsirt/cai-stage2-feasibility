# Retrospective external T3 validation results

This harness was authored after candidate generation. Results are automated observations, not human adjudication or a confirmatory acceptance study.

| Snapshot | Passed | Failed | Conditional probe not exercised |
|---|---:|---:|---:|
| BASELINE | 7 | 3 | 2 |
| T3R01 | 12 | 0 | 0 |
| T3R02 | 12 | 0 | 0 |
| T3R03 | 12 | 0 | 0 |
| T3R04 | 12 | 0 | 0 |
| T3R05 | 12 | 0 | 0 |
| T3R06 | 12 | 0 | 0 |
| T3R07 | 12 | 0 | 0 |
| T3R08 | 12 | 0 | 0 |

Original commits and tracked files unchanged: True.
Frozen harness files unchanged: True.

The seed baseline is a negative control for the lost-update defect. Conditional-update probes are algorithm-specific and are not counted as failures when that port is not exercised. The ten common task cases are separate from those probes. No complete correctness, branch-coverage, mutation-score or false-positive claim follows from these selected tests.
