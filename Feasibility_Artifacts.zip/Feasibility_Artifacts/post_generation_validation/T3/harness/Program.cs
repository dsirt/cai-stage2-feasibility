using System.Diagnostics;
using System.Text.Json;
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;

var cases = new (string Id, string Scope, Func<Task<object>> Run)[]
{
    ("T3-01", "Sequential reservations conserve stock", Checks.Sequential),
    ("T3-02", "Insufficient stock does not mutate inventory", Checks.Insufficient),
    ("T3-03", "Zero and negative quantities retain rejection behavior", Checks.Invalid),
    ("T3-04", "Missing inventory retains rejection behavior", Checks.Missing),
    ("T3-05", "Cancellation before invocation consumes no stock", Checks.PreCancelled),
    ("T3-06", "Cancellation at the read hook consumes no stock", Checks.HookCancelled),
    ("T3-07", "Persistence failure before commit consumes no stock", Checks.FailedWrite),
    ("T3-08", "Overlapping excess demand across service instances", () => Checks.Cohort(10, new[] { 7, 7 })),
    ("T3-09", "Overlapping fulfillable demand across service instances", () => Checks.Cohort(10, new[] { 3, 4 })),
    ("T3-10", "Finite contention across 32 service instances", () => Checks.Cohort(37, Enumerable.Range(0, 32).Select(i => i % 3 + 1).ToArray())),
    ("T3-11", "Conditional update retry observes cancellation", Checks.RetryCancellation),
    ("T3-12", "Finite conditional update conflicts eventually recover", Checks.RetryRecovery)
};
var results = new List<CaseResult>();
foreach (var (id, scope, run) in cases)
{
    var watch = Stopwatch.StartNew();
    try
    {
        var evidence = await run().WaitAsync(TimeSpan.FromSeconds(10));
        results.Add(new(id, scope, "pass", watch.Elapsed.TotalMilliseconds, evidence, null));
    }
    catch (NotExercisedException e)
    {
        results.Add(new(id, scope, "not_exercised", watch.Elapsed.TotalMilliseconds, e.Evidence, e.Message));
    }
    catch (Exception e)
    {
        results.Add(new(id, scope, "fail", watch.Elapsed.TotalMilliseconds, null, e.ToString()));
    }
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    harness = "T3-retrospective-external-v1",
    started_scope = "Post-generation checks, not preregistered or hidden during candidate generation",
    total = results.Count,
    passed = results.Count(x => x.Status == "pass"),
    failed = results.Count(x => x.Status == "fail"),
    not_exercised = results.Count(x => x.Status == "not_exercised"),
    results
}, new JsonSerializerOptions { WriteIndented = true }));
return results.Any(x => x.Status == "fail") ? 1 : 0;

record CaseResult(string Id, string Scope, string Status, double DurationMs, object? Evidence, string? Error);
sealed class NotExercisedException(string message, object evidence) : Exception(message)
{
    public object Evidence { get; } = evidence;
}

static class Checks
{
    public static InventoryItem Item(int stock = 10) => new() { Id = "INV-EXTERNAL-42", Code = "INV42", Sku = "SKU42", OnHand = stock, Reserved = 0, Version = 1 };
    public static async Task<ProbeSession> Seed(int stock = 10)
    {
        var session = new ProbeSession();
        await session.Inner.SaveAsync(Item(stock));
        return session;
    }
    static InventoryService Service(ProbeSession session, IReservationObserver? observer = null)
        => new(session, observer ?? new NoOpReservationObserver());
    static async Task<InventoryItem> State(ProbeSession session) => (await session.Inner.FindAsync<InventoryItem>(Item().Id))!;
    static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
    static async Task<string> Throws<T>(Func<Task> run) where T : Exception
    {
        try { await run(); }
        catch (T e) { return e.GetType().Name; }
        throw new Exception($"Expected {typeof(T).Name}.");
    }
    static void Unchanged(InventoryItem item)
        => Require(item.Available == 10 && item.Reserved == 0 && item.Version == 1,
            $"Noncommitted request altered inventory: available={item.Available}, reserved={item.Reserved}, version={item.Version}.");

    public static async Task<object> Sequential()
    {
        var s = await Seed(); var service = Service(s);
        var a = await service.ReserveAsync(Item().Id, 3);
        var b = await service.ReserveAsync(Item().Id, 2);
        var final = await State(s);
        Require(a.Success && b.Success && final.Available == 5 && final.Reserved == 5, "Sequential stock conservation failed.");
        Require(a.Code == "Reserved" && b.Code == "Reserved", "Sequential result code changed.");
        return new { a, b, final };
    }
    public static async Task<object> Insufficient()
    {
        var s = await Seed(); var result = await Service(s).ReserveAsync(Item().Id, 11);
        Unchanged(await State(s));
        Require(!result.Success && result.Code == "InsufficientStock", "Insufficient-stock response changed.");
        return new { result, writes = s.WriteAttempts };
    }
    public static async Task<object> Invalid()
    {
        var s = await Seed(); var service = Service(s);
        var zero = await Throws<DomainValidationException>(() => service.ReserveAsync(Item().Id, 0));
        var negative = await Throws<DomainValidationException>(() => service.ReserveAsync(Item().Id, -3));
        Unchanged(await State(s));
        return new { zero, negative, writes = s.WriteAttempts };
    }
    public static async Task<object> Missing()
    {
        var s = await Seed();
        var error = await Throws<MissingEntityException>(() => Service(s).ReserveAsync("MISSING-ITEM", 1));
        Unchanged(await State(s));
        return new { error, writes = s.WriteAttempts };
    }
    public static async Task<object> PreCancelled()
    {
        var s = await Seed(); using var cts = new CancellationTokenSource(); cts.Cancel();
        var error = await Throws<OperationCanceledException>(() => Service(s).ReserveAsync(Item().Id, 3, cts.Token));
        Unchanged(await State(s));
        return new { error, writes = s.WriteAttempts };
    }
    public static async Task<object> HookCancelled()
    {
        var s = await Seed(); using var cts = new CancellationTokenSource();
        var observer = new CancelObserver(cts);
        var error = await Throws<OperationCanceledException>(() => Service(s, observer).ReserveAsync(Item().Id, 3, cts.Token));
        Unchanged(await State(s)); Require(observer.Calls == 1, "Read coordination hook was not reached.");
        return new { error, hook_calls = observer.Calls, writes = s.WriteAttempts };
    }
    public static async Task<object> FailedWrite()
    {
        var s = await Seed(); s.ThrowBeforeWrite = true;
        var error = await Throws<IOException>(() => Service(s).ReserveAsync(Item().Id, 3));
        Unchanged(await State(s)); Require(s.WriteAttempts > 0, "Injected write failure was not exercised.");
        return new { error, writes = s.WriteAttempts };
    }
    public static async Task<object> Cohort(int stock, int[] quantities)
    {
        var s = await Seed(stock); using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        var observer = new OneShotObserver(quantities.Length);
        var services = quantities.Select(_ => Service(s, observer)).ToArray();
        var results = await Task.WhenAll(services.Select((service, i) => service.ReserveAsync(Item().Id, quantities[i], deadline.Token)));
        var final = await State(s);
        var successfulQuantity = results.Select((result, i) => result.Success ? quantities[i] : 0).Sum();
        var evidence = JsonSerializer.Serialize(new { stock, quantities, results, final, successfulQuantity, observed_available = s.ObservedAvailable.ToArray(), hook_calls = observer.Calls });
        Require(final.Available == stock - successfulQuantity, "Stock conservation failed. " + evidence);
        Require(final.Reserved == successfulQuantity, "Reserved amount differs from successful quantities. " + evidence);
        Require(final.Available >= 0 && s.ObservedAvailable.All(x => x >= 0), "Negative committed availability observed. " + evidence);
        Require(results.Any(x => x.Success), "No request completed successfully despite sufficient stock for at least one request. " + evidence);
        Require(results.All(x => x.Code == (x.Success ? "Reserved" : "InsufficientStock")), "Reservation response code changed. " + evidence);
        if (quantities.Sum() <= stock) Require(results.All(x => x.Success), "Fulfillable requests were rejected. " + evidence);
        return JsonSerializer.Deserialize<JsonElement>(evidence);
    }
    public static async Task<object> RetryCancellation()
    {
        var s = await Seed(); using var cts = new CancellationTokenSource();
        s.RejectConditionalWrites = 1; s.CancelOnRejectedConditionalWrite = cts;
        Exception? error = null;
        try { await Service(s).ReserveAsync(Item().Id, 3, cts.Token); }
        catch (Exception e) { error = e; }
        if (s.ConditionalAttempts == 0)
            throw new NotExercisedException("This implementation did not use the conditional-update port. This algorithm-specific probe is not a task acceptance criterion.", new { writes = s.WriteAttempts });
        Require(error is OperationCanceledException, "Cancellation during a conditional-update retry was not propagated.");
        Unchanged(await State(s));
        return new { error = error!.GetType().Name, conditional_attempts = s.ConditionalAttempts };
    }
    public static async Task<object> RetryRecovery()
    {
        var s = await Seed(); s.RejectConditionalWrites = 3;
        var result = await Service(s).ReserveAsync(Item().Id, 3);
        if (s.ConditionalAttempts == 0)
            throw new NotExercisedException("This implementation did not use the conditional-update port. This algorithm-specific probe is not a task acceptance criterion.", new { writes = s.WriteAttempts });
        var final = await State(s);
        Require(result.Success && final.Available == 7 && final.Reserved == 3, "Recovery after three rejected conditional updates did not conserve stock.");
        Require(s.ConditionalAttempts == 4, "Unexpected conditional update attempt count in the controlled retry probe.");
        return new { result, final, conditional_attempts = s.ConditionalAttempts };
    }
}

sealed class OneShotObserver(int parties) : IReservationObserver
{
    readonly TaskCompletionSource release = new(TaskCreationOptions.RunContinuationsAsynchronously);
    int calls;
    public int Calls => Volatile.Read(ref calls);
    public async Task AfterReadAsync(InventoryItem snapshot, CancellationToken token = default)
    {
        if (Interlocked.Increment(ref calls) >= parties) release.TrySetResult();
        await release.Task.WaitAsync(token);
    }
}
sealed class CancelObserver(CancellationTokenSource source) : IReservationObserver
{
    public int Calls { get; private set; }
    public Task AfterReadAsync(InventoryItem snapshot, CancellationToken token = default)
    { Calls++; source.Cancel(); return Task.CompletedTask; }
}
sealed class ProbeSession : IDatabaseSession
{
    public InMemoryDatabaseSession Inner { get; } = new();
    public bool ThrowBeforeWrite { get; set; }
    public int RejectConditionalWrites { get; set; }
    public CancellationTokenSource? CancelOnRejectedConditionalWrite { get; set; }
    int writeAttempts, conditionalAttempts;
    public int WriteAttempts => Volatile.Read(ref writeAttempts);
    public int ConditionalAttempts => Volatile.Read(ref conditionalAttempts);
    public System.Collections.Concurrent.ConcurrentQueue<int> ObservedAvailable { get; } = new();
    public Task<T?> FindAsync<T>(string id, CancellationToken token = default) where T : BusinessDocument => Inner.FindAsync<T>(id, token);
    public Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken token = default) where T : BusinessDocument => Inner.ListAsync<T>(token);
    void BeforeWrite()
    {
        Interlocked.Increment(ref writeAttempts);
        if (ThrowBeforeWrite) throw new IOException("External harness injected a failure before persistence.");
    }
    public async Task SaveAsync<T>(T item, CancellationToken token = default) where T : BusinessDocument
    { BeforeWrite(); await Inner.SaveAsync(item, token); if (item is InventoryItem inventory) ObservedAvailable.Enqueue(inventory.Available); }
    public async Task<bool> TryReplaceAsync<T>(T item, int expectedVersion, CancellationToken token = default) where T : BusinessDocument
    {
        BeforeWrite(); Interlocked.Increment(ref conditionalAttempts); token.ThrowIfCancellationRequested();
        if (RejectConditionalWrites > 0)
        { RejectConditionalWrites--; CancelOnRejectedConditionalWrite?.Cancel(); return false; }
        var result = await Inner.TryReplaceAsync(item, expectedVersion, token);
        if (result && item is InventoryItem inventory) ObservedAvailable.Enqueue(inventory.Available);
        return result;
    }
    public Task DeleteAsync<T>(string id, CancellationToken token = default) where T : BusinessDocument => Inner.DeleteAsync<T>(id, token);
    public Task<T> InTransactionAsync<T>(Func<CancellationToken, Task<T>> action, CancellationToken token = default) => Inner.InTransactionAsync(action, token);
}
