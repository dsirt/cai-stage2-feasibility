# Retrospective external T3 behavioral validation

This evaluator-authored harness was created after the 24 agent changes and the Stage 2 timing experiment. It is not a preregistered test suite and was not hidden executable feedback available during generation. No candidate is repaired, excluded, or regenerated based on these results. It uses the published T3 requirements and retained baseline API. The harness tests selected behaviors and does not certify complete task correctness or absence of defects.

The ten common task cases exercise sequential stock conservation, insufficient stock, invalid quantities, missing items, cancellation before invocation, cancellation at the existing read hook, a persistence failure before commit, two forced-overlap cohorts, and a finite 32-request cohort. Every overlapping request uses a separate service instance sharing one persistence session. The observer releases permanently after the initial cohort arrives, so implementations may call it again during retries without artificial barrier deadlock. The seed baseline is evaluated as a sensitivity control for lost updates.

Two additional probes exercise cancellation and recovery at the existing conditional-update port. They are explicitly algorithm-specific. A candidate that does not call that port receives `not_exercised`, not a task failure, for these probes. No requirement to use a particular concurrency algorithm is introduced. Forced false conditional-update returns simulate finite version conflicts without writing inventory.

The overlap checks inspect the conservation equation, nonnegative committed values, successful and rejected result codes, and completion under bounded finite contention. The timeout is a harness resource limit, not a benchmark performance claim. Public tests and agent-written assertions are not reused in this executable. The `ProbeSession` delegates normal operations to the retained infrastructure and injects only stated pre-commit failures or conditional conflicts.

The runner freezes SHA-256 hashes of the harness, project, runner, and this specification with a UTC timestamp before executing the baseline or any candidate. Every source snapshot is reconstructed with `git archive` from its recorded commit into a new directory. Original baseline, heads, gate outputs and timing records remain unchanged. Input tracked files and commit identities are verified before and after the new checks. The JSON and CSV contain all baseline and candidate outcomes and exact commands. Build failure, timeout, assertion failure and `not_exercised` are distinct statuses.

No human adjudication, false-positive rate, missed-defect rate, branch coverage, mutation score, preregistration, or confirmatory study is claimed. Runtime fields only document these post-generation checks and do not alter the original Stage 2 latency measurements.

Reproduction from this workspace:

```sh
python3 work/post_generation_validation/T3/run_validation.py
```

The runner accepts `--work-root` and `--output-root` for relocated or separate runs. A fresh output root is required once results exist. The .NET SDK path is `<work-root>/dotnet/dotnet`. The source manifest is `<work-root>/experiment_manifest.json`. A portable replay can reconstruct its manifest paths from the supplied repository bundle before invoking the runner. SDK 8.0.425 is pinned through the copied `global.json`. No external packages are introduced.
