#!/usr/bin/env python3
"""Retrospective evaluator-authored T1 checks, no candidate modifications."""
import csv, datetime, hashlib, io, json, os, subprocess, tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[1]
SDK=WORK/'dotnet/dotnet'
manifest=json.loads((WORK/'experiment_manifest.json').read_text())
baseline=manifest['changes'][0]['parent_commit']
rows=[dict(change_id='BASELINE',head_commit=baseline,head_path=str(WORK/'benchmark'))]+[r for r in manifest['changes'] if r['task_id']=='T1']
factories={
 'BASELINE':'new PurchaseOrderService(session)',
 'T1R01':'new PurchaseOrderService(new PurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
 'T1R02':'new PurchaseOrderService(new DatabasePurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
 'T1R03':'new PurchaseOrderService(new PurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
 'T1R04':'new PurchaseOrderService(new DatabasePurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
 'T1R05':'new PurchaseOrderService(new DatabaseRepository<PurchaseOrder>(session), new DatabaseRepository<PurchaseOrderLine>(session), new DatabaseUnitOfWork(session))',
 'T1R06':'new PurchaseOrderService(new DatabasePurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
 'T1R07':'new PurchaseOrderService(new DatabaseRepository(session), new DatabaseUnitOfWork(session))',
 'T1R08':'new PurchaseOrderService(new PurchaseOrderRepository(session), new DatabaseUnitOfWork(session))',
}
env=os.environ.copy(); env.update(DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1')
projects=[]
for r in rows:
 target=ROOT/'snapshots'/r['change_id']; target.mkdir(parents=True,exist_ok=True)
 archive=subprocess.check_output(['git','-C',r['head_path'],'archive',r['head_commit']])
 with tarfile.open(fileobj=io.BytesIO(archive)) as tf: tf.extractall(target,filter='data')
 h=target/'ExternalT1'; h.mkdir(exist_ok=True)
 (h/'Program.cs').write_bytes((ROOT/'Program.cs').read_bytes())
 binding='using Benchmark.Application; using Benchmark.Domain; using Benchmark.Infrastructure;\npublic static class Binding {\n public const bool UsesRepositoryAndUnitOfWork = '+str(r['change_id']!='BASELINE').lower()+';\n public static PurchaseOrderService Create(IDatabaseSession session) => '+factories[r['change_id']]+';\n}\n'
 (h/'Binding.cs').write_text(binding)
 (h/'ExternalT1.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType></PropertyGroup><ItemGroup><ProjectReference Include="../src/Domain/Benchmark.Domain.csproj"/><ProjectReference Include="../src/Application/Benchmark.Application.csproj"/><ProjectReference Include="../src/Infrastructure/Benchmark.Infrastructure.csproj"/></ItemGroup></Project>')
 projects.append((r,h))
freeze={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'after candidate generation, before first external test evaluation','preregistered':False,'human_adjudication':False,'interpretation':'23 behavior cases and 3 architecture cases. Compatibility-constructor presence/absence is observed, not scored. Explicit adapters use actual candidate Infrastructure implementations. Baseline comparator is not an agent submission. Finite tests cannot establish complete correctness. Production composition-root execution and branch/mutation coverage are not evaluated.','inputs':[]}
for p in [ROOT/'Program.cs',ROOT/'evaluate.py']+[p for _,h in projects for p in (h/'Binding.cs',h/'ExternalT1.csproj')]:
 freeze['inputs'].append({'path':str(p.relative_to(ROOT)), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(ROOT/'harness_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
(ROOT/'logs').mkdir(exist_ok=True); (ROOT/'results').mkdir(exist_ok=True)
all_records=[]; summary=[]
for r,h in projects:
 id=r['change_id']; commands=[]
 def call(args,label):
  start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  p=subprocess.run([str(SDK),*args],cwd=h,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  log=ROOT/'logs'/f'{id}.{label}.log'; log.write_text(p.stdout)
  commands.append({'command':[str(SDK),*args], 'cwd':str(h),'started_utc':start,'exit_code':p.returncode,'log':str(log.relative_to(ROOT))})
  return p
 build=call(['build','ExternalT1.csproj','-c','Release','--disable-build-servers','-m:1','-nr:false','-p:UseSharedCompilation=false'],'build')
 if build.returncode==0:
  run=call(['bin/Release/net8.0/ExternalT1.dll'],'run')
  try: result=json.loads(run.stdout)
  except Exception: result={'tests':[{'id':'harness_execution','category':'harness','status':'not_evaluable','detail':run.stdout}]}
 else: result={'tests':[{'id':'harness_build','category':'harness','status':'not_evaluable','detail':build.stdout}]}
 result.update(change_id=id,head_commit=r['head_commit'],commands=commands)
 (ROOT/'results'/f'{id}.json').write_text(json.dumps(result,indent=2)+'\n')
 for t in result['tests']: all_records.append(dict(change_id=id,head_commit=r['head_commit'],**t))
 counts={cat:{st:sum(t['category']==cat and t['status']==st for t in result['tests']) for st in ['passed','failed','not_evaluable']} for cat in ['behavior','architecture','harness']}
 summary.append(dict(change_id=id,head_commit=r['head_commit'],counts=counts))
 print(id,counts,flush=True)
with (ROOT/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['change_id','head_commit','id','category','status','detail']); w.writeheader(); w.writerows(all_records)
(ROOT/'summary.json').write_text(json.dumps({'scope':freeze['interpretation'],'harness_sha256':hashlib.sha256((ROOT/'harness_freeze.json').read_bytes()).hexdigest(),'runs':summary},indent=2)+'\n')
