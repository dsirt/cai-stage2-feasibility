# T1 retrospective external validation

This evaluator was written after all agent-generated changes and the gate runtime measurements had been frozen. It is not a preregistered or hidden-at-generation test suite. Its author is a separate AI evaluation agent. It is not human adjudication and does not estimate false-positive or false-negative rates of Stage 2 gates.

The harness tests the unchanged baseline and the eight retained T1 commits. Each is extracted into a disposable snapshot. The original source repositories, commits, and gate measurements remain unchanged. The common Program.cs assertions use explicit per-candidate adapters. These adapters construct the candidate's real Infrastructure repositories and unit of work over the same instrumented session. Baseline construction uses its original IDatabaseSession constructor. The instrumented session delegates storage and transaction rollback to that candidate's InMemoryDatabaseSession and injects specified persistence failures or cancellations.

## Interpretation

Behavior and architecture are reported separately. The 23 behavior cases cover finite examples of the original operation-method contract. They do not prove complete task success. The three architecture checks inspect compiled assembly references, stored service dependency types, and the actual objects selected by the explicit harness bindings. They do not execute the API production composition root or establish transitive semantic independence of every method body.

The task requirements conflict on constructor compatibility. Some candidates retained an IDatabaseSession compatibility constructor, while others removed it. Constructor parameter types are recorded without awarding or deducting a test result. Architecture case A02 checks stored workflow dependencies, not the presence of an adapter constructor. A03 checks the explicitly selected Infrastructure implementation objects, not dependency injection configuration in the web application.

A test passes only when all assertions in that named case complete. A failed test records its exception and stack trace. A build or output parsing failure is not_evaluable and is not counted as a candidate behavioral failure. No tests were revised after the first evaluation, if the recorded freeze and final source hashes match. Original public test results belong to the earlier preflight records and are separate from these additional results.

No branch coverage, mutation score, human expert agreement, historical threshold calibration, or production-representativeness result is claimed.

## Cases

- `B01_create_values_boundary` (behavior): create values boundary.
- `B02_read_only_no_writes_or_commits` (behavior): read only no writes or commits.
- `B03_lines_filter_ordinal_order` (behavior): lines filter ordinal order.
- `B04_add_line_exact_money_atomic_boundary` (behavior): add line exact money atomic boundary.
- `B05_remove_values_boundary` (behavior): remove values boundary.
- `B06_submit_approve_boundaries` (behavior): submit approve boundaries.
- `B07_missing_order_behavior` (behavior): missing order behavior.
- `B08_invalid_create` (behavior): invalid create.
- `B09_non_draft_create` (behavior): non draft create.
- `B10_duplicate_create_id_and_code` (behavior): duplicate create id and code.
- `B11_invalid_line` (behavior): invalid line.
- `B12_stale_version` (behavior): stale version.
- `B13_empty_submit_and_draft_approve` (behavior): empty submit and draft approve.
- `B14_duplicate_line_id_and_code` (behavior): duplicate line id and code.
- `B15_missing_and_foreign_line_removal` (behavior): missing and foreign line removal.
- `B16_add_second_write_failure_rolls_back` (behavior): add second write failure rolls back.
- `B17_remove_save_failure_restores_deleted_line` (behavior): remove save failure restores deleted line.
- `B18_create_persistence_failure` (behavior): create persistence failure.
- `B19_pre_cancelled_create_and_reads` (behavior): pre cancelled create and reads.
- `B20_pre_cancelled_mutations` (behavior): pre cancelled mutations.
- `B21_cancel_after_first_write_rolls_back` (behavior): cancel after first write rolls back.
- `B22_failure_at_commit_rolls_back_all_writes` (behavior): failure at commit rolls back all writes.
- `B23_cancel_at_commit_rolls_back_all_writes` (behavior): cancel at commit rolls back all writes.
- `A01_application_compiled_reference_boundary` (architecture): application compiled reference boundary.
- `A02_service_owns_only_application_contract_fields` (architecture): service owns only application contract fields.
- `A03_explicit_repository_uow_infrastructure_binding` (architecture): explicit repository uow infrastructure binding.

Program.cs is the exact executable definition of each assertion, including expected exception types, decimal amounts, transaction counts, and stored values. Case B04 checks 3 times 12.345 rounded away from zero to 37.04, then a 12.5 percent discount rounded to 32.41. Fault cases compare stored order and line records after failure. Read-only cases also assert zero writes and transaction entries.

## Provenance and reproduction

- harness_freeze.json records UTC creation and SHA-256 hashes before the first evaluation.
- results.csv and results/*.json contain case results with exact source commits.
- logs/*.build.log and logs/*.run.log retain all command output.
- Per-run JSON includes the actual commands, working directory, start time, and exit status.
- The disposable snapshots directory contains extracted source and build output and can be omitted from distribution. Its per-head Binding.cs files must be retained separately because their hashes are in the freeze record.

Run a clean replay with Python 3.12, git, and .NET SDK 8.0.425:

```sh
python3 replay.py --bundle /path/to/repository.bundle --manifest /path/to/experiment_manifest.json --dotnet /path/to/dotnet --output /new/empty-location
```

The replay reconstructs baseline and T1 heads from the bundle, makes local path mappings, and executes the unchanged evaluator. It does not reproduce original agent generation. The output directory must not already exist. The original output hashes describe the original run and will naturally differ for timestamped replay records. No network packages are required.
