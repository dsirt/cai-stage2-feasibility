#!/usr/bin/env python3
"""Reconstruct frozen sources from the submission bundle and replay T1 checks."""
import argparse, json, shutil, subprocess, sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--bundle',required=True,type=Path)
p.add_argument('--manifest',required=True,type=Path)
p.add_argument('--dotnet',required=True,type=Path,help='Path to installed .NET 8.0.425 dotnet executable')
p.add_argument('--output',required=True,type=Path,help='New directory for reconstructed inputs and outputs')
a=p.parse_args(); base=Path(__file__).resolve().parent
out=a.output.resolve()
if out.exists(): p.error('--output must not exist')
sdk=a.dotnet.resolve()
version=subprocess.check_output([str(sdk),'--version'],text=True).strip()
if version!='8.0.425': p.error('Pinned SDK 8.0.425 required, found '+version)
work=out/'work'; harness=work/'post_generation_validation/T1'; harness.mkdir(parents=True)
(work/'dotnet').symlink_to(sdk.parent,target_is_directory=True)
manifest=json.loads(a.manifest.read_text())
entries=[e for e in manifest['changes'] if e['task_id']=='T1']
baseline=entries[0]['parent_commit']; repo=work/'benchmark'
subprocess.run(['git','clone',str(a.bundle.resolve()),str(repo)],check=True)
subprocess.run(['git','-C',str(repo),'checkout','--detach',baseline],check=True)
for e in entries:
 target=work/'agent_runs'/e['change_id']
 subprocess.run(['git','clone','--shared',str(repo),str(target)],check=True)
 subprocess.run(['git','-C',str(target),'checkout','--detach',e['head_commit']],check=True)
 e['parent_path']=str(repo); e['head_path']=str(target)
(work/'experiment_manifest.json').write_text(json.dumps({'changes':entries},indent=2)+'\n')
for name in ['Program.cs','evaluate.py']:
 shutil.copy2(base/name,harness/name)
subprocess.run([sys.executable,str(harness/'evaluate.py')],check=True)
print(harness/'summary.json')
