using Benchmark.Application; using Benchmark.Domain; using Benchmark.Infrastructure;
public static class Binding {
 public const bool UsesRepositoryAndUnitOfWork = true;
 public static PurchaseOrderService Create(IDatabaseSession session) => new PurchaseOrderService(new DatabasePurchaseOrderRepository(session), new DatabaseUnitOfWork(session));
}
