using Benchmark.Application; using Benchmark.Domain; using Benchmark.Infrastructure;
public static class Binding {
 public const bool UsesRepositoryAndUnitOfWork = false;
 public static PurchaseOrderService Create(IDatabaseSession session) => new PurchaseOrderService(session);
}
