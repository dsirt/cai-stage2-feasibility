using System.Reflection;
using System.Text.Json;
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;

var results = new List<object>();
async Task Case(string id, string category, Func<Task> test)
{
    try { await test(); results.Add(new { id, category, status = "passed", detail = "" }); }
    catch (Exception e) { results.Add(new { id, category, status = "failed", detail = e.ToString() }); }
}
void Eq<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, actual {actual}"); }
void True(bool b, string m) { if (!b) throw new Exception(m); }
async Task Throws<T>(Func<Task> f) where T : Exception
{
    try { await f(); } catch (T) { return; }
    throw new Exception($"Expected {typeof(T).Name}");
}
PurchaseOrder Order(string id = "PO-A", string code = "A") => new() { Id = id, Code = code, DiscountPercent = 12.5m };
PurchaseOrderLine Line(string id = "LINE-A", string code = "A", string order = "PO-A") => new() { Id = id, Code = code, OrderId = order, ProductId = "PRODUCT-A", Quantity = 3, UnitPrice = 12.345m };
async Task<(ProbeSession, PurchaseOrderService, PurchaseOrder)> Draft()
{
    var p = new ProbeSession(); var s = Binding.Create(p); var o = await s.CreateAsync(Order()); p.Reset(); return (p, s, o);
}
await Case("B01_create_values_boundary", "behavior", async () => {
    var (p,s,o) = await Draft(); Eq(1, o.Version); Eq(o, await p.Inner.FindAsync<PurchaseOrder>(o.Id));
    p.Reset(); var b = await s.CreateAsync(Order("PO-B", "B")); Eq(1, p.Transactions); Eq(1, p.Commits); Eq(1, p.Writes); Eq(b, await p.Inner.FindAsync<PurchaseOrder>(b.Id));
});
await Case("B02_read_only_no_writes_or_commits", "behavior", async () => {
    var (p,s,o) = await Draft(); Eq(o, await s.GetAsync(o.Id)); Eq(0, (await s.GetLinesAsync(o.Id)).Count); Eq(0, p.Transactions); Eq(0, p.Writes); Eq(0, p.Commits);
});
await Case("B03_lines_filter_ordinal_order", "behavior", async () => {
    var (p,s,o) = await Draft(); foreach (var l in new[]{Line("L1","z"),Line("L2","A"),Line("L3","B","OTHER")}) await p.Inner.SaveAsync(l);
    Eq("L2,L1", string.Join(",", (await s.GetLinesAsync(o.Id)).Select(x=>x.Id))); Eq(0,p.Writes); Eq(0,p.Transactions);
});
await Case("B04_add_line_exact_money_atomic_boundary", "behavior", async () => {
    var (p,s,o) = await Draft(); var l=Line(); var next=await s.AddLineAsync(l,o.Version);
    Eq(32.41m,next.Amount); Eq(2,next.Version); Eq(next,await p.Inner.FindAsync<PurchaseOrder>(o.Id));
    Eq(l with { Version=1,Amount=37.04m },await p.Inner.FindAsync<PurchaseOrderLine>(l.Id)); Eq(2,p.Writes); Eq(1,p.Transactions); Eq(1,p.Commits);
});
await Case("B05_remove_values_boundary", "behavior", async () => {
    var (p,s,o)=await Draft(); var a=await s.AddLineAsync(Line(),o.Version); p.Reset(); var b=await s.RemoveLineAsync(o.Id,"LINE-A",a.Version);
    Eq(0m,b.Amount); Eq(3,b.Version); Eq<PurchaseOrderLine?>(null,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(b,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq(2,p.Writes); Eq(1,p.Commits); Eq(1,p.Transactions);
});
await Case("B06_submit_approve_boundaries", "behavior", async () => {
    var (p,s,o)=await Draft(); var a=await s.AddLineAsync(Line(),o.Version); p.Reset(); var b=await s.SubmitAsync(o.Id,a.Version); Eq(DocumentStatus.Submitted,b.Status); Eq(3,b.Version); Eq(1,p.Commits); Eq(1,p.Writes);
    p.Reset(); var c=await s.ApproveAsync(o.Id,b.Version); Eq(DocumentStatus.Approved,c.Status); Eq(4,c.Version); Eq(1,p.Transactions); Eq(1,p.Commits); Eq(1,p.Writes); Eq(c,await p.Inner.FindAsync<PurchaseOrder>(o.Id));
});
await Case("B07_missing_order_behavior", "behavior", async () => {
    var p=new ProbeSession(); var s=Binding.Create(p); await Throws<MissingEntityException>(()=>s.GetAsync("ABSENT")); await Throws<MissingEntityException>(()=>s.AddLineAsync(Line(),0)); await Throws<MissingEntityException>(()=>s.SubmitAsync("ABSENT",0)); await Throws<MissingEntityException>(()=>s.ApproveAsync("ABSENT",0)); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B08_invalid_create", "behavior", async () => {
    var p=new ProbeSession(); var s=Binding.Create(p); await Throws<DomainValidationException>(()=>s.CreateAsync(Order() with {Currency="invalid"})); Eq(0,p.Writes); Eq(0,p.Commits); Eq(0,(await p.Inner.ListAsync<PurchaseOrder>()).Count);
});
await Case("B09_non_draft_create", "behavior", async () => {
    var p=new ProbeSession(); var s=Binding.Create(p); await Throws<DomainValidationException>(()=>s.CreateAsync(Order() with {Status=DocumentStatus.Approved})); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B10_duplicate_create_id_and_code", "behavior", async () => {
    var (p,s,o)=await Draft(); await Throws<DomainValidationException>(()=>s.CreateAsync(Order())); await Throws<DomainValidationException>(()=>s.CreateAsync(Order("DIFFERENT","A"))); Eq(0,p.Writes); Eq(0,p.Commits); Eq(1,(await p.Inner.ListAsync<PurchaseOrder>()).Count);
});
await Case("B11_invalid_line", "behavior", async () => {
    var (p,s,o)=await Draft(); await Throws<DomainValidationException>(()=>s.AddLineAsync(Line() with {Quantity=0},o.Version)); Eq(0,p.Writes); Eq(0,p.Commits); Eq(o,await s.GetAsync(o.Id));
});
await Case("B12_stale_version", "behavior", async () => {
    var (p,s,o)=await Draft(); await Throws<ConcurrencyConflictException>(()=>s.AddLineAsync(Line(),0)); await Throws<ConcurrencyConflictException>(()=>s.SubmitAsync(o.Id,0)); await Throws<ConcurrencyConflictException>(()=>s.ApproveAsync(o.Id,0)); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B13_empty_submit_and_draft_approve", "behavior", async () => {
    var (p,s,o)=await Draft(); await Throws<DomainValidationException>(()=>s.SubmitAsync(o.Id,o.Version)); await Throws<DomainValidationException>(()=>s.ApproveAsync(o.Id,o.Version)); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B14_duplicate_line_id_and_code", "behavior", async () => {
    var (p,s,o)=await Draft(); var a=await s.AddLineAsync(Line(),o.Version); p.Reset(); await Throws<DomainValidationException>(()=>s.AddLineAsync(Line(),a.Version)); await Throws<DomainValidationException>(()=>s.AddLineAsync(Line("OTHER","A"),a.Version)); Eq(0,p.Writes); Eq(0,p.Commits); Eq(1,(await s.GetLinesAsync(o.Id)).Count);
});
await Case("B15_missing_and_foreign_line_removal", "behavior", async () => {
    var (p,s,o)=await Draft(); await p.Inner.SaveAsync(Line("FOREIGN","B","OTHER")); await Throws<MissingEntityException>(()=>s.RemoveLineAsync(o.Id,"ABSENT",o.Version)); await Throws<DomainValidationException>(()=>s.RemoveLineAsync(o.Id,"FOREIGN",o.Version)); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B16_add_second_write_failure_rolls_back", "behavior", async () => {
    var (p,s,o)=await Draft(); p.FailSaveAt=2; await Throws<IOException>(()=>s.AddLineAsync(Line(),o.Version)); Eq(o,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq<PurchaseOrderLine?>(null,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(0,p.Commits); Eq(1,p.Transactions);
});
await Case("B17_remove_save_failure_restores_deleted_line", "behavior", async () => {
    var (p,s,o)=await Draft(); var a=await s.AddLineAsync(Line(),o.Version); var original=await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A"); p.Reset(); p.FailSaveAt=1; await Throws<IOException>(()=>s.RemoveLineAsync(o.Id,"LINE-A",a.Version)); Eq(a,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq(original,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(0,p.Commits);
});
await Case("B18_create_persistence_failure", "behavior", async () => {
    var p=new ProbeSession {FailSaveAt=1}; var s=Binding.Create(p); await Throws<IOException>(()=>s.CreateAsync(Order())); Eq(0,(await p.Inner.ListAsync<PurchaseOrder>()).Count); Eq(0,p.Commits);
});
await Case("B19_pre_cancelled_create_and_reads", "behavior", async () => {
    var p=new ProbeSession(); var s=Binding.Create(p); using var c=new CancellationTokenSource(); c.Cancel(); await Throws<OperationCanceledException>(()=>s.CreateAsync(Order(),c.Token)); await Throws<OperationCanceledException>(()=>s.GetAsync("ABSENT",c.Token)); await Throws<OperationCanceledException>(()=>s.GetLinesAsync("ABSENT",c.Token)); Eq(0,p.Writes); Eq(0,p.Commits);
});
await Case("B20_pre_cancelled_mutations", "behavior", async () => {
    var (p,s,o)=await Draft(); using var c=new CancellationTokenSource(); c.Cancel(); await Throws<OperationCanceledException>(()=>s.AddLineAsync(Line(),o.Version,c.Token)); await Throws<OperationCanceledException>(()=>s.RemoveLineAsync(o.Id,"ABSENT",o.Version,c.Token)); await Throws<OperationCanceledException>(()=>s.SubmitAsync(o.Id,o.Version,c.Token)); await Throws<OperationCanceledException>(()=>s.ApproveAsync(o.Id,o.Version,c.Token)); Eq(0,p.Writes); Eq(0,p.Commits); Eq(o,await p.Inner.FindAsync<PurchaseOrder>(o.Id));
});
await Case("B21_cancel_after_first_write_rolls_back", "behavior", async () => {
    var (p,s,o)=await Draft(); using var c=new CancellationTokenSource(); p.AfterSave=()=>c.Cancel(); await Throws<OperationCanceledException>(()=>s.AddLineAsync(Line(),o.Version,c.Token)); Eq(o,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq<PurchaseOrderLine?>(null,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(0,p.Commits);
});
await Case("B22_failure_at_commit_rolls_back_all_writes", "behavior", async () => {
    var (p,s,o)=await Draft(); p.FailBeforeCommit=true; await Throws<IOException>(()=>s.AddLineAsync(Line(),o.Version)); Eq(o,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq<PurchaseOrderLine?>(null,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(0,p.Commits);
});
await Case("B23_cancel_at_commit_rolls_back_all_writes", "behavior", async () => {
    var (p,s,o)=await Draft(); using var c=new CancellationTokenSource(); p.BeforeCommit=()=>c.Cancel(); await Throws<OperationCanceledException>(()=>s.AddLineAsync(Line(),o.Version,c.Token)); Eq(o,await p.Inner.FindAsync<PurchaseOrder>(o.Id)); Eq<PurchaseOrderLine?>(null,await p.Inner.FindAsync<PurchaseOrderLine>("LINE-A")); Eq(0,p.Commits);
});
await Case("A01_application_compiled_reference_boundary", "architecture", () => {
    True(!typeof(PurchaseOrderService).Assembly.GetReferencedAssemblies().Any(x=>x.Name=="Benchmark.Infrastructure"),"Application references Infrastructure"); True(!typeof(PurchaseOrder).Assembly.GetReferencedAssemblies().Any(x=>x.Name=="Benchmark.Application" || x.Name=="Benchmark.Infrastructure"),"Domain references outer layer"); return Task.CompletedTask;
});
await Case("A02_service_owns_only_application_contract_fields", "architecture", () => {
    var fields=typeof(PurchaseOrderService).GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public); True(fields.Length>0,"No stored dependencies found"); foreach(var f in fields) { True(f.FieldType.IsInterface,"Stored dependency is not an interface: "+f.FieldType); True(f.FieldType.Assembly==typeof(PurchaseOrderService).Assembly || f.FieldType.Assembly==typeof(PurchaseOrder).Assembly,"Stored dependency outside inner contracts"); True(f.FieldType!=typeof(IDatabaseSession),"Workflow retains direct IDatabaseSession field"); } return Task.CompletedTask;
});
await Case("A03_explicit_repository_uow_infrastructure_binding", "architecture", () => {
    True(Binding.UsesRepositoryAndUnitOfWork,"Baseline has no repository/unit-of-work refactoring"); var constructed=Binding.Create(new ProbeSession()); var fields=typeof(PurchaseOrderService).GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public); True(fields.Length>=2,"Repository and unit-of-work storage not found"); foreach(var f in fields) { var v=f.GetValue(constructed); True(v is not null && v.GetType().Assembly==typeof(InMemoryDatabaseSession).Assembly,"Adapter not provided by Infrastructure"); } return Task.CompletedTask;
});
var observations=new { publicMethods=typeof(PurchaseOrderService).GetMethods(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly).Select(x=>x.ToString()).ToArray(), constructorParameterTypes=typeof(PurchaseOrderService).GetConstructors().Select(c=>c.GetParameters().Select(p=>p.ParameterType.FullName).ToArray()).ToArray(), storedFields=typeof(PurchaseOrderService).GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).Select(f=>new{f.Name,type=f.FieldType.FullName}).ToArray(), applicationReferences=typeof(PurchaseOrderService).Assembly.GetReferencedAssemblies().Select(x=>x.FullName).ToArray() };
Console.WriteLine(JsonSerializer.Serialize(new { tests=results, observations },new JsonSerializerOptions {WriteIndented=true}));

public sealed class ProbeSession : IDatabaseSession
{
    public InMemoryDatabaseSession Inner {get;} = new();
    public int Writes, Saves, Transactions, Commits, FailSaveAt;
    public bool FailBeforeCommit;
    public Action? AfterSave, BeforeCommit;
    public void Reset() { Writes=Saves=Transactions=Commits=FailSaveAt=0; FailBeforeCommit=false; AfterSave=BeforeCommit=null; }
    public Task<T?> FindAsync<T>(string id,CancellationToken t=default) where T:BusinessDocument => Inner.FindAsync<T>(id,t);
    public Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken t=default) where T:BusinessDocument => Inner.ListAsync<T>(t);
    public async Task SaveAsync<T>(T d,CancellationToken t=default) where T:BusinessDocument { Saves++; if(Saves==FailSaveAt) throw new IOException("Injected save failure"); await Inner.SaveAsync(d,t); Writes++; AfterSave?.Invoke(); }
    public async Task DeleteAsync<T>(string id,CancellationToken t=default) where T:BusinessDocument { await Inner.DeleteAsync<T>(id,t); Writes++; }
    public Task<bool> TryReplaceAsync<T>(T d,int v,CancellationToken t=default) where T:BusinessDocument => Inner.TryReplaceAsync(d,v,t);
    public async Task<T> InTransactionAsync<T>(Func<CancellationToken,Task<T>> action,CancellationToken t=default) { Transactions++; var value=await Inner.InTransactionAsync(async token=> { var r=await action(token); BeforeCommit?.Invoke(); if(FailBeforeCommit) throw new IOException("Injected precommit failure"); return r; },t); Commits++; return value; }
}
