from pathlib import Path
import json,csv,hashlib,subprocess,collections,statistics,math
B=Path('/workspace/scratch/6d54e12a9ca2/work');D=B/'measurements'
manifest=json.loads((B/'experiment_manifest.json').read_text());changes=manifest['changes'];rows=list(csv.DictReader((D/'gate_runs.csv').open()));checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
check(len(changes)==24 and len({x['head_commit'] for x in changes})==24,'24 distinct submitted heads retained')
check(collections.Counter(x['task_id'] for x in changes)=={'T1':8,'T2':8,'T3':8},'eight heads for each task')
check(len(rows)==1314 and len({r['attempt_id'] for r in rows})==1314,'1314 uniquely identified gate attempts')
check(collections.Counter(r['scan_role'] for r in rows)=={'head':1296,'parent':18},'head and common-parent denominators')
check(collections.Counter(r['concurrency'] for r in rows)=={'1':438,'2':438,'4':438},'438 gate attempts per concurrency scenario')
for item in changes:
 p=Path(item['head_path']);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()
 check(head==item['head_commit'],item['change_id']+' head unchanged')
 check(not subprocess.check_output(['git','status','--porcelain'],cwd=p,text=True).strip(),item['change_id']+' tracked source remains clean')
 check(Path(item['diff_path']).is_file() and Path(item['prompt_path']).is_file() and Path(item['terminal_trace']).is_file(),item['change_id']+' evidence files exist')
 result=json.loads((B/'preflight'/item['change_id']/'result.json').read_text())
 check(result['head_commit']==item['head_commit'],item['change_id']+' preflight exact-head match')
 check(sum(r['change_id']==item['change_id'] for r in rows)==54,item['change_id']+' six gates by three repeats by three concurrency levels')
for r in rows:
 if r['result_json_sha256']:check(sha(D/r['result_json_path'])==r['result_json_sha256'],r['attempt_id']+' result integrity')
 if r['diff_sha256']:check(sha(r['diff_path'])==r['diff_sha256'],r['attempt_id']+' diff integrity')
check(all(r['enforcement_mode']=='report_only' for r in rows),'all records report-only')
summary=json.loads((B/'measurement_summary/summary.json').read_text())
for entry in summary['pipeline_summary']:
 group=[r for r in rows if int(r['concurrency'])==entry['concurrency'] and r['scan_role']=='head'];reps=collections.defaultdict(list)
 for r in group:reps[(r['change_id'],r['repetition'])].append(float(r['wall_seconds']))
 values=sorted(sum(v) for v in reps.values());p=(len(values)-1)*.95;lo=math.floor(p);hi=math.ceil(p);q=values[lo]+(values[hi]-values[lo])*(p-lo)
 check(len(values)==72,'72 head repetitions for concurrency '+str(entry['concurrency']))
 check(abs(statistics.median(values)-entry['attempted_head_repetition_gate_wall_sum_seconds_median'])<1e-9,'independent median cross-check c'+str(entry['concurrency']))
 check(abs(q-entry['attempted_head_repetition_gate_wall_sum_seconds_p95'])<1e-9,'independent p95 cross-check c'+str(entry['concurrency']))
journal=[json.loads(line) for line in (D/'gate_runs.jsonl').read_text().splitlines()]
csv_ids={r['attempt_id'] for r in rows};journal_ids={r['attempt_id'] for r in journal}
check(not (journal_ids-csv_ids),'no journal attempt absent from final CSV')
check(all(r['result_json_sha256'] for r in rows),'every CSV attempt has a recorded result hash')
missing=sorted(csv_ids-journal_ids)
report={'status':'passed_with_documented_journal_discrepancy' if missing else 'passed','append_journal_records':len(journal),'append_journal_missing_attempt_ids':missing,'canonical_measurement_table':'gate_runs.csv','check_count':len(checks),'status_counts':dict(collections.Counter(r['measurement_status'] for r in rows)),'scope':'integrity and arithmetic audit, not task acceptance or human adjudication','checks':checks}
(B/'experiment_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'}))
