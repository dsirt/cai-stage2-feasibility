from pathlib import Path
import subprocess,json
B=Path('/workspace/scratch/6d54e12a9ca2/work');repo=B/'benchmark';base='8858837c4dad57fb3b2083d1f5e9afcb88d3e1f2'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=repo,text=True).splitlines();rows=[]
for f in files:
 if not f.endswith('.cs'):continue
 s=subprocess.check_output(['git','show',base+':'+f],cwd=repo,text=True).splitlines()
 rows.append({'path':f,'scope':'tests' if f.startswith('src/Tests/') else 'implementation','physical_lines':len(s),'nonblank_lines':sum(bool(x.strip()) for x in s)})
summary={k:{m:sum(x[m] for x in rows if x['scope']==k) for m in ['physical_lines','nonblank_lines']} for k in ['implementation','tests']}
(B/'baseline_line_inventory.json').write_text(json.dumps({'base_commit':base,'definition':'git tracked C# files at the frozen commit, splitlines physical lines and stripped nonblank lines, not lexical NCLOC','summary':summary,'files':rows},indent=2));print(json.dumps(summary))
