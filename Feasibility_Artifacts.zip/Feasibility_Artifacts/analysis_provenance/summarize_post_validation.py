from pathlib import Path
import argparse, csv, json, collections

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,default=Path(__file__).parent/'post_generation_validation')
root=p.parse_args().root.resolve()
t1=json.loads((root/'T1/summary.json').read_text())
t2=json.loads((root/'T2/summary.json').read_text())
t3=list(csv.DictReader((root/'T3/case_results.csv').open()))
manifest_path=root.parent/'experiment_manifest.json'
if not manifest_path.exists():manifest_path=root.parent/'records/experiment_manifest.json'
manifest=json.loads(manifest_path.read_text())
heads={x['change_id']:x['head_commit'] for x in manifest['changes']}
groups=[]
for category,n in [('behavior',23),('architecture',3)]:
 entries=[r for r in t1['runs'] if r['change_id']!='BASELINE']
 assert len(entries)==8
 counts=collections.Counter()
 for r in entries:
  assert heads[r['change_id']]==r['head_commit']
  counts.update(r['counts'][category])
 assert sum(counts.values())==8*n
 groups.append({'task':'T1','scope':category,'cases_per_change':n,'changes':8,**dict(counts)})
assert t2['authoritative_campaign']=='attempt4' and len(t2['per_head'])==8
counts=collections.Counter()
for r in t2['per_head']:
 assert heads[r['head']]==r['commit']
 assert r['build_exit']==0 and r['checks']==9
 for k in ['pass','fail','unsupported_api','not_evaluable']:counts[k]+=r[k]
groups.append({'task':'T2','scope':'behavior','cases_per_change':9,'changes':8,
 'passed':counts['pass'],'failed':counts['fail'],'not_evaluable':counts['not_evaluable'],'unsupported_api':counts['unsupported_api']})
assert len({(r['run_id'],r['case_id']) for r in t3})==len(t3)==108
for category,ids in [('behavior',{f'T3-{i:02d}' for i in range(1,11)}),('conditional_update_probe',{'T3-11','T3-12'})]:
 entries=[r for r in t3 if r['run_id']!='BASELINE' and r['case_id'] in ids]
 assert len(entries)==8*len(ids)
 for r in entries:assert heads[r['run_id']]==r['source_commit']
 counts=collections.Counter(r['status'] for r in entries)
 groups.append({'task':'T3','scope':category,'cases_per_change':len(ids),'changes':8,
 'passed':counts['pass'],'failed':counts['fail'],'not_evaluable':counts['not_evaluable'],
 'not_exercised':counts['not_exercised']})
summary={'design':'retrospective unblinded AI-assisted external checks after generation and gate measurement',
 'independent_agent_changes':24,'candidate_case_observations':sum(x['cases_per_change']*x['changes'] for x in groups),
 'groups':groups,'human_adjudication':False,'preregistered':False,
 'baseline_controls':{'T1':next(x['counts'] for x in t1['runs'] if x['change_id']=='BASELINE'),
 'T2':t2['baseline'],'T3':dict(collections.Counter(r['status'] for r in t3 if r['run_id']=='BASELINE'))},
 'limitations':['Finite selected checks do not establish complete task acceptance.',
 'Evaluators inspected retained source. These checks were not frozen before agent generation.',
 'T1 constructor compatibility and production composition root were not scored.',
 'T3 conditional-update probes are algorithm-specific and separate from common requirements.',
 'T2 final campaign follows a documented evaluator constructor-binding correction. Earlier attempts remain retained.',
 'No branch-coverage, mutation, diagnostic-accuracy or human-review-time result is inferred.']}
assert summary['candidate_case_observations']==376
assert all(x['failed']==0 and x['not_evaluable']==0 and x['passed']==x['cases_per_change']*x['changes'] for x in groups)
(root/'combined_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (root/'combined_summary.csv').open('w',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=['task','scope','cases_per_change','changes','passed','failed','not_evaluable','unsupported_api','not_exercised'])
 writer.writeheader();writer.writerows(groups)
print(json.dumps({'candidate_case_observations':summary['candidate_case_observations'],'groups':groups},indent=2))
