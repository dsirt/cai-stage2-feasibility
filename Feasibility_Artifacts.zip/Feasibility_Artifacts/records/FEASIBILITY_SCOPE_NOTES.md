# Evidence scope and baseline documentation correction

The recorded benchmark is synthetic and test-heavy. Its 17,914 physical C# lines comprise 1,895 implementation lines and 16,019 test lines. Physical and nonblank line counts are not lexical NCLOC. Generated repetition does not establish industrial representativeness.

The frozen baseline README says task-specific hidden acceptance checks are kept outside the repository. At agent generation and gate measurement, the external materials contained an acceptance contract and fixture specification, not a completed executable hidden acceptance harness. A later retrospective evaluation adds selected external task checks. These checks were written after generation, with access to retained source, and are documented separately under post_generation_validation. They were not a hidden oracle frozen before generation, and they do not establish complete task acceptance. The immutable baseline is retained to preserve the exact inputs used by the agent runs. This note corrects that documentation wording without changing the experimental source snapshot.

Public regression tests, including two compiled assembly-reference checks, are executed separately from the timed gate replay. The timed architecture gate is a custom project-reference and namespace-syntax check. These scopes must not be conflated.

All reported findings are tool or policy signals. No independent human adjudication, false-positive estimate, missed-defect estimate, reviewer time, participant study, longitudinal deployment, or validation of the complete CAI framework is claimed. No branch-coverage or mutation score is claimed for the engineering demonstration.

The service exposed a Codex agent interface through ChatGPT, but did not expose an immutable backend model version or sampling settings. Full prompts, submitted source snapshots, command/output traces, and pinned analysis tools support replay of the retained changes. They do not guarantee regeneration of identical model outputs.
