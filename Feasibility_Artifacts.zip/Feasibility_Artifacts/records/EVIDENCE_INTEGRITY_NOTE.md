# Evidence integrity note

The completed runner reported 1,314 gate attempts. Its final `gate_runs.csv`, exported from the completed in-memory record list, contains 1,314 unique attempt IDs. Each has an analyzer result file whose SHA-256 matches the hash recorded in the CSV. All 24 source heads and diff hashes were checked against the frozen manifest.

The separately appended `gate_runs.jsonl` journal contains 1,300 unique records. Fourteen attempt IDs present in the complete CSV are absent from that journal. No extra journal IDs or invalid JSON lines were found. The cause of this append-journal discrepancy was not established. It is a logging-integrity anomaly, distinct from an analyzer failure.

The original journal is retained unchanged. No missing measurement was fabricated or estimated. All numerical analyses use the complete final CSV and the retained per-attempt result files. `experiment_verification.json` records the discrepancy and the missing attempt IDs, alongside source-integrity and arithmetic checks. No repeat experiment was substituted for the recorded run.
