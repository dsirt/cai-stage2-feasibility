using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class DocumentService<T>(IDatabaseSession session) where T : BusinessDocument
{
    public Task<T> CreateAsync(T document, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            document.Validate();
            if (document.Status != DocumentStatus.Draft)
                throw new DomainValidationException("New documents must be drafts.");
            if (await session.FindAsync<T>(document.Id, token) is not null)
                throw new DomainValidationException("Duplicate document id.");
            if ((await session.ListAsync<T>(token)).Any(x => x.Code == document.Code))
                throw new DomainValidationException("Duplicate document code.");
            var saved = (T)(document with { Version = 1 });
            await session.SaveAsync(saved, token);
            return saved;
        }, cancellationToken);

    public async Task<T> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<T>(id, cancellationToken)
            ?? throw new MissingEntityException($"{typeof(T).Name} {id} was not found.");

    public Task<IReadOnlyList<T>> ListAsync(CancellationToken cancellationToken = default)
        => session.ListAsync<T>(cancellationToken);

    public Task<T> UpdateDraftAsync(T replacement, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(replacement.Id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Only drafts may be edited.");
            if (replacement.Status != current.Status) throw new DomainValidationException("Use TransitionAsync to change status.");
            replacement.Validate();
            if ((await session.ListAsync<T>(token)).Any(x => x.Id != replacement.Id && x.Code == replacement.Code))
                throw new DomainValidationException("Duplicate document code.");
            var saved = (T)(replacement with { Version = checked(current.Version + 1) });
            await session.SaveAsync(saved, token);
            return saved;
        }, cancellationToken);

    public Task<T> TransitionAsync(string id, DocumentStatus target, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            var updated = (T)current.NextStatus(target);
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<bool> DeleteDraftAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Only drafts may be deleted.");
            await session.DeleteAsync<T>(id, token);
            return true;
        }, cancellationToken);
}
