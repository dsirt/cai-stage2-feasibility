using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class InventoryService(IDatabaseSession session, IReservationObserver observer)
{
    public Task<InventoryItem> CreateAsync(InventoryItem item, CancellationToken cancellationToken = default)
        => new DocumentService<InventoryItem>(session).CreateAsync(item, cancellationToken);

    public async Task<InventoryItem> GetAsync(string sku, CancellationToken cancellationToken = default)
        => await session.FindAsync<InventoryItem>(sku, cancellationToken)
            ?? throw new MissingEntityException($"Inventory item {sku} was not found.");

    public async Task<ReservationResult> ReserveAsync(string sku, int quantity, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (quantity <= 0) throw new DomainValidationException("Reservation quantity must be positive.");
        var current = await GetAsync(sku, cancellationToken);
        if (current.Available < quantity) return new(false, "InsufficientStock", current.Available, current.Version);
        await observer.AfterReadAsync(current, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        var updated = current with { Reserved = checked(current.Reserved + quantity), Version = checked(current.Version + 1) };
        updated.Validate();
        await session.SaveAsync(updated, cancellationToken);
        return new(true, "Reserved", updated.Available, updated.Version);
    }

    public Task<InventoryItem> ReleaseAsync(string sku, int quantity, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            if (quantity <= 0) throw new DomainValidationException("Release quantity must be positive.");
            var current = await GetAsync(sku, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Inventory changed.");
            if (quantity > current.Reserved) throw new DomainValidationException("Release exceeds reservation.");
            var updated = current with { Reserved = current.Reserved - quantity, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<InventoryItem> AdjustAsync(string sku, int newOnHand, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(sku, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Inventory changed.");
            var updated = current with { OnHand = newOnHand, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);
}
