using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class SalesOrderService(IDatabaseSession session, IAuditSink auditSink, IClock clock)
{
    public Task<SalesOrder> CreateAsync(SalesOrder order, CancellationToken cancellationToken = default)
        => new DocumentService<SalesOrder>(session).CreateAsync(order, cancellationToken);

    public async Task<SalesOrder> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<SalesOrder>(id, cancellationToken)
            ?? throw new MissingEntityException($"Sales order {id} was not found.");

    public Task<SalesOrder> UpdateDescriptionAsync(string id, string description, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (current.Status is DocumentStatus.Closed or DocumentStatus.Cancelled)
                throw new DomainValidationException("A terminal order cannot be edited.");
            var updated = current with { Description = description, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<SalesOrder> ChangeAmountAsync(string id, decimal amount, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Amount changes require a draft.");
            var updated = current with { Amount = amount, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<SalesOrder> SubmitAsync(string id, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            var updated = (SalesOrder)current.NextStatus(DocumentStatus.Submitted);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);
}
