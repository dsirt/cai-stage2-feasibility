using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class PurchaseOrderService(IDatabaseSession session)
{
    public Task<PurchaseOrder> CreateAsync(PurchaseOrder order, CancellationToken cancellationToken = default)
        => new DocumentService<PurchaseOrder>(session).CreateAsync(order, cancellationToken);

    public async Task<PurchaseOrder> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<PurchaseOrder>(id, cancellationToken)
            ?? throw new MissingEntityException($"Purchase order {id} was not found.");

    public async Task<IReadOnlyList<PurchaseOrderLine>> GetLinesAsync(string orderId, CancellationToken cancellationToken = default)
        => (await session.ListAsync<PurchaseOrderLine>(cancellationToken))
            .Where(x => x.OrderId == orderId).OrderBy(x => x.Code, StringComparer.Ordinal).ToArray();

    public Task<PurchaseOrder> AddLineAsync(PurchaseOrderLine line, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            line.Validate();
            var order = await GetAsync(line.OrderId, token);
            RequireEditable(order, expectedVersion);
            if (await session.FindAsync<PurchaseOrderLine>(line.Id, token) is not null)
                throw new DomainValidationException("Duplicate order line id.");
            var lines = await GetLinesAsync(order.Id, token);
            if (lines.Any(x => x.Code == line.Code)) throw new DomainValidationException("Duplicate order line code.");
            var total = decimal.Round((lines.Sum(x => x.NetTotal) + line.NetTotal) * (1 - order.DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
            var updated = order with { Amount = total, Version = checked(order.Version + 1) };
            updated.Validate();
            await session.SaveAsync(line with { Version = 1, Amount = line.NetTotal }, token);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> RemoveLineAsync(string orderId, string lineId, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(orderId, token);
            RequireEditable(order, expectedVersion);
            var line = await session.FindAsync<PurchaseOrderLine>(lineId, token)
                ?? throw new MissingEntityException("Order line was not found.");
            if (line.OrderId != orderId) throw new DomainValidationException("Line belongs to a different order.");
            var remaining = (await GetLinesAsync(orderId, token)).Where(x => x.Id != lineId);
            var total = decimal.Round(remaining.Sum(x => x.NetTotal) * (1 - order.DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
            var updated = order with { Amount = total, Version = checked(order.Version + 1) };
            await session.DeleteAsync<PurchaseOrderLine>(lineId, token);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> SubmitAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(id, token);
            RequireEditable(order, expectedVersion);
            if ((await GetLinesAsync(id, token)).Count == 0)
                throw new DomainValidationException("An order requires at least one line before submission.");
            var updated = (PurchaseOrder)order.NextStatus(DocumentStatus.Submitted);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> ApproveAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(id, token);
            if (order.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (order.Status != DocumentStatus.Submitted) throw new DomainValidationException("Only submitted orders may be approved.");
            var updated = (PurchaseOrder)order.NextStatus(DocumentStatus.Approved);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    private static void RequireEditable(PurchaseOrder order, int expectedVersion)
    {
        if (order.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
        if (order.Status != DocumentStatus.Draft) throw new DomainValidationException("Only draft orders may be edited.");
    }
}
