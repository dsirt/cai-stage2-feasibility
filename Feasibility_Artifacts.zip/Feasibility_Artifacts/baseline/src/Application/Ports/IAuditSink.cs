using Benchmark.Domain;
namespace Benchmark.Application;
public interface IAuditSink
{
    Task AppendAsync(AuditRecord record, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<AuditRecord>> ReadAllAsync(CancellationToken cancellationToken = default);
}
public interface IClock { DateTimeOffset UtcNow { get; } }
public sealed class SystemClock : IClock { public DateTimeOffset UtcNow => DateTimeOffset.UtcNow; }
public interface IReservationObserver
{
    Task AfterReadAsync(InventoryItem snapshot, CancellationToken cancellationToken = default);
}
public sealed class NoOpReservationObserver : IReservationObserver
{
    public Task AfterReadAsync(InventoryItem snapshot, CancellationToken cancellationToken = default)
        => Task.CompletedTask;
}
