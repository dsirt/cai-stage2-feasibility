using Benchmark.Domain;
namespace Benchmark.Application;

// Application-owned storage port. The in-memory adapter is deliberately replaceable.
public interface IDatabaseSession
{
    Task<T?> FindAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task SaveAsync<T>(T document, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task DeleteAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<bool> TryReplaceAsync<T>(T document, int expectedVersion, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<T> InTransactionAsync<T>(Func<CancellationToken, Task<T>> action, CancellationToken cancellationToken = default);
}
