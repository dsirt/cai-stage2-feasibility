using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record StockPlan(int ReorderPoint, int SuggestedQuantity, decimal StockValue);
public static class ProductCatalogPolicy
{
    public static decimal ConvertQuantity(decimal quantity, decimal unitsPerPack)
    {
        Rules.Range(quantity, 0, 100000000, nameof(quantity));
        if (unitsPerPack <= 0) throw new DomainValidationException("Conversion factor must be positive.");
        return quantity * unitsPerPack;
    }
    public static decimal UnitCost(decimal packageCost, int unitsPerPack)
    {
        Rules.Range(packageCost, 0, 1000000000, nameof(packageCost));
        Rules.Range(unitsPerPack, 1, 1000000, nameof(unitsPerPack));
        return decimal.Round(packageCost / unitsPerPack, 4, MidpointRounding.AwayFromZero);
    }
    public static decimal GrossMarginPercent(Product product, decimal unitCost)
    {
        product.Validate();
        Rules.Range(unitCost, 0, 10000000, nameof(unitCost));
        if (product.UnitPrice == 0) return 0m;
        return decimal.Round((product.UnitPrice - unitCost) / product.UnitPrice * 100m, 2);
    }
    public static decimal ShipmentWeight(Product product, int quantity, decimal packagingWeight)
    {
        product.Validate();
        Rules.Range(quantity, 0, 1000000, nameof(quantity));
        Rules.Range(packagingWeight, 0, 100000, nameof(packagingWeight));
        return product.WeightKg * quantity + packagingWeight;
    }
    public static StockPlan Replenish(Product product, int onHand, int openOrders, decimal dailyDemand, int leadDays, int safetyStock, int targetDays)
    {
        product.Validate();
        Rules.Range(onHand, 0, 10000000, nameof(onHand));
        Rules.Range(openOrders, 0, 10000000, nameof(openOrders));
        Rules.Range(dailyDemand, 0, 100000, nameof(dailyDemand));
        Rules.Range(leadDays, 0, 365, nameof(leadDays));
        Rules.Range(safetyStock, 0, 1000000, nameof(safetyStock));
        Rules.Range(targetDays, leadDays, 730, nameof(targetDays));
        var reorder = checked((int)decimal.Ceiling(dailyDemand * leadDays) + safetyStock);
        var target = checked((int)decimal.Ceiling(dailyDemand * targetDays) + safetyStock);
        var available = checked(onHand + openOrders);
        var suggested = available <= reorder ? Math.Max(0, target - available) : 0;
        return new(reorder, suggested, onHand * product.UnitPrice);
    }
}
