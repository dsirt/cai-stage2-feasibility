using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public enum ContractPhase { NotStarted, Active, Expired, Cancelled }
public sealed record ContractRenewal(DateOnly Start, DateOnly End, decimal Amount, DateOnly DecisionDeadline);
public sealed record ContractTermination(int UsedDays, int UnusedDays, decimal EarnedAmount, decimal Refund, decimal Penalty);

public static class ContractPolicy
{
    public static int DurationDays(Contract contract)
    {
        ArgumentNullException.ThrowIfNull(contract);
        contract.Validate();
        return contract.EndDate.DayNumber - contract.StartDate.DayNumber + 1;
    }

    public static ContractPhase Phase(Contract contract, DateOnly asOf)
    {
        contract.Validate();
        if (contract.Status == DocumentStatus.Cancelled) return ContractPhase.Cancelled;
        if (asOf < contract.StartDate) return ContractPhase.NotStarted;
        return asOf > contract.EndDate ? ContractPhase.Expired : ContractPhase.Active;
    }

    public static DateOnly NoticeDeadline(Contract contract)
    {
        contract.Validate();
        return contract.EndDate.AddDays(-contract.NoticeDays);
    }

    public static bool IsRenewalWindow(Contract contract, DateOnly asOf, int openingDays)
    {
        Rules.Range(openingDays, 0, 730, nameof(openingDays));
        contract.Validate();
        if (openingDays < contract.NoticeDays) throw new DomainValidationException("Renewal window opens after notice deadline.");
        return Phase(contract, asOf) == ContractPhase.Active &&
            asOf >= contract.EndDate.AddDays(-openingDays) && asOf <= NoticeDeadline(contract);
    }

    public static ContractRenewal Renew(Contract contract, DateOnly decisionOn, int months, decimal priceIncreaseRate)
    {
        contract.Validate();
        Rules.Range(months, 1, 120, nameof(months));
        Rules.Range(priceIncreaseRate, -1, 10, nameof(priceIncreaseRate));
        if (Phase(contract, decisionOn) != ContractPhase.Active || decisionOn > NoticeDeadline(contract))
            throw new DomainValidationException("Renewal decision is outside the active notice period.");
        var start = contract.EndDate.AddDays(1);
        var end = start.AddMonths(months).AddDays(-1);
        var amount = decimal.Round(contract.Amount * (1 + priceIncreaseRate), 2, MidpointRounding.AwayFromZero);
        if (amount > 1_000_000_000m) throw new DomainValidationException("Renewal amount exceeds the supported range.");
        return new(start, end, amount, end.AddDays(-contract.NoticeDays));
    }

    public static decimal EarnedAmount(Contract contract, DateOnly asOf)
    {
        var duration = DurationDays(contract);
        var elapsed = Math.Clamp(asOf.DayNumber - contract.StartDate.DayNumber + 1, 0, duration);
        return elapsed == duration ? contract.Amount : decimal.Round(contract.Amount * elapsed / duration, 2, MidpointRounding.AwayFromZero);
    }

    public static ContractTermination Terminate(Contract contract, DateOnly effectiveOn, DateOnly noticeOn, decimal penaltyRate)
    {
        var duration = DurationDays(contract);
        Rules.Range(penaltyRate, 0, 1, nameof(penaltyRate));
        if (contract.Status == DocumentStatus.Cancelled) throw new DomainValidationException("Contract is already cancelled.");
        if (effectiveOn < contract.StartDate || effectiveOn > contract.EndDate)
            throw new DomainValidationException("Termination must fall within the contract term.");
        if (noticeOn > effectiveOn) throw new DomainValidationException("Notice follows termination.");
        var used = effectiveOn.DayNumber - contract.StartDate.DayNumber + 1;
        var earned = EarnedAmount(contract, effectiveOn);
        var unearned = contract.Amount - earned;
        var shortNotice = effectiveOn.DayNumber - noticeOn.DayNumber < contract.NoticeDays;
        var penalty = shortNotice ? decimal.Round(unearned * penaltyRate, 2, MidpointRounding.AwayFromZero) : 0;
        return new(used, duration - used, earned, unearned - penalty, penalty);
    }

    public static bool Overlaps(Contract first, Contract second)
    {
        first.Validate();
        second.Validate();
        if (first.Status == DocumentStatus.Cancelled || second.Status == DocumentStatus.Cancelled) return false;
        return first.StartDate <= second.EndDate && second.StartDate <= first.EndDate;
    }

    public static int DaysUntilNotice(Contract contract, DateOnly asOf) => NoticeDeadline(contract).DayNumber - asOf.DayNumber;

    public static decimal RemainingCommitment(Contract contract, DateOnly asOf)
    {
        if (Phase(contract, asOf) == ContractPhase.Cancelled) return 0;
        return contract.Amount - EarnedAmount(contract, asOf);
    }
}
