using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public enum InvoiceAgingBucket { Current, Days1To30, Days31To60, Days61To90, Over90 }
public sealed record InvoiceAllocation(string InvoiceId, decimal Amount);
public sealed record InvoiceAllocationPlan(IReadOnlyList<InvoiceAllocation> Allocations, decimal Unallocated);
public sealed record InvoiceBalance(decimal Total, decimal Paid, decimal Outstanding, int DaysPastDue, InvoiceAgingBucket Bucket);

public static class InvoicePolicy
{
    public static decimal Total(Invoice invoice)
    {
        ArgumentNullException.ThrowIfNull(invoice);
        invoice.Validate();
        return invoice.Amount + invoice.TaxAmount;
    }

    public static decimal Outstanding(Invoice invoice) => Total(invoice) - invoice.PaidAmount;

    public static int DaysPastDue(Invoice invoice, DateOnly asOf)
    {
        invoice.Validate();
        return Outstanding(invoice) == 0 ? 0 : Math.Max(0, asOf.DayNumber - invoice.DueDate.DayNumber);
    }

    public static InvoiceAgingBucket Aging(Invoice invoice, DateOnly asOf)
    {
        var days = DaysPastDue(invoice, asOf);
        return days switch
        {
            0 => InvoiceAgingBucket.Current,
            <= 30 => InvoiceAgingBucket.Days1To30,
            <= 60 => InvoiceAgingBucket.Days31To60,
            <= 90 => InvoiceAgingBucket.Days61To90,
            _ => InvoiceAgingBucket.Over90
        };
    }

    public static InvoiceBalance Balance(Invoice invoice, DateOnly asOf) =>
        new(Total(invoice), invoice.PaidAmount, Outstanding(invoice), DaysPastDue(invoice, asOf), Aging(invoice, asOf));

    public static decimal Interest(Invoice invoice, DateOnly asOf, decimal annualRate, int graceDays = 0)
    {
        Rules.Range(annualRate, 0, 1, nameof(annualRate));
        Rules.Range(graceDays, 0, 365, nameof(graceDays));
        var chargeableDays = Math.Max(0, DaysPastDue(invoice, asOf) - graceDays);
        // Fixture convention: simple interest, actual elapsed days over a fixed 365-day year.
        return decimal.Round(Outstanding(invoice) * annualRate * chargeableDays / 365m, 2, MidpointRounding.AwayFromZero);
    }

    public static Invoice ApplyPayment(Invoice invoice, decimal amount)
    {
        var remaining = Outstanding(invoice);
        if (invoice.Status is DocumentStatus.Cancelled or DocumentStatus.Closed)
            throw new DomainValidationException("Invoice is not open for payment.");
        if (amount <= 0 || amount > remaining)
            throw new DomainValidationException("Payment must be positive and no greater than the open balance.");
        return invoice with { PaidAmount = invoice.PaidAmount + amount, Version = checked(invoice.Version + 1) };
    }

    public static InvoiceAllocationPlan Allocate(IEnumerable<Invoice> invoices, decimal amount, string currency)
    {
        ArgumentNullException.ThrowIfNull(invoices);
        if (amount < 0) throw new DomainValidationException("Allocation cannot be negative.");
        ValidateCurrency(currency);
        var input = invoices.ToArray();
        if (input.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != input.Length)
            throw new DomainValidationException("Duplicate invoice identities.");
        foreach (var invoice in input)
        {
            invoice.Validate();
            if (invoice.Currency != currency) throw new DomainValidationException("Allocation currency mismatch.");
        }
        var allocations = new List<InvoiceAllocation>();
        var remaining = amount;
        foreach (var invoice in input.OrderBy(x => x.DueDate).ThenBy(x => x.Id, StringComparer.Ordinal))
        {
            if (invoice.Status is DocumentStatus.Cancelled or DocumentStatus.Closed) continue;
            var applied = Math.Min(remaining, Outstanding(invoice));
            if (applied > 0) allocations.Add(new(invoice.Id, applied));
            remaining -= applied;
            if (remaining == 0) break;
        }
        return new(allocations.AsReadOnly(), remaining);
    }

    public static IReadOnlyDictionary<InvoiceAgingBucket, decimal> AgingTotals(IEnumerable<Invoice> invoices, DateOnly asOf, string currency)
    {
        ValidateCurrency(currency);
        var result = Enum.GetValues<InvoiceAgingBucket>().ToDictionary(x => x, _ => 0m);
        foreach (var invoice in invoices)
        {
            invoice.Validate();
            if (invoice.Currency != currency) throw new DomainValidationException("Statement currency mismatch.");
            if (invoice.Status != DocumentStatus.Cancelled) result[Aging(invoice, asOf)] += Outstanding(invoice);
        }
        return new System.Collections.ObjectModel.ReadOnlyDictionary<InvoiceAgingBucket, decimal>(result);
    }

    private static void ValidateCurrency(string currency)
    {
        if (currency is null || currency.Length != 3 || currency.Any(c => c is < 'A' or > 'Z'))
            throw new DomainValidationException("Currency must contain three uppercase letters.");
    }
}
