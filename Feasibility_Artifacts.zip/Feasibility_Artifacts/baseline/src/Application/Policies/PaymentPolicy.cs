using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public sealed record PaymentFeeSchedule(decimal TransferFlat, decimal CardFlat, decimal CardRate);
public sealed record PaymentRefund(decimal Gross, decimal ReversedFee, decimal Net, decimal RemainingRefundable);
public sealed record PaymentSettlement(string PaymentId, string InvoiceId, decimal Credited, decimal RemainingInvoiceBalance);

public static class PaymentPolicy
{
    public static decimal CalculateFee(string method, decimal gross, PaymentFeeSchedule schedule)
    {
        ArgumentNullException.ThrowIfNull(schedule);
        Rules.Range(gross, 0, 1_000_000_000m, nameof(gross));
        Rules.Range(schedule.TransferFlat, 0, 1_000_000m, nameof(schedule.TransferFlat));
        Rules.Range(schedule.CardFlat, 0, 1_000_000m, nameof(schedule.CardFlat));
        Rules.Range(schedule.CardRate, 0, 1, nameof(schedule.CardRate));
        var fee = method switch
        {
            "Transfer" => schedule.TransferFlat,
            "Card" => schedule.CardFlat + gross * schedule.CardRate,
            "Cash" => 0m,
            _ => throw new DomainValidationException("Unsupported payment method.")
        };
        return Math.Min(gross, decimal.Round(fee, 2, MidpointRounding.AwayFromZero));
    }

    public static decimal NetAmount(Payment payment)
    {
        ArgumentNullException.ThrowIfNull(payment);
        payment.Validate();
        return payment.Amount - payment.Fee;
    }

    public static PaymentSettlement Settle(Payment payment, Invoice invoice)
    {
        var net = NetAmount(payment);
        invoice.Validate();
        if (payment.InvoiceId != invoice.Id) throw new DomainValidationException("Payment targets another invoice.");
        if (payment.Currency != invoice.Currency) throw new DomainValidationException("Settlement currency mismatch.");
        if (payment.Status is not (DocumentStatus.Approved or DocumentStatus.Fulfilled))
            throw new DomainValidationException("Payment has not been approved.");
        if (invoice.Status is DocumentStatus.Cancelled or DocumentStatus.Closed)
            throw new DomainValidationException("Invoice is not open.");
        var remaining = InvoicePolicy.Outstanding(invoice);
        if (net <= 0 || net > remaining) throw new DomainValidationException("Net settlement is outside the open balance.");
        return new(payment.Id, invoice.Id, net, remaining - net);
    }

    public static PaymentRefund Refund(Payment payment, decimal alreadyRefunded, decimal requested, bool reverseFee)
    {
        payment.Validate();
        if (payment.Status is not (DocumentStatus.Fulfilled or DocumentStatus.Closed))
            throw new DomainValidationException("Only settled payments can be refunded.");
        if (alreadyRefunded < 0 || alreadyRefunded > payment.Amount)
            throw new DomainValidationException("Refund history is outside the payment amount.");
        if (requested <= 0 || requested > payment.Amount - alreadyRefunded)
            throw new DomainValidationException("Refund exceeds remaining refundable amount.");
        // A cumulative difference allocates rounding residue to later refunds.
        var before = decimal.Round(payment.Fee * alreadyRefunded / payment.Amount, 2, MidpointRounding.AwayFromZero);
        var after = decimal.Round(payment.Fee * (alreadyRefunded + requested) / payment.Amount, 2, MidpointRounding.AwayFromZero);
        var reversedFee = reverseFee ? after - before : 0m;
        return new(requested, reversedFee, requested - reversedFee, payment.Amount - alreadyRefunded - requested);
    }

    public static decimal Convert(decimal amount, string fromCurrency, string toCurrency, decimal rate)
    {
        Rules.Range(amount, 0, 1_000_000_000m, nameof(amount));
        foreach (var currency in new[] { fromCurrency, toCurrency })
            if (currency is null || currency.Length != 3 || currency.Any(c => c is < 'A' or > 'Z'))
                throw new DomainValidationException("Invalid currency.");
        if (rate <= 0 || rate > 1_000_000m) throw new DomainValidationException("Invalid exchange rate.");
        if (fromCurrency == toCurrency && rate != 1m)
            throw new DomainValidationException("Same-currency conversion requires rate one.");
        return decimal.Round(amount * rate, 2, MidpointRounding.AwayFromZero);
    }

    public static DateOnly SettlementDate(DateOnly initiated, int businessDays)
    {
        Rules.Range(businessDays, 0, 30, nameof(businessDays));
        var date = initiated;
        while (businessDays > 0)
        {
            date = date.AddDays(1);
            if (date.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday)) businessDays--;
        }
        // Zero-day settlement on a weekend moves to the next weekday.
        while (date.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday) date = date.AddDays(1);
        return date;
    }

    public static bool IsDuplicate(Payment candidate, IEnumerable<Payment> existing)
    {
        candidate.Validate();
        return existing.Any(x => x.Id != candidate.Id && x.Status != DocumentStatus.Cancelled &&
            x.InvoiceId == candidate.InvoiceId && x.Method == candidate.Method &&
            string.Equals(x.Reference.Trim(), candidate.Reference.Trim(), StringComparison.OrdinalIgnoreCase));
    }
}
