using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record ShippingQuote(decimal BaseCost, decimal FuelSurcharge, decimal Insurance, decimal Total);
public static class ShipmentPlanningPolicy
{
    public static DateOnly AddWorkingDays(DateOnly date, int days, IReadOnlySet<DateOnly> holidays)
    {
        Rules.Range(days, 0, 730, nameof(days));
        var current = date;
        while (days > 0)
        {
            current = current.AddDays(1);
            if (current.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday) && !holidays.Contains(current)) days--;
        }
        return current;
    }
    public static ShippingQuote Quote(decimal weightKg, decimal distanceKm, decimal baseFee, decimal perKgKm, decimal fuelPercent, decimal declaredValue, decimal insurancePercent)
    {
        Rules.Range(weightKg, 0, 1000000, nameof(weightKg));
        Rules.Range(distanceKm, 0, 100000, nameof(distanceKm));
        Rules.Range(baseFee, 0, 1000000, nameof(baseFee));
        Rules.Range(perKgKm, 0, 100, nameof(perKgKm));
        Rules.Range(fuelPercent, 0, 100, nameof(fuelPercent));
        Rules.Range(declaredValue, 0, 1000000000, nameof(declaredValue));
        Rules.Range(insurancePercent, 0, 100, nameof(insurancePercent));
        var cost = decimal.Round(baseFee + weightKg * distanceKm * perKgKm, 2, MidpointRounding.AwayFromZero);
        var fuel = decimal.Round(cost * fuelPercent / 100m, 2, MidpointRounding.AwayFromZero);
        var insurance = decimal.Round(declaredValue * insurancePercent / 100m, 2, MidpointRounding.AwayFromZero);
        return new(cost, fuel, insurance, cost + fuel + insurance);
    }
    public static int TransitDays(Shipment shipment)
    {
        shipment.Validate();
        return shipment.ArrivalDate.DayNumber - shipment.DispatchDate.DayNumber;
    }
    public static decimal DelayPenalty(Shipment shipment, DateOnly actualArrival, decimal dailyPercent, decimal maximumPercent)
    {
        shipment.Validate();
        Rules.Range(dailyPercent, 0, 100, nameof(dailyPercent));
        Rules.Range(maximumPercent, 0, 100, nameof(maximumPercent));
        var days = Math.Max(0, actualArrival.DayNumber - shipment.ArrivalDate.DayNumber);
        return decimal.Round(shipment.Amount * Math.Min(days * dailyPercent, maximumPercent) / 100m, 2, MidpointRounding.AwayFromZero);
    }
    public static bool CanDispatch(Shipment shipment, DateOnly date, bool goodsReady)
    {
        shipment.Validate();
        return goodsReady && shipment.Status == DocumentStatus.Approved && date >= shipment.DispatchDate;
    }
}
