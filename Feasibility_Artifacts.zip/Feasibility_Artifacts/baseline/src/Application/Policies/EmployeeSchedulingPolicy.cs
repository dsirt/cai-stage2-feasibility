using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record WorkEntry(DateOnly Date, decimal Hours, string Project);
public sealed record TimeSummary(decimal RegularHours, decimal OvertimeHours, decimal TotalHours, decimal Cost);
public static class EmployeeSchedulingPolicy
{
    // Parameters represent synthetic organization policy, not statutory employment rules.
    public static TimeSummary Summarize(Employee employee, IEnumerable<WorkEntry> entries, decimal hourlyRate, decimal overtimeMultiplier)
    {
        employee.Validate();
        Rules.Range(hourlyRate, 0, 1000000, nameof(hourlyRate));
        Rules.Range(overtimeMultiplier, 1, 10, nameof(overtimeMultiplier));
        var source = entries.ToArray();
        foreach (var entry in source)
        {
            Rules.Range(entry.Hours, 0, 24, nameof(entry.Hours));
            Rules.Required(entry.Project, nameof(entry.Project), 64);
            if (entry.Date < employee.HireDate) throw new DomainValidationException("Work entry precedes hire date.");
        }
        if (source.GroupBy(x => x.Date).Any(day => day.Sum(x => x.Hours) > 24))
            throw new DomainValidationException("A day cannot contain more than 24 hours.");
        if (source.Length > 0 && source.Max(x => x.Date).DayNumber - source.Min(x => x.Date).DayNumber > 6)
            throw new DomainValidationException("Summary must cover at most seven consecutive days.");
        var total = source.Sum(x => x.Hours);
        var regular = Math.Min(total, employee.WeeklyHours);
        var overtime = Math.Max(0, total - employee.WeeklyHours);
        var cost = decimal.Round((regular + overtime * overtimeMultiplier) * hourlyRate, 2, MidpointRounding.AwayFromZero);
        return new(regular, overtime, total, cost);
    }
    public static int CompletedServiceMonths(Employee employee, DateOnly asOf)
    {
        employee.Validate();
        if (asOf < employee.HireDate) return 0;
        var months = (asOf.Year - employee.HireDate.Year) * 12 + asOf.Month - employee.HireDate.Month;
        if (asOf.Day < employee.HireDate.Day) months--;
        return Math.Max(0, months);
    }
    public static decimal AccruedLeave(Employee employee, DateOnly asOf, decimal annualDays, decimal usedDays)
    {
        Rules.Range(annualDays, 0, 100, nameof(annualDays));
        Rules.Range(usedDays, 0, 100000, nameof(usedDays));
        return Math.Max(0, decimal.Round(CompletedServiceMonths(employee, asOf) * annualDays / 12m, 2) - usedDays);
    }
    public static bool CanAllocate(Employee employee, decimal alreadyAllocated, decimal newHours)
    {
        employee.Validate();
        Rules.Range(alreadyAllocated, 0, 168, nameof(alreadyAllocated));
        Rules.Range(newHours, 0, 168, nameof(newHours));
        return alreadyAllocated + newHours <= employee.WeeklyHours;
    }
}
