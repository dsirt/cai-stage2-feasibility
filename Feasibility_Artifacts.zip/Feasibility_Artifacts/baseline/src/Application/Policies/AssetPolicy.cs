using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public sealed record DepreciationPeriod(int Number, DateOnly Date, decimal Charge, decimal Accumulated, decimal BookValue);
public sealed record AssetDisposal(decimal BookValue, decimal Proceeds, decimal GainOrLoss);

public static class AssetPolicy
{
    public static decimal DepreciableBase(Asset asset)
    {
        ArgumentNullException.ThrowIfNull(asset);
        asset.Validate();
        RequireMoney(asset.Amount);
        RequireMoney(asset.SalvageValue);
        return asset.Amount - asset.SalvageValue;
    }

    public static int CompletedMonths(Asset asset, DateOnly asOf)
    {
        asset.Validate();
        if (asOf < asset.AcquisitionDate) return 0;
        var months = (asOf.Year - asset.AcquisitionDate.Year) * 12 + asOf.Month - asset.AcquisitionDate.Month;
        if (asset.AcquisitionDate.AddMonths(months) > asOf) months--;
        return Math.Clamp(months, 0, asset.UsefulLifeMonths);
    }

    public static decimal MonthlyCharge(Asset asset) =>
        decimal.Round(DepreciableBase(asset) / asset.UsefulLifeMonths, 2, MidpointRounding.ToZero);

    public static decimal AccumulatedDepreciation(Asset asset, DateOnly asOf)
    {
        var basis = DepreciableBase(asset);
        var completed = CompletedMonths(asset, asOf);
        if (completed == asset.UsefulLifeMonths) return basis;
        return Math.Min(basis, MonthlyCharge(asset) * completed);
    }

    public static decimal BookValue(Asset asset, DateOnly asOf) => asset.Amount - AccumulatedDepreciation(asset, asOf);

    public static int RemainingMonths(Asset asset, DateOnly asOf) => asset.UsefulLifeMonths - CompletedMonths(asset, asOf);

    public static IReadOnlyList<DepreciationPeriod> Schedule(Asset asset)
    {
        var basis = DepreciableBase(asset);
        var monthly = MonthlyCharge(asset);
        var periods = new List<DepreciationPeriod>(asset.UsefulLifeMonths);
        var accumulated = 0m;
        for (var month = 1; month <= asset.UsefulLifeMonths; month++)
        {
            // Final period absorbs division remainder; book value ends at salvage.
            var charge = month == asset.UsefulLifeMonths ? basis - accumulated : monthly;
            accumulated += charge;
            periods.Add(new(month, asset.AcquisitionDate.AddMonths(month), charge, accumulated, asset.Amount - accumulated));
        }
        return periods.AsReadOnly();
    }

    public static decimal DepreciationBetween(Asset asset, DateOnly startExclusive, DateOnly endInclusive)
    {
        if (endInclusive < startExclusive) throw new DomainValidationException("Depreciation interval is reversed.");
        return AccumulatedDepreciation(asset, endInclusive) - AccumulatedDepreciation(asset, startExclusive);
    }

    public static AssetDisposal Dispose(Asset asset, DateOnly date, decimal proceeds)
    {
        if (date < asset.AcquisitionDate) throw new DomainValidationException("Disposal precedes acquisition.");
        Rules.Range(proceeds, 0, 1_000_000_000m, nameof(proceeds));
        RequireMoney(proceeds);
        if (asset.Status == DocumentStatus.Cancelled) throw new DomainValidationException("Cancelled asset cannot be disposed.");
        var bookValue = BookValue(asset, date);
        return new(bookValue, proceeds, proceeds - bookValue);
    }

    public static decimal Impairment(Asset asset, DateOnly asOf, decimal recoverableAmount)
    {
        Rules.Range(recoverableAmount, 0, 1_000_000_000m, nameof(recoverableAmount));
        RequireMoney(recoverableAmount);
        var carrying = BookValue(asset, asOf);
        return Math.Max(0m, carrying - Math.Max(asset.SalvageValue, recoverableAmount));
    }

    public static decimal UtilizedLifePercent(Asset asset, DateOnly asOf)
    {
        var months = CompletedMonths(asset, asOf);
        return decimal.Round(100m * months / asset.UsefulLifeMonths, 2, MidpointRounding.AwayFromZero);
    }

    private static void RequireMoney(decimal amount)
    {
        if (decimal.Round(amount, 2) != amount)
            throw new DomainValidationException("Asset monetary inputs require at most two decimal places.");
    }
}
