using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public sealed record ReturnQuote(decimal Gross, decimal RestockingFee, decimal ShippingRefund, decimal Refund, bool RestockInventory);
public sealed record ReturnEligibility(bool Allowed, string Reason, int DaysSinceDelivery, int RemainingQuantity);

public static class ReturnAuthorizationPolicy
{
    public static ReturnEligibility Eligibility(ReturnAuthorization request, DateOnly deliveredOn, int deliveredQuantity,
        int previouslyReturned, int returnWindowDays)
    {
        ArgumentNullException.ThrowIfNull(request);
        request.Validate();
        Rules.Range(deliveredQuantity, 1, 1_000_000, nameof(deliveredQuantity));
        Rules.Range(previouslyReturned, 0, deliveredQuantity, nameof(previouslyReturned));
        Rules.Range(returnWindowDays, 0, 366, nameof(returnWindowDays));
        var age = request.BusinessDate.DayNumber - deliveredOn.DayNumber;
        var remaining = deliveredQuantity - previouslyReturned;
        if (request.Status is DocumentStatus.Cancelled or DocumentStatus.Closed)
            return new(false, "Authorization is not open.", age, remaining);
        if (age < 0) return new(false, "Return precedes delivery.", age, remaining);
        if (age > returnWindowDays) return new(false, "Return window has elapsed.", age, remaining);
        if (request.Quantity > remaining) return new(false, "Return exceeds delivered quantity still eligible.", age, remaining);
        return new(true, "Eligible.", age, remaining);
    }

    public static ReturnQuote Quote(ReturnAuthorization request, decimal unitPrice, decimal shippingPaid,
        bool fullOrderReturn, bool itemResalable)
    {
        request.Validate();
        Rules.Range(unitPrice, 0, 1_000_000_000m, nameof(unitPrice));
        Rules.Range(shippingPaid, 0, 1_000_000_000m, nameof(shippingPaid));
        var gross = decimal.Round(unitPrice * request.Quantity, 2, MidpointRounding.AwayFromZero);
        if (gross > request.Amount) throw new DomainValidationException("Refund gross exceeds authorized amount.");
        var sellerFault = request.Reason is "Damaged" or "WrongItem";
        var fee = sellerFault ? 0 : decimal.Round(gross * request.RestockingPercent / 100, 2, MidpointRounding.AwayFromZero);
        var shipping = sellerFault && fullOrderReturn ? shippingPaid : 0;
        return new(gross, fee, shipping, gross - fee + shipping, itemResalable && request.Reason != "Damaged");
    }

    public static decimal RefundRemaining(decimal captured, decimal alreadyRefunded, ReturnQuote quote)
    {
        Rules.Range(captured, 0, 1_000_000_000m, nameof(captured));
        if (alreadyRefunded < 0 || alreadyRefunded > captured) throw new DomainValidationException("Invalid refund history.");
        if (quote.Gross < 0 || quote.RestockingFee < 0 || quote.RestockingFee > quote.Gross || quote.ShippingRefund < 0 ||
            quote.Refund != quote.Gross - quote.RestockingFee + quote.ShippingRefund)
            throw new DomainValidationException("Refund quote is inconsistent.");
        if (quote.Refund > captured - alreadyRefunded) throw new DomainValidationException("Refund exceeds remaining captured amount.");
        return captured - alreadyRefunded - quote.Refund;
    }

    public static int RestockQuantity(ReturnAuthorization request, ReturnQuote quote)
    {
        request.Validate();
        if (request.Status is not (DocumentStatus.Approved or DocumentStatus.Fulfilled))
            throw new DomainValidationException("Return requires approval before receipt.");
        return quote.RestockInventory ? request.Quantity : 0;
    }

    public static decimal ProratedDiscount(decimal totalDiscount, int orderedQuantity, int returnedQuantity)
    {
        Rules.Range(totalDiscount, 0, 1_000_000_000m, nameof(totalDiscount));
        Rules.Range(orderedQuantity, 1, 1_000_000, nameof(orderedQuantity));
        Rules.Range(returnedQuantity, 0, orderedQuantity, nameof(returnedQuantity));
        return returnedQuantity == orderedQuantity ? totalDiscount :
            decimal.Round(totalDiscount * returnedQuantity / orderedQuantity, 2, MidpointRounding.AwayFromZero);
    }

    public static int RemainingReturnable(int deliveredQuantity, IEnumerable<ReturnAuthorization> returns, string orderId)
    {
        Rules.Range(deliveredQuantity, 0, 1_000_000, nameof(deliveredQuantity));
        Rules.Required(orderId, nameof(orderId), 64);
        var used = 0;
        var identities = new HashSet<string>(StringComparer.Ordinal);
        foreach (var request in returns)
        {
            request.Validate();
            if (!identities.Add(request.Id)) throw new DomainValidationException("Duplicate return authorization.");
            if (request.OrderId != orderId || request.Status is DocumentStatus.Draft or DocumentStatus.Cancelled) continue;
            used = checked(used + request.Quantity);
        }
        if (used > deliveredQuantity) throw new DomainValidationException("Existing returns exceed delivered quantity.");
        return deliveredQuantity - used;
    }
}
