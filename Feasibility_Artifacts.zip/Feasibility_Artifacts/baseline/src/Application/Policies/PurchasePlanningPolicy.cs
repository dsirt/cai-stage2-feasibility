using Benchmark.Domain;
namespace Benchmark.Application;

public sealed record SupplierOffer(string SupplierId, decimal UnitPrice, int LeadDays, decimal Reliability);
public sealed record ReceiptMatch(bool QuantityMatches, bool PriceMatches, decimal Difference, string Status);
public static class PurchasePlanningPolicy
{
    public static decimal NetTotal(IEnumerable<PurchaseOrderLine> lines, decimal discountPercent)
    {
        Rules.Range(discountPercent, 0, 100, nameof(discountPercent));
        var items = lines.ToArray();
        foreach (var line in items) line.Validate();
        return decimal.Round(items.Sum(x => x.NetTotal) * (1 - discountPercent / 100m), 2, MidpointRounding.AwayFromZero);
    }
    public static DateOnly LatestOrderDate(DateOnly requiredDate, int leadDays, int safetyDays)
    {
        Rules.Range(leadDays, 0, 730, nameof(leadDays));
        Rules.Range(safetyDays, 0, 365, nameof(safetyDays));
        return requiredDate.AddDays(-leadDays - safetyDays);
    }
    public static SupplierOffer SelectOffer(IEnumerable<SupplierOffer> offers, int maximumLeadDays, decimal minimumReliability)
    {
        Rules.Range(maximumLeadDays, 0, 730, nameof(maximumLeadDays));
        Rules.Range(minimumReliability, 0, 1, nameof(minimumReliability));
        var candidates = offers.ToArray();
        foreach (var offer in candidates)
        {
            Rules.Required(offer.SupplierId, nameof(offer.SupplierId), 64);
            Rules.Range(offer.UnitPrice, 0, 1000000, nameof(offer.UnitPrice));
            Rules.Range(offer.LeadDays, 0, 730, nameof(offer.LeadDays));
            Rules.Range(offer.Reliability, 0, 1, nameof(offer.Reliability));
        }
        return candidates.Where(x => x.LeadDays <= maximumLeadDays && x.Reliability >= minimumReliability)
            .OrderBy(x => x.UnitPrice).ThenBy(x => x.LeadDays).ThenBy(x => x.SupplierId, StringComparer.Ordinal)
            .FirstOrDefault() ?? throw new DomainValidationException("No qualifying supplier offer.");
    }
    public static ReceiptMatch MatchReceipt(int ordered, int received, decimal expectedPrice, decimal invoicePrice, decimal tolerancePercent)
    {
        Rules.Range(ordered, 1, 1000000, nameof(ordered));
        Rules.Range(received, 0, 1000000, nameof(received));
        Rules.Range(expectedPrice, 0, 1000000, nameof(expectedPrice));
        Rules.Range(invoicePrice, 0, 1000000, nameof(invoicePrice));
        Rules.Range(tolerancePercent, 0, 100, nameof(tolerancePercent));
        var difference = decimal.Abs(invoicePrice - expectedPrice);
        var priceMatches = difference <= expectedPrice * tolerancePercent / 100m;
        var quantityMatches = ordered == received;
        var state = quantityMatches && priceMatches ? "Matched" : received > ordered ? "OverReceived" : "Review";
        return new(quantityMatches, priceMatches, difference, state);
    }
    public static bool RequiresSecondApproval(PurchaseOrder order, decimal approvalLimit, bool newSupplier)
    {
        order.Validate();
        Rules.Range(approvalLimit, 0, 1000000000, nameof(approvalLimit));
        return order.Amount > approvalLimit || newSupplier;
    }
    public static int DelayDays(PurchaseOrder order, DateOnly asOf)
    {
        order.Validate();
        if (order.Status is DocumentStatus.Closed or DocumentStatus.Cancelled) return 0;
        return Math.Max(0, asOf.DayNumber - order.ExpectedDate.DayNumber);
    }
}
