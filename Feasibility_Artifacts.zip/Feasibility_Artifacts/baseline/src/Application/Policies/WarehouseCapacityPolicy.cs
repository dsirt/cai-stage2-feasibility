using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record StorageLot(string Id, int Quantity, DateOnly ReceivedOn, DateOnly ExpiresOn);
public sealed record PickLine(string LotId, int Quantity);
public static class WarehouseCapacityPolicy
{
    public static decimal UtilizationPercent(Warehouse warehouse, int occupied)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        return decimal.Round((decimal)occupied / warehouse.Capacity * 100m, 2);
    }
    public static bool CanReceive(Warehouse warehouse, int occupied, int incoming, decimal requiredMinimum, decimal requiredMaximum)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        Rules.Range(incoming, 0, 10000000, nameof(incoming));
        if (requiredMinimum > requiredMaximum) throw new DomainValidationException("Invalid storage temperature interval.");
        return (long)occupied + incoming <= warehouse.Capacity
            && warehouse.MinimumTemperature >= requiredMinimum && warehouse.MaximumTemperature <= requiredMaximum;
    }
    public static IReadOnlyList<PickLine> PickFirstExpiring(IEnumerable<StorageLot> lots, int requested, DateOnly asOf)
    {
        Rules.Range(requested, 1, 1000000, nameof(requested));
        var source = lots.ToArray();
        if (source.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != source.Length)
            throw new DomainValidationException("Lot identifiers must be unique.");
        foreach (var lot in source)
        {
            Rules.Required(lot.Id, nameof(lot.Id), 64);
            Rules.Range(lot.Quantity, 0, 1000000, nameof(lot.Quantity));
            Rules.DateOrder(lot.ReceivedOn, lot.ExpiresOn, nameof(lot.ExpiresOn));
        }
        var remaining = requested;
        var picks = new List<PickLine>();
        foreach (var lot in source.Where(x => x.ReceivedOn <= asOf && x.ExpiresOn >= asOf).OrderBy(x => x.ExpiresOn).ThenBy(x => x.ReceivedOn).ThenBy(x => x.Id, StringComparer.Ordinal))
        {
            var quantity = Math.Min(remaining, lot.Quantity);
            if (quantity > 0) picks.Add(new(lot.Id, quantity));
            remaining -= quantity;
            if (remaining == 0) break;
        }
        if (remaining > 0) throw new DomainValidationException("Insufficient nonexpired stock.");
        return picks;
    }
    public static int FreeCapacity(Warehouse warehouse, int occupied)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        return warehouse.Capacity - occupied;
    }
}
