using Benchmark.Domain;

namespace Benchmark.Application.Policies;

public sealed record ExpenseLimits(decimal TravelDaily, decimal MealDaily, decimal AccommodationDaily, decimal OfficePerClaim, decimal ManagerThreshold);
public sealed record ExpenseAssessment(decimal ConvertedAmount, decimal Reimbursable, decimal Excess, bool RequiresManager, string Currency);
public sealed record ExpenseApproval(bool Allowed, string Reason, decimal ApprovedAmount);

public static class ExpenseClaimPolicy
{
    public static decimal CategoryCap(string category, int days, ExpenseLimits limits)
    {
        ValidateLimits(limits);
        Rules.Range(days, 1, 366, nameof(days));
        return category switch
        {
            "Travel" => limits.TravelDaily * days,
            "Meal" => limits.MealDaily * days,
            "Accommodation" => limits.AccommodationDaily * days,
            "Office" => limits.OfficePerClaim,
            _ => throw new DomainValidationException("Unknown expense category.")
        };
    }

    public static ExpenseAssessment Assess(ExpenseClaim claim, int days, string reportingCurrency, decimal rate, ExpenseLimits limits)
    {
        ArgumentNullException.ThrowIfNull(claim);
        claim.Validate();
        var cap = CategoryCap(claim.Category, days, limits);
        var converted = PaymentPolicy.Convert(claim.Amount, claim.Currency, reportingCurrency, rate);
        var receipt = PaymentPolicy.Convert(claim.ReceiptAmount, claim.Currency, reportingCurrency, rate);
        var payable = Math.Min(converted, Math.Min(receipt, cap));
        return new(converted, payable, converted - payable, payable > limits.ManagerThreshold, reportingCurrency);
    }

    public static ExpenseApproval Approve(ExpenseClaim claim, ExpenseAssessment assessment, string approverId, bool isManager)
    {
        claim.Validate();
        Rules.Required(approverId, nameof(approverId), 64);
        if (claim.Status != DocumentStatus.Submitted) return new(false, "Claim must be submitted.", 0);
        if (string.Equals(claim.EmployeeId, approverId, StringComparison.Ordinal)) return new(false, "Self approval is not permitted.", 0);
        if (assessment.Reimbursable < 0 || assessment.Reimbursable > assessment.ConvertedAmount ||
            assessment.Excess != assessment.ConvertedAmount - assessment.Reimbursable)
            throw new DomainValidationException("Assessment amounts are inconsistent.");
        if (assessment.RequiresManager && !isManager) return new(false, "Manager approval is required.", 0);
        if (assessment.Reimbursable == 0) return new(false, "Nothing is reimbursable.", 0);
        return new(true, "Approved.", assessment.Reimbursable);
    }

    public static bool IsWithinSubmissionWindow(ExpenseClaim claim, DateOnly submittedOn, int windowDays)
    {
        claim.Validate();
        Rules.Range(windowDays, 0, 366, nameof(windowDays));
        var age = submittedOn.DayNumber - claim.BusinessDate.DayNumber;
        return age >= 0 && age <= windowDays;
    }

    public static decimal RemainingBudget(IEnumerable<ExpenseClaim> claims, string employeeId, string currency, decimal budget)
    {
        Rules.Required(employeeId, nameof(employeeId), 64);
        Rules.Range(budget, 0, 1_000_000_000m, nameof(budget));
        PaymentPolicy.Convert(0, currency, currency, 1);
        var spent = 0m;
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var claim in claims)
        {
            claim.Validate();
            if (!seen.Add(claim.Id)) throw new DomainValidationException("Duplicate claim identity.");
            if (claim.EmployeeId != employeeId || claim.Status is DocumentStatus.Draft or DocumentStatus.Cancelled) continue;
            if (claim.Currency != currency) throw new DomainValidationException("Budget currency mismatch.");
            spent += claim.Amount;
        }
        return Math.Max(0m, budget - spent);
    }

    public static bool IsPotentialDuplicate(ExpenseClaim candidate, IEnumerable<ExpenseClaim> existing)
    {
        candidate.Validate();
        return existing.Any(x => x.Id != candidate.Id && x.Status != DocumentStatus.Cancelled &&
            x.EmployeeId == candidate.EmployeeId && x.BusinessDate == candidate.BusinessDate &&
            x.Currency == candidate.Currency && x.Amount == candidate.Amount && x.Category == candidate.Category);
    }

    private static void ValidateLimits(ExpenseLimits limits)
    {
        ArgumentNullException.ThrowIfNull(limits);
        foreach (var value in new[] { limits.TravelDaily, limits.MealDaily, limits.AccommodationDaily, limits.OfficePerClaim, limits.ManagerThreshold })
            Rules.Range(value, 0, 1_000_000_000m, nameof(limits));
    }
}
