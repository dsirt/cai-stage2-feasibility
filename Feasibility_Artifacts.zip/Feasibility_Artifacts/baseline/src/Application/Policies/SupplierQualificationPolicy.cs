using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record SupplierPerformance(int Deliveries, int OnTime, int Accepted, decimal AverageLeadDays);
public sealed record SupplierAssessment(decimal OnTimeRate, decimal AcceptanceRate, decimal Score, bool Qualified, string Reason);
public static class SupplierQualificationPolicy
{
    public static SupplierAssessment Assess(Supplier supplier, SupplierPerformance performance, int minimumDeliveries, decimal minimumScore)
    {
        supplier.Validate();
        Rules.Range(minimumDeliveries, 1, 1000000, nameof(minimumDeliveries));
        Rules.Range(minimumScore, 0, 100, nameof(minimumScore));
        ValidatePerformance(performance);
        var onTime = performance.Deliveries == 0 ? 0 : (decimal)performance.OnTime / performance.Deliveries;
        var accepted = performance.Deliveries == 0 ? 0 : (decimal)performance.Accepted / performance.Deliveries;
        var score = decimal.Round((onTime * 0.6m + accepted * 0.4m) * 100m, 2);
        var qualified = supplier.IsApproved && performance.Deliveries >= minimumDeliveries && score >= minimumScore;
        var reason = !supplier.IsApproved ? "NotApproved" : performance.Deliveries < minimumDeliveries ? "InsufficientHistory" : score < minimumScore ? "LowScore" : "Qualified";
        return new(onTime, accepted, score, qualified, reason);
    }
    public static void ValidatePerformance(SupplierPerformance performance)
    {
        Rules.Range(performance.Deliveries, 0, 1000000, nameof(performance.Deliveries));
        Rules.Range(performance.OnTime, 0, performance.Deliveries, nameof(performance.OnTime));
        Rules.Range(performance.Accepted, 0, performance.Deliveries, nameof(performance.Accepted));
        Rules.Range(performance.AverageLeadDays, 0, 730, nameof(performance.AverageLeadDays));
    }
    public static DateOnly PaymentDueDate(Supplier supplier, DateOnly invoiceDate)
    {
        supplier.Validate();
        return invoiceDate.AddDays(supplier.PaymentDays);
    }
    public static decimal EarlyPaymentDiscount(decimal invoiceAmount, decimal percent, DateOnly paidOn, DateOnly discountDeadline)
    {
        Rules.Range(invoiceAmount, 0, 1000000000, nameof(invoiceAmount));
        Rules.Range(percent, 0, 100, nameof(percent));
        return paidOn <= discountDeadline ? decimal.Round(invoiceAmount * percent / 100m, 2, MidpointRounding.AwayFromZero) : 0m;
    }
    public static bool HasDuplicateTaxNumber(Supplier supplier, IEnumerable<Supplier> existing)
    {
        supplier.Validate();
        return existing.Any(x => x.Id != supplier.Id && x.Country == supplier.Country && x.TaxNumber == supplier.TaxNumber);
    }
}
