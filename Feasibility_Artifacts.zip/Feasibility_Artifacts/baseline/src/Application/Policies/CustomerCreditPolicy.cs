using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record Receivable(decimal Amount, DateOnly DueDate, decimal Paid);
public sealed record AgingBalance(decimal Current, decimal Days1To30, decimal Days31To60, decimal Days61Plus)
{
    public decimal Total => Current + Days1To30 + Days31To60 + Days61Plus;
}
public static class CustomerCreditPolicy
{
    public static AgingBalance Aging(IEnumerable<Receivable> receivables, DateOnly asOf)
    {
        decimal current = 0, first = 0, second = 0, last = 0;
        foreach (var item in receivables)
        {
            Rules.Range(item.Amount, 0, 1000000000, nameof(item.Amount));
            Rules.Range(item.Paid, 0, item.Amount, nameof(item.Paid));
            var remaining = item.Amount - item.Paid;
            var days = asOf.DayNumber - item.DueDate.DayNumber;
            if (days <= 0) current += remaining;
            else if (days <= 30) first += remaining;
            else if (days <= 60) second += remaining;
            else last += remaining;
        }
        return new(current, first, second, last);
    }
    public static decimal CreditRemaining(Customer customer, decimal receivables, decimal openOrders)
    {
        customer.Validate();
        Rules.Range(receivables, 0, 1000000000, nameof(receivables));
        Rules.Range(openOrders, 0, 1000000000, nameof(openOrders));
        return Math.Max(0, customer.CreditLimit - receivables - openOrders);
    }
    public static bool CanAcceptOrder(Customer customer, decimal orderAmount, decimal receivables, decimal openOrders, bool creditHold)
    {
        Rules.Range(orderAmount, 0, 1000000000, nameof(orderAmount));
        return !creditHold && orderAmount <= CreditRemaining(customer, receivables, openOrders);
    }
    public static DateOnly DueDate(Customer customer, DateOnly invoiceDate)
    {
        customer.Validate();
        return invoiceDate.AddDays(customer.PaymentDays);
    }
    public static string CollectionBand(AgingBalance aging)
    {
        if (aging.Current < 0 || aging.Days1To30 < 0 || aging.Days31To60 < 0 || aging.Days61Plus < 0)
            throw new DomainValidationException("Aging balances cannot be negative.");
        if (aging.Days61Plus > 0) return "Escalate";
        if (aging.Days31To60 > 0) return "Contact";
        if (aging.Days1To30 > 0) return "Reminder";
        return "Current";
    }
}
