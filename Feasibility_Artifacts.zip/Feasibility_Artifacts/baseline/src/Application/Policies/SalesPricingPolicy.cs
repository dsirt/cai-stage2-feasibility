using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record PriceBreakdown(decimal Subtotal, decimal Discount, decimal Net, decimal Tax, decimal Gross);
public sealed record Allocation(string WarehouseId, int Quantity);
public static class SalesPricingPolicy
{
    public static PriceBreakdown Calculate(decimal unitPrice, int quantity, decimal discountPercent, decimal taxPercent)
    {
        Rules.Range(unitPrice, 0, 1000000, nameof(unitPrice));
        Rules.Range(quantity, 1, 1000000, nameof(quantity));
        Rules.Range(discountPercent, 0, 100, nameof(discountPercent));
        Rules.Range(taxPercent, 0, 100, nameof(taxPercent));
        var subtotal = decimal.Round(unitPrice * quantity, 2, MidpointRounding.AwayFromZero);
        var discount = decimal.Round(subtotal * discountPercent / 100m, 2, MidpointRounding.AwayFromZero);
        var net = subtotal - discount;
        var tax = decimal.Round(net * taxPercent / 100m, 2, MidpointRounding.AwayFromZero);
        return new(subtotal, discount, net, tax, net + tax);
    }
    public static decimal AvailableCredit(SalesOrder order, decimal outstanding)
    {
        order.Validate();
        Rules.Range(outstanding, 0, 1000000000, nameof(outstanding));
        return Math.Max(0, order.CreditLimit - outstanding);
    }
    public static IReadOnlyList<Allocation> Allocate(int requested, IReadOnlyDictionary<string, int> stock)
    {
        Rules.Range(requested, 1, 1000000, nameof(requested));
        if (stock.Values.Any(x => x < 0)) throw new DomainValidationException("Stock cannot be negative.");
        var remaining = requested;
        var result = new List<Allocation>();
        foreach (var location in stock.OrderByDescending(x => x.Value).ThenBy(x => x.Key, StringComparer.Ordinal))
        {
            var take = Math.Min(remaining, location.Value);
            if (take > 0) result.Add(new(location.Key, take));
            remaining -= take;
            if (remaining == 0) break;
        }
        if (remaining > 0) throw new DomainValidationException("Insufficient total stock.");
        return result;
    }
    public static DateOnly PromiseDate(DateOnly ordered, int preparationDays, int transportDays)
    {
        Rules.Range(preparationDays, 0, 365, nameof(preparationDays));
        Rules.Range(transportDays, 0, 365, nameof(transportDays));
        return ordered.AddDays(preparationDays + transportDays);
    }
    public static decimal GrossOrderAmount(SalesOrder order)
    {
        order.Validate();
        return decimal.Round(order.Amount * (1 + order.TaxPercent / 100m), 2, MidpointRounding.AwayFromZero);
    }
    public static bool CanPromise(SalesOrder order, DateOnly earliestDelivery)
    {
        order.Validate();
        return order.Status is not (DocumentStatus.Cancelled or DocumentStatus.Closed) && earliestDelivery <= order.PromisedDate;
    }
}
