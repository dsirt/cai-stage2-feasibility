using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record MaintenanceSlot(string WorkOrderId, DateTimeOffset Start, DateTimeOffset End, string Technician);
public static class WorkOrderSchedulingPolicy
{
    public static DateTimeOffset DueAt(WorkOrder order, DateTimeOffset reportedAt, IReadOnlyDictionary<int, int> responseHours)
    {
        order.Validate();
        if (!responseHours.TryGetValue(order.Priority, out var hours) || hours < 0)
            throw new DomainValidationException("No valid response target for priority.");
        return reportedAt.AddHours(hours);
    }
    public static decimal Cost(WorkOrder order, decimal hourlyRate, decimal partsCost)
    {
        order.Validate();
        Rules.Range(hourlyRate, 0, 1000000, nameof(hourlyRate));
        Rules.Range(partsCost, 0, 1000000000, nameof(partsCost));
        return decimal.Round(order.ActualHours * hourlyRate + partsCost, 2, MidpointRounding.AwayFromZero);
    }
    public static decimal VariancePercent(WorkOrder order)
    {
        order.Validate();
        if (order.PlannedHours == 0) return 0;
        return decimal.Round((order.ActualHours - order.PlannedHours) / order.PlannedHours * 100m, 2);
    }
    public static bool Overlaps(MaintenanceSlot first, MaintenanceSlot second)
    {
        ValidateSlot(first);
        ValidateSlot(second);
        return first.Technician == second.Technician && first.Start < second.End && second.Start < first.End;
    }
    public static void ValidateSlot(MaintenanceSlot slot)
    {
        Rules.Required(slot.WorkOrderId, nameof(slot.WorkOrderId), 64);
        Rules.Required(slot.Technician, nameof(slot.Technician), 64);
        if (slot.End <= slot.Start) throw new DomainValidationException("Maintenance slot must have positive duration.");
    }
    public static IReadOnlyList<WorkOrder> Prioritize(IEnumerable<WorkOrder> orders)
    {
        var items = orders.ToArray();
        foreach (var item in items) item.Validate();
        return items.Where(x => x.Status is not (DocumentStatus.Closed or DocumentStatus.Cancelled))
            .OrderBy(x => x.Priority).ThenBy(x => x.BusinessDate).ThenBy(x => x.Id, StringComparer.Ordinal).ToArray();
    }
    public static decimal RemainingHours(WorkOrder order)
    {
        order.Validate();
        return Math.Max(0, order.PlannedHours - order.ActualHours);
    }
}
