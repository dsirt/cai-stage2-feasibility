using System.Collections.Concurrent;
using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Infrastructure;

// Synthetic in-process adapter; no process-crash persistence is claimed.
public sealed class InMemoryDatabaseSession : IDatabaseSession
{
    private readonly ConcurrentDictionary<(Type Type, string Id), BusinessDocument> rows = new();
    private readonly SemaphoreSlim transactionLock = new(1, 1);
    private readonly AsyncLocal<Dictionary<(Type Type, string Id), BusinessDocument>?> transactionRows = new();

    public Task<T?> FindAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (transactionRows.Value is { } pending)
            return Task.FromResult(pending.TryGetValue((typeof(T), id), out var p) ? (T)p : null);
        return Task.FromResult(rows.TryGetValue((typeof(T), id), out var value) ? (T)value : null);
    }

    public Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        IEnumerable<BusinessDocument> values = transactionRows.Value is { } pending ? pending.Values : rows.Values;
        return Task.FromResult<IReadOnlyList<T>>(values.OfType<T>().OrderBy(x => x.Id, StringComparer.Ordinal).ToArray());
    }

    public Task SaveAsync<T>(T document, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        document.Validate();
        if (transactionRows.Value is { } pending) pending[(typeof(T), document.Id)] = document;
        else rows[(typeof(T), document.Id)] = document;
        return Task.CompletedTask;
    }

    public Task DeleteAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (transactionRows.Value is { } pending) pending.Remove((typeof(T), id));
        else rows.TryRemove((typeof(T), id), out _);
        return Task.CompletedTask;
    }

    public Task<bool> TryReplaceAsync<T>(T document, int expectedVersion, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        document.Validate();
        var key = (typeof(T), document.Id);
        if (transactionRows.Value is { } pending)
        {
            if (!pending.TryGetValue(key, out var old) || old.Version != expectedVersion) return Task.FromResult(false);
            pending[key] = document;
            return Task.FromResult(true);
        }
        if (!rows.TryGetValue(key, out var current) || current.Version != expectedVersion) return Task.FromResult(false);
        return Task.FromResult(rows.TryUpdate(key, document, current));
    }

    public async Task<T> InTransactionAsync<T>(Func<CancellationToken, Task<T>> action, CancellationToken cancellationToken = default)
    {
        if (transactionRows.Value is not null) return await action(cancellationToken);
        await transactionLock.WaitAsync(cancellationToken);
        try
        {
            var before = rows.ToDictionary(x => x.Key, x => x.Value);
            transactionRows.Value = new(before);
            var result = await action(cancellationToken);
            cancellationToken.ThrowIfCancellationRequested();
            var after = transactionRows.Value;
            foreach (var removed in before.Keys.Where(key => !after.ContainsKey(key))) rows.TryRemove(removed, out _);
            foreach (var pair in after)
                if (!before.TryGetValue(pair.Key, out var old) || old != pair.Value) rows[pair.Key] = pair.Value;
            return result;
        }
        finally
        {
            transactionRows.Value = null;
            transactionLock.Release();
        }
    }
}
