using System.Collections.Concurrent;
using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Infrastructure;
public sealed class InMemoryAuditSink : IAuditSink
{
    private readonly ConcurrentQueue<AuditRecord> records = new();
    public Task AppendAsync(AuditRecord record, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        records.Enqueue(record);
        return Task.CompletedTask;
    }
    public Task<IReadOnlyList<AuditRecord>> ReadAllAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult<IReadOnlyList<AuditRecord>>(records.ToArray());
    }
}
