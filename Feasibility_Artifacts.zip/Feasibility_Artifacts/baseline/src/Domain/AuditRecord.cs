namespace Benchmark.Domain;
public sealed record AuditRecord(
    string Id,
    string EntityKind,
    string EntityId,
    string Action,
    string Actor,
    DateTimeOffset OccurredAt,
    int PreviousVersion,
    int CurrentVersion,
    string BeforeJson,
    string AfterJson);
