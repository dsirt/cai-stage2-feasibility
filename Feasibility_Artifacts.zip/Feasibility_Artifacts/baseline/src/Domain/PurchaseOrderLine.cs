namespace Benchmark.Domain;
public sealed record PurchaseOrderLine : BusinessDocument
{
    public override string Kind => "PurchaseOrderLine";
    public required string OrderId { get; init; }
    public required string ProductId { get; init; }
    public int Quantity { get; init; }
    public decimal UnitPrice { get; init; }
    public decimal NetTotal => decimal.Round(Quantity * UnitPrice, 2, MidpointRounding.AwayFromZero);
    public override void Validate()
    {
        base.Validate();
        Rules.Required(OrderId, nameof(OrderId), 64);
        Rules.Required(ProductId, nameof(ProductId), 64);
        Rules.Range(Quantity, 1, 1000000, nameof(Quantity));
        Rules.Range(UnitPrice, 0, 1000000, nameof(UnitPrice));
    }
}
