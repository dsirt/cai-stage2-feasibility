namespace Benchmark.Domain;
public enum DocumentStatus { Draft, Submitted, Approved, Fulfilled, Closed, Cancelled }
public sealed class DomainValidationException(string message) : Exception(message);
public sealed class ConcurrencyConflictException(string message) : Exception(message);
public sealed class MissingEntityException(string message) : Exception(message);
