namespace Benchmark.Domain;
public sealed record InventoryItem : BusinessDocument
{
    public override string Kind => "InventoryItem";
    public required string Sku { get; init; }
    public int OnHand { get; init; }
    public int Reserved { get; init; }
    public int Available => OnHand - Reserved;
    public override void Validate()
    {
        base.Validate();
        Rules.Required(Sku, nameof(Sku), 40);
        if (OnHand < 0 || Reserved < 0 || Reserved > OnHand)
            throw new DomainValidationException("Inventory quantities are inconsistent.");
    }
}
public sealed record ReservationResult(bool Success, string Code, int Available, int Version);
