namespace Benchmark.Domain;

public abstract record BusinessDocument
{
    public required string Id { get; init; }
    public required string Code { get; init; }
    public string PartyId { get; init; } = "";
    public DateOnly BusinessDate { get; init; } = new(2026, 1, 1);
    public decimal Amount { get; init; }
    public string Currency { get; init; } = "TRY";
    public string Description { get; init; } = "";
    public DocumentStatus Status { get; init; } = DocumentStatus.Draft;
    public int Version { get; init; }
    public abstract string Kind { get; }

    public virtual void Validate()
    {
        Rules.Required(Id, nameof(Id), 64);
        Rules.Required(Code, nameof(Code), 40);
        if (Id.Any(char.IsWhiteSpace)) throw new DomainValidationException("Id cannot contain whitespace.");
        if (Amount < 0 || Amount > 1_000_000_000m) throw new DomainValidationException("Amount is outside the supported range.");
        if (Currency.Length != 3 || Currency.Any(c => c < 'A' || c > 'Z'))
            throw new DomainValidationException("Currency must be a three-letter uppercase code.");
        if (BusinessDate.Year < 2000 || BusinessDate.Year > 2100)
            throw new DomainValidationException("BusinessDate must be between 2000 and 2100.");
        if (Description.Length > 2000) throw new DomainValidationException("Description exceeds 2000 characters.");
        if (Version < 0) throw new DomainValidationException("Version cannot be negative.");
        if (!Enum.IsDefined(Status)) throw new DomainValidationException("Unknown document status.");
    }

    public BusinessDocument NextStatus(DocumentStatus target)
    {
        if (!WorkflowRules.Allows(Status, target))
            throw new DomainValidationException($"Transition from {Status} to {target} is not allowed.");
        return this with { Status = target, Version = checked(Version + 1) };
    }
}

public static class Rules
{
    public static void Required(string value, string field, int limit)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new DomainValidationException($"{field} is required.");
        if (value.Length > limit) throw new DomainValidationException($"{field} exceeds {limit} characters.");
    }
    public static void Range(decimal value, decimal minimum, decimal maximum, string field)
    {
        if (value < minimum || value > maximum)
            throw new DomainValidationException($"{field} is outside [{minimum}, {maximum}].");
    }
    public static void DateOrder(DateOnly first, DateOnly last, string field)
    {
        if (last < first) throw new DomainValidationException($"{field} cannot precede its start date.");
    }
}

public static class WorkflowRules
{
    public static bool Allows(DocumentStatus source, DocumentStatus target) => (source, target) switch
    {
        (DocumentStatus.Draft, DocumentStatus.Submitted) => true,
        (DocumentStatus.Draft, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Submitted, DocumentStatus.Draft) => true,
        (DocumentStatus.Submitted, DocumentStatus.Approved) => true,
        (DocumentStatus.Submitted, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Approved, DocumentStatus.Fulfilled) => true,
        (DocumentStatus.Approved, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Fulfilled, DocumentStatus.Closed) => true,
        _ => false
    };
}
