namespace Benchmark.Domain;

public sealed record Supplier : BusinessDocument
{
    public override string Kind => "Supplier";
    public string TaxNumber { get; init; } = "1234567890";
    public int PaymentDays { get; init; } = 30;
    public string Country { get; init; } = "TR";
    public bool IsApproved { get; init; } = false;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(TaxNumber, nameof(TaxNumber), 20);
        if (!TaxNumber.All(char.IsDigit)) throw new DomainValidationException("Tax number must contain digits only.");
        Rules.Range(PaymentDays, 0, 365, nameof(PaymentDays));
        if (Country.Length != 2) throw new DomainValidationException("Country must have two characters.");
    }
}
