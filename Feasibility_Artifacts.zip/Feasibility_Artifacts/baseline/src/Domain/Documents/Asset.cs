namespace Benchmark.Domain;

public sealed record Asset : BusinessDocument
{
    public override string Kind => "Asset";
    public string SerialNumber { get; init; } = "SN-1";
    public DateOnly AcquisitionDate { get; init; } = new(2026, 1, 1);
    public int UsefulLifeMonths { get; init; } = 60;
    public decimal SalvageValue { get; init; } = 0m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(SerialNumber, nameof(SerialNumber), 80);
        Rules.Range(UsefulLifeMonths, 1, 1200, nameof(UsefulLifeMonths));
        if (SalvageValue < 0 || SalvageValue > Amount) throw new DomainValidationException("Salvage value exceeds asset cost.");
        if (AcquisitionDate > BusinessDate) throw new DomainValidationException("Asset acquisition cannot follow business date.");
    }
}
