namespace Benchmark.Domain;

public sealed record Shipment : BusinessDocument
{
    public override string Kind => "Shipment";
    public string OrderId { get; init; } = "SO-1";
    public string Carrier { get; init; } = "Carrier-1";
    public DateOnly DispatchDate { get; init; } = new(2026, 1, 2);
    public DateOnly ArrivalDate { get; init; } = new(2026, 1, 3);

    public override void Validate()
    {
        base.Validate();
        Rules.Required(OrderId, nameof(OrderId), 64);
        Rules.Required(Carrier, nameof(Carrier), 80);
        Rules.DateOrder(BusinessDate, DispatchDate, nameof(DispatchDate));
        Rules.DateOrder(DispatchDate, ArrivalDate, nameof(ArrivalDate));
    }
}
