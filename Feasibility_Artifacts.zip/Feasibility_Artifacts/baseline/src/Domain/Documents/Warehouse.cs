namespace Benchmark.Domain;

public sealed record Warehouse : BusinessDocument
{
    public override string Kind => "Warehouse";
    public string LocationCode { get; init; } = "IST-01";
    public int Capacity { get; init; } = 10000;
    public decimal MinimumTemperature { get; init; } = 0m;
    public decimal MaximumTemperature { get; init; } = 40m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(LocationCode, nameof(LocationCode), 30);
        Rules.Range(Capacity, 1, 10000000, nameof(Capacity));
        if (MinimumTemperature > MaximumTemperature) throw new DomainValidationException("Minimum temperature exceeds maximum.");
        Rules.Range(MinimumTemperature, -100, 100, nameof(MinimumTemperature));
    }
}
