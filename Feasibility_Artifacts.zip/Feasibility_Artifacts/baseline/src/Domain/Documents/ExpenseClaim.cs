namespace Benchmark.Domain;

public sealed record ExpenseClaim : BusinessDocument
{
    public override string Kind => "ExpenseClaim";
    public string EmployeeId { get; init; } = "E-1";
    public string Category { get; init; } = "Travel";
    public decimal ReceiptAmount { get; init; } = 100m;
    public bool ReceiptAttached { get; init; } = true;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(EmployeeId, nameof(EmployeeId), 64);
        if (Category is not ("Travel" or "Meal" or "Accommodation" or "Office")) throw new DomainValidationException("Unknown expense category.");
        if (Amount > ReceiptAmount) throw new DomainValidationException("Claim exceeds receipt amount.");
        if (Amount > 50m && !ReceiptAttached) throw new DomainValidationException("Receipt attachment required above 50.");
    }
}
