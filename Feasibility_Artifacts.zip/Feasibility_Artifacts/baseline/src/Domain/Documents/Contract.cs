namespace Benchmark.Domain;

public sealed record Contract : BusinessDocument
{
    public override string Kind => "Contract";
    public string Counterparty { get; init; } = "Partner-1";
    public DateOnly StartDate { get; init; } = new(2026, 1, 1);
    public DateOnly EndDate { get; init; } = new(2026, 12, 31);
    public int NoticeDays { get; init; } = 30;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(Counterparty, nameof(Counterparty), 100);
        Rules.DateOrder(StartDate, EndDate, nameof(EndDate));
        Rules.Range(NoticeDays, 0, 365, nameof(NoticeDays));
        if (EndDate.DayNumber - StartDate.DayNumber < NoticeDays) throw new DomainValidationException("Notice period exceeds contract duration.");
    }
}
