namespace Benchmark.Domain;

public sealed record Invoice : BusinessDocument
{
    public override string Kind => "Invoice";
    public string OrderId { get; init; } = "SO-1";
    public DateOnly DueDate { get; init; } = new(2026, 2, 1);
    public decimal TaxAmount { get; init; } = 20m;
    public decimal PaidAmount { get; init; } = 0m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(OrderId, nameof(OrderId), 64);
        Rules.DateOrder(BusinessDate, DueDate, nameof(DueDate));
        Rules.Range(TaxAmount, 0, 1000000000, nameof(TaxAmount));
        if (PaidAmount < 0 || PaidAmount > Amount + TaxAmount) throw new DomainValidationException("Paid amount exceeds invoice total.");
    }
}
