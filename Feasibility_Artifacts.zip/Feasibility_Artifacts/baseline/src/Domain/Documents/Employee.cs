namespace Benchmark.Domain;

public sealed record Employee : BusinessDocument
{
    public override string Kind => "Employee";
    public string Department { get; init; } = "Operations";
    public string PersonnelNumber { get; init; } = "E-1";
    public DateOnly HireDate { get; init; } = new(2025, 1, 1);
    public decimal WeeklyHours { get; init; } = 40m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(Department, nameof(Department), 80);
        Rules.Required(PersonnelNumber, nameof(PersonnelNumber), 40);
        if (HireDate > BusinessDate) throw new DomainValidationException("Hire date cannot follow business date.");
        Rules.Range(WeeklyHours, 1, 60, nameof(WeeklyHours));
    }
}
