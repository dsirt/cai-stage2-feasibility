namespace Benchmark.Domain;

public sealed record Customer : BusinessDocument
{
    public override string Kind => "Customer";
    public string TaxNumber { get; init; } = "9876543210";
    public decimal CreditLimit { get; init; } = 50000m;
    public int PaymentDays { get; init; } = 15;
    public string Email { get; init; } = "test@example.invalid";

    public override void Validate()
    {
        base.Validate();
        Rules.Required(TaxNumber, nameof(TaxNumber), 20);
        Rules.Range(CreditLimit, 0, 100000000, nameof(CreditLimit));
        Rules.Range(PaymentDays, 0, 365, nameof(PaymentDays));
        if (!Email.Contains("@", StringComparison.Ordinal)) throw new DomainValidationException("Email must contain an at sign.");
    }
}
