namespace Benchmark.Domain;

public sealed record WorkOrder : BusinessDocument
{
    public override string Kind => "WorkOrder";
    public string AssetId { get; init; } = "ASSET-1";
    public int Priority { get; init; } = 2;
    public decimal PlannedHours { get; init; } = 4m;
    public decimal ActualHours { get; init; } = 0m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(AssetId, nameof(AssetId), 64);
        Rules.Range(Priority, 1, 5, nameof(Priority));
        Rules.Range(PlannedHours, 0, 10000, nameof(PlannedHours));
        Rules.Range(ActualHours, 0, 10000, nameof(ActualHours));
    }
}
