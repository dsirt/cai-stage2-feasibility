namespace Benchmark.Domain;

public sealed record SalesOrder : BusinessDocument
{
    public override string Kind => "SalesOrder";
    public string CustomerId { get; init; } = "CUS-1";
    public DateOnly PromisedDate { get; init; } = new(2026, 2, 1);
    public decimal TaxPercent { get; init; } = 20m;
    public decimal CreditLimit { get; init; } = 100000m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(CustomerId, nameof(CustomerId), 64);
        Rules.DateOrder(BusinessDate, PromisedDate, nameof(PromisedDate));
        Rules.Range(TaxPercent, 0, 100, nameof(TaxPercent));
        if (Amount > CreditLimit) throw new DomainValidationException("Order exceeds customer credit limit.");
    }
}
