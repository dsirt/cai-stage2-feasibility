namespace Benchmark.Domain;

public sealed record PurchaseOrder : BusinessDocument
{
    public override string Kind => "PurchaseOrder";
    public string SupplierId { get; init; } = "SUP-1";
    public DateOnly ExpectedDate { get; init; } = new(2026, 2, 1);
    public decimal DiscountPercent { get; init; } = 0m;
    public string DeliveryTerms { get; init; } = "DAP";

    public override void Validate()
    {
        base.Validate();
        Rules.Required(SupplierId, nameof(SupplierId), 64);
        Rules.DateOrder(BusinessDate, ExpectedDate, nameof(ExpectedDate));
        Rules.Range(DiscountPercent, 0, 100, nameof(DiscountPercent));
        Rules.Required(DeliveryTerms, nameof(DeliveryTerms), 30);
    }
}
