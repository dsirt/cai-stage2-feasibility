namespace Benchmark.Domain;

public sealed record Payment : BusinessDocument
{
    public override string Kind => "Payment";
    public string InvoiceId { get; init; } = "INV-1";
    public string Method { get; init; } = "Transfer";
    public string Reference { get; init; } = "PAY-REF-1";
    public decimal Fee { get; init; } = 0m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(InvoiceId, nameof(InvoiceId), 64);
        if (Method is not ("Transfer" or "Card" or "Cash")) throw new DomainValidationException("Unsupported payment method.");
        Rules.Required(Reference, nameof(Reference), 80);
        if (Fee < 0 || Fee > Amount) throw new DomainValidationException("Payment fee is invalid.");
    }
}
