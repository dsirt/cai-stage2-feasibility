namespace Benchmark.Domain;

public sealed record ReturnAuthorization : BusinessDocument
{
    public override string Kind => "ReturnAuthorization";
    public string OrderId { get; init; } = "SO-1";
    public string Reason { get; init; } = "Damaged";
    public int Quantity { get; init; } = 1;
    public decimal RestockingPercent { get; init; } = 0m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(OrderId, nameof(OrderId), 64);
        if (Reason is not ("Damaged" or "WrongItem" or "Unwanted")) throw new DomainValidationException("Unknown return reason.");
        Rules.Range(Quantity, 1, 100000, nameof(Quantity));
        Rules.Range(RestockingPercent, 0, 100, nameof(RestockingPercent));
    }
}
