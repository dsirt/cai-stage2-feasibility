namespace Benchmark.Domain;

public sealed record Product : BusinessDocument
{
    public override string Kind => "Product";
    public string Sku { get; init; } = "SKU-1";
    public string Unit { get; init; } = "EA";
    public decimal UnitPrice { get; init; } = 10m;
    public decimal WeightKg { get; init; } = 1m;

    public override void Validate()
    {
        base.Validate();
        Rules.Required(Sku, nameof(Sku), 40);
        Rules.Required(Unit, nameof(Unit), 12);
        Rules.Range(UnitPrice, 0, 10000000, nameof(UnitPrice));
        Rules.Range(WeightKg, 0, 100000, nameof(WeightKg));
    }
}
