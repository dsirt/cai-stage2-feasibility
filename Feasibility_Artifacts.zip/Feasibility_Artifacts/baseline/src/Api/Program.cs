using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
using Benchmark.Api;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IDatabaseSession, InMemoryDatabaseSession>();
builder.Services.AddSingleton<IAuditSink, InMemoryAuditSink>();
builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton<IReservationObserver, NoOpReservationObserver>();
builder.Services.AddScoped<PurchaseOrderService>();
builder.Services.AddScoped<SalesOrderService>();
builder.Services.AddScoped<InventoryService>();
var app = builder.Build();
app.Use(async (context, next) =>
{
    try { await next(context); }
    catch (DomainValidationException error) { context.Response.StatusCode = 400; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
    catch (MissingEntityException error) { context.Response.StatusCode = 404; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
    catch (ConcurrencyConflictException error) { context.Response.StatusCode = 409; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
});
app.MapGet("/health", () => Results.Ok(new { status = "ok", storage = "synthetic-memory" }));
ModuleEndpoints.MapAll(app);
app.MapPost("/workflows/purchase-orders/{id}/lines", async (string id, AddLineRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.AddLineAsync(request.Line with { OrderId = id }, request.ExpectedVersion, token)));
app.MapPost("/workflows/purchase-orders/{id}/submit", async (string id, VersionRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.SubmitAsync(id, request.ExpectedVersion, token)));
app.MapPost("/workflows/purchase-orders/{id}/approve", async (string id, VersionRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.ApproveAsync(id, request.ExpectedVersion, token)));
app.MapPut("/workflows/sales-orders/{id}/description", async (string id, DescriptionRequest request, SalesOrderService service, CancellationToken token) =>
    Results.Ok(await service.UpdateDescriptionAsync(id, request.Description, request.Actor, request.ExpectedVersion, token)));
app.MapPost("/workflows/inventory", async (InventoryItem item, InventoryService service, CancellationToken token) => Results.Ok(await service.CreateAsync(item, token)));
app.MapPost("/workflows/inventory/{sku}/reserve", async (string sku, QuantityRequest request, InventoryService service, CancellationToken token) =>
    Results.Ok(await service.ReserveAsync(sku, request.Quantity, token)));
app.MapGet("/workflows/audit", async (IAuditSink sink, CancellationToken token) => Results.Ok(await sink.ReadAllAsync(token)));
app.Run();

public sealed record AddLineRequest(PurchaseOrderLine Line, int ExpectedVersion);
public sealed record VersionRequest(int ExpectedVersion);
public sealed record DescriptionRequest(string Description, string Actor, int ExpectedVersion);
public sealed record QuantityRequest(int Quantity);
