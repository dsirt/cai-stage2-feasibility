using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Api;
public static class ModuleEndpoints
{
    public static void MapAll(WebApplication app)
    {
        Map<PurchaseOrder>(app, "/api/purchaseorders");
        Map<SalesOrder>(app, "/api/salesorders");
        Map<Supplier>(app, "/api/suppliers");
        Map<Customer>(app, "/api/customers");
        Map<Product>(app, "/api/products");
        Map<Warehouse>(app, "/api/warehouses");
        Map<Invoice>(app, "/api/invoices");
        Map<Payment>(app, "/api/payments");
        Map<Shipment>(app, "/api/shipments");
        Map<Asset>(app, "/api/assets");
        Map<WorkOrder>(app, "/api/workorders");
        Map<Employee>(app, "/api/employees");
        Map<ExpenseClaim>(app, "/api/expenseclaims");
        Map<ReturnAuthorization>(app, "/api/returnauthorizations");
        Map<Contract>(app, "/api/contracts");
    }
    private static void Map<T>(WebApplication app, string path) where T : BusinessDocument
    {
        app.MapGet(path, async (IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).ListAsync(token)));
        app.MapGet(path + "/{id}", async (string id, IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).GetAsync(id, token)));
        app.MapPost(path, async (T document, IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).CreateAsync(document, token)));
        app.MapPut(path + "/{id}", async (string id, UpdateRequest<T> request, IDatabaseSession session, CancellationToken token) =>
        {
            if (id != request.Document.Id) throw new DomainValidationException("Route and body id differ.");
            return Results.Ok(await new DocumentService<T>(session).UpdateDraftAsync(request.Document, request.ExpectedVersion, token));
        });
        app.MapPost(path + "/{id}/transition", async (string id, TransitionRequest request, IDatabaseSession session, CancellationToken token) =>
            Results.Ok(await new DocumentService<T>(session).TransitionAsync(id, request.Target, request.ExpectedVersion, token)));
        app.MapDelete(path + "/{id}", async (string id, int expectedVersion, IDatabaseSession session, CancellationToken token) =>
            Results.Ok(await new DocumentService<T>(session).DeleteDraftAsync(id, expectedVersion, token)));
    }
}
public sealed record UpdateRequest<T>(T Document, int ExpectedVersion);
public sealed record TransitionRequest(DocumentStatus Target, int ExpectedVersion);
