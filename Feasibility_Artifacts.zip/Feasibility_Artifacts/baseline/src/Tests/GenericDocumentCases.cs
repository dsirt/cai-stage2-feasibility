using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;

public static class GenericDocumentCases
{
    public static IEnumerable<(string, Func<Task>)> For<T>(Func<string, T> factory) where T : BusinessDocument
    {
        var name = typeof(T).Name;
        yield return ($"{name}.CreateAndRead", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            AssertEx.Equal(1, saved.Version);
            AssertEx.Equal(saved, await service.GetAsync("a"));
        });
        yield return ($"{name}.DuplicateId", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(factory("a")));
        });
        yield return ($"{name}.DuplicateCode", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var first = await service.CreateAsync(factory("a"));
            var second = (T)(factory("b") with { Code = first.Code });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(second));
        });
        yield return ($"{name}.DraftEditVersion", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var original = await service.CreateAsync(factory("a"));
            var updated = await service.UpdateDraftAsync((T)(original with { Description = "Edited" }), 1);
            AssertEx.Equal(2, updated.Version);
            AssertEx.Equal("Edited", updated.Description);
        });
        yield return ($"{name}.StaleEditRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var original = await service.CreateAsync(factory("a"));
            await service.UpdateDraftAsync((T)(original with { Description = "Edited" }), 1);
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(original, 1));
        });
        yield return ($"{name}.FullLifecycle", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            foreach (var status in new[] { DocumentStatus.Submitted, DocumentStatus.Approved, DocumentStatus.Fulfilled, DocumentStatus.Closed })
                saved = await service.TransitionAsync(saved.Id, status, saved.Version);
            AssertEx.Equal(DocumentStatus.Closed, saved.Status);
            AssertEx.Equal(5, saved.Version);
        });
        yield return ($"{name}.SubmittedEditRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            saved = await service.TransitionAsync(saved.Id, DocumentStatus.Submitted, saved.Version);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.UpdateDraftAsync(saved, saved.Version));
        });
        yield return ($"{name}.IllegalTransitionRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.TransitionAsync("a", DocumentStatus.Closed, 1));
        });
        yield return ($"{name}.DraftDeletion", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            AssertEx.True(await service.DeleteDraftAsync("a", 1));
            await AssertEx.ThrowsAsync<MissingEntityException>(() => service.GetAsync("a"));
        });
        yield return ($"{name}.Cancellation", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            using var source = new CancellationTokenSource();
            source.Cancel();
            await AssertEx.ThrowsAsync<OperationCanceledException>(() => service.CreateAsync(factory("a"), source.Token));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
        });
        yield return ($"{name}.NegativeAmount", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Amount = -1m }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.InvalidCurrency", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Currency = "try" }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.InvalidDate", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { BusinessDate = new(1900,1,1) }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.LongDescription", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Description = new string('x', 2001) }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.ListStableOrder", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("b"));
            await service.CreateAsync(factory("a"));
            AssertEx.Equal("a", (await service.ListAsync())[0].Id);
        });
        yield return ($"{name}.CancellationIsTerminal", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            var saved = await service.TransitionAsync("a", DocumentStatus.Cancelled, 1);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.TransitionAsync("a", DocumentStatus.Draft, saved.Version));
        });
    }
}
