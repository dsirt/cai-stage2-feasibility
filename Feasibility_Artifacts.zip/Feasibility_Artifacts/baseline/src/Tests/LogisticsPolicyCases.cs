using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Tests;

public static class LogisticsPolicyCases
{
    private static (string, Func<Task>) Case(string name, Action action) => (name, () => { action(); return Task.CompletedTask; });
    public static IEnumerable<(string, Func<Task>)> All()
    {
        var date = new DateOnly(2026, 1, 1);
        yield return Case("PurchasePolicy.NetDiscount", () => AssertEx.Equal(90m, PurchasePlanningPolicy.NetTotal(new[] { new PurchaseOrderLine { Id = "l", Code = "L", OrderId = "po", ProductId = "p", Quantity = 2, UnitPrice = 50m } }, 10m)));
        yield return Case("PurchasePolicy.EmptyTotal", () => AssertEx.Equal(0m, PurchasePlanningPolicy.NetTotal(Array.Empty<PurchaseOrderLine>(), 0)));
        yield return Case("PurchasePolicy.InvalidDiscount", () => AssertEx.Throws<DomainValidationException>(() => PurchasePlanningPolicy.NetTotal(Array.Empty<PurchaseOrderLine>(), 101)));
        yield return Case("PurchasePolicy.LatestOrder", () => AssertEx.Equal(date.AddDays(-5), PurchasePlanningPolicy.LatestOrderDate(date, 3, 2)));
        yield return Case("PurchasePolicy.SelectQualifying", () => AssertEx.Equal("b", PurchasePlanningPolicy.SelectOffer(new[] { new SupplierOffer("a", 10, 4, 0.5m), new SupplierOffer("b", 15, 4, 0.9m) }, 5, 0.8m).SupplierId));
        yield return Case("PurchasePolicy.NoQualifying", () => AssertEx.Throws<DomainValidationException>(() => PurchasePlanningPolicy.SelectOffer(Array.Empty<SupplierOffer>(), 5, 0.8m)));
        yield return Case("PurchasePolicy.ExactReceipt", () => AssertEx.Equal("Matched", PurchasePlanningPolicy.MatchReceipt(10, 10, 100, 100, 0).Status));
        yield return Case("PurchasePolicy.OverReceipt", () => AssertEx.Equal("OverReceived", PurchasePlanningPolicy.MatchReceipt(10, 11, 100, 100, 0).Status));
        yield return Case("PurchasePolicy.ToleranceBoundary", () => AssertEx.True(PurchasePlanningPolicy.MatchReceipt(10, 10, 100, 105, 5).PriceMatches));
        yield return Case("PurchasePolicy.ToleranceExceeded", () => AssertEx.True(!PurchasePlanningPolicy.MatchReceipt(10, 10, 100, 105.01m, 5).PriceMatches));
        yield return Case("PurchasePolicy.ZeroExpectedPrice", () => AssertEx.True(!PurchasePlanningPolicy.MatchReceipt(10, 10, 0, 1, 5).PriceMatches));
        var po = new PurchaseOrder { Id = "po", Code = "PO", Amount = 100m, ExpectedDate = date };
        yield return Case("PurchasePolicy.ApprovalLimit", () => AssertEx.True(!PurchasePlanningPolicy.RequiresSecondApproval(po, 100m, false)));
        yield return Case("PurchasePolicy.NewSupplier", () => AssertEx.True(PurchasePlanningPolicy.RequiresSecondApproval(po, 100m, true)));
        yield return Case("PurchasePolicy.LateDays", () => AssertEx.Equal(3, PurchasePlanningPolicy.DelayDays(po, date.AddDays(3))));
        yield return Case("PurchasePolicy.ClosedNotLate", () => AssertEx.Equal(0, PurchasePlanningPolicy.DelayDays(po with { Status = DocumentStatus.Closed }, date.AddDays(3))));
        yield return Case("SalesPolicy.Price", () => AssertEx.Equal(216m, SalesPricingPolicy.Calculate(100m, 2, 10, 20).Gross));
        yield return Case("SalesPolicy.FullDiscount", () => AssertEx.Equal(0m, SalesPricingPolicy.Calculate(100m, 2, 100, 20).Gross));
        yield return Case("SalesPolicy.ZeroQuantityRejected", () => AssertEx.Throws<DomainValidationException>(() => SalesPricingPolicy.Calculate(100m, 0, 10, 20)));
        yield return Case("SalesPolicy.AllocationConserves", () => AssertEx.Equal(7, SalesPricingPolicy.Allocate(7, new Dictionary<string,int> { ["a"] = 3, ["b"] = 6 }).Sum(x => x.Quantity)));
        yield return Case("SalesPolicy.LargestLocationFirst", () => AssertEx.Equal("b", SalesPricingPolicy.Allocate(7, new Dictionary<string,int> { ["a"] = 3, ["b"] = 6 })[0].WarehouseId));
        yield return Case("SalesPolicy.InsufficientAllocation", () => AssertEx.Throws<DomainValidationException>(() => SalesPricingPolicy.Allocate(10, new Dictionary<string,int> { ["a"] = 3 })));
        yield return Case("SalesPolicy.NegativeStockRejected", () => AssertEx.Throws<DomainValidationException>(() => SalesPricingPolicy.Allocate(1, new Dictionary<string,int> { ["a"] = -1 })));
        yield return Case("SalesPolicy.Promise", () => AssertEx.Equal(date.AddDays(5), SalesPricingPolicy.PromiseDate(date, 2, 3)));
        var so = new SalesOrder { Id = "so", Code = "SO", Amount = 100m, CreditLimit = 1000m, PromisedDate = date.AddDays(4) };
        yield return Case("SalesPolicy.CreditFloor", () => AssertEx.Equal(0m, SalesPricingPolicy.AvailableCredit(so, 1200m)));
        yield return Case("SalesPolicy.GrossOrder", () => AssertEx.Equal(120m, SalesPricingPolicy.GrossOrderAmount(so)));
        yield return Case("SalesPolicy.CanPromise", () => AssertEx.True(SalesPricingPolicy.CanPromise(so, date.AddDays(4))));
        yield return Case("SalesPolicy.CannotPromiseLate", () => AssertEx.True(!SalesPricingPolicy.CanPromise(so, date.AddDays(5))));
        var supplier = new Supplier { Id = "s", Code = "S", IsApproved = true };
        yield return Case("SupplierPolicy.Qualified", () => AssertEx.True(SupplierQualificationPolicy.Assess(supplier, new(10,10,10,3), 5, 80).Qualified));
        yield return Case("SupplierPolicy.NotApproved", () => AssertEx.Equal("NotApproved", SupplierQualificationPolicy.Assess(supplier with { IsApproved = false }, new(10,10,10,3), 5, 80).Reason));
        yield return Case("SupplierPolicy.NoHistory", () => AssertEx.Equal("InsufficientHistory", SupplierQualificationPolicy.Assess(supplier, new(0,0,0,0), 5, 80).Reason));
        yield return Case("SupplierPolicy.LowScore", () => AssertEx.Equal("LowScore", SupplierQualificationPolicy.Assess(supplier, new(10,2,2,3), 5, 80).Reason));
        yield return Case("SupplierPolicy.InvalidPerformance", () => AssertEx.Throws<DomainValidationException>(() => SupplierQualificationPolicy.ValidatePerformance(new(1,2,1,3))));
        yield return Case("SupplierPolicy.PaymentDue", () => AssertEx.Equal(date.AddDays(30), SupplierQualificationPolicy.PaymentDueDate(supplier, date)));
        yield return Case("SupplierPolicy.DiscountDeadline", () => AssertEx.Equal(2m, SupplierQualificationPolicy.EarlyPaymentDiscount(100,2,date,date)));
        yield return Case("SupplierPolicy.LateNoDiscount", () => AssertEx.Equal(0m, SupplierQualificationPolicy.EarlyPaymentDiscount(100,2,date.AddDays(1),date)));
        yield return Case("SupplierPolicy.DuplicateTax", () => AssertEx.True(SupplierQualificationPolicy.HasDuplicateTaxNumber(supplier, new[] { supplier with { Id = "other" } })));
        yield return Case("SupplierPolicy.SameIdNotDuplicate", () => AssertEx.True(!SupplierQualificationPolicy.HasDuplicateTaxNumber(supplier, new[] { supplier })));
        var customer = new Customer { Id = "c", Code = "C", CreditLimit = 1000m };
        yield return Case("CustomerPolicy.CreditRemaining", () => AssertEx.Equal(500m, CustomerCreditPolicy.CreditRemaining(customer, 200, 300)));
        yield return Case("CustomerPolicy.CreditExhausted", () => AssertEx.Equal(0m, CustomerCreditPolicy.CreditRemaining(customer, 800, 300)));
        yield return Case("CustomerPolicy.CreditHold", () => AssertEx.True(!CustomerCreditPolicy.CanAcceptOrder(customer,100,0,0,true)));
        yield return Case("CustomerPolicy.ExactCredit", () => AssertEx.True(CustomerCreditPolicy.CanAcceptOrder(customer,1000,0,0,false)));
        yield return Case("CustomerPolicy.DueDate", () => AssertEx.Equal(date.AddDays(15), CustomerCreditPolicy.DueDate(customer,date)));
        foreach (var (age,band) in new[] { (0,"Current"), (1,"Reminder"), (30,"Reminder"), (31,"Contact"), (60,"Contact"), (61,"Escalate") })
        {
            yield return Case($"CustomerPolicy.Aging{age}", () =>
            {
                var aging = CustomerCreditPolicy.Aging(new[] { new Receivable(100,date.AddDays(-age),20) }, date);
                AssertEx.Equal(80m, aging.Total);
                AssertEx.Equal(band, CustomerCreditPolicy.CollectionBand(aging));
            });
        }
        yield return Case("CustomerPolicy.OverpaidRejected", () => AssertEx.Throws<DomainValidationException>(() => CustomerCreditPolicy.Aging(new[] { new Receivable(100,date,101) },date)));
        var product = new Product { Id = "p", Code = "P", UnitPrice = 10m, WeightKg = 2m };
        yield return Case("ProductPolicy.UnitConversion", () => AssertEx.Equal(24m, ProductCatalogPolicy.ConvertQuantity(2,12)));
        yield return Case("ProductPolicy.InvalidConversion", () => AssertEx.Throws<DomainValidationException>(() => ProductCatalogPolicy.ConvertQuantity(2,0)));
        yield return Case("ProductPolicy.UnitCost", () => AssertEx.Equal(3.3333m, ProductCatalogPolicy.UnitCost(10,3)));
        yield return Case("ProductPolicy.Margin", () => AssertEx.Equal(40m, ProductCatalogPolicy.GrossMarginPercent(product,6)));
        yield return Case("ProductPolicy.ZeroPriceMargin", () => AssertEx.Equal(0m, ProductCatalogPolicy.GrossMarginPercent(product with { UnitPrice = 0 },6)));
        yield return Case("ProductPolicy.Weight", () => AssertEx.Equal(7m, ProductCatalogPolicy.ShipmentWeight(product,3,1)));
        yield return Case("ProductPolicy.Replenish", () => AssertEx.Equal(12, ProductCatalogPolicy.Replenish(product,4,0,2,3,2,7).SuggestedQuantity));
        yield return Case("ProductPolicy.NoReplenishAbovePoint", () => AssertEx.Equal(0, ProductCatalogPolicy.Replenish(product,9,0,2,3,2,7).SuggestedQuantity));
        yield return Case("ProductPolicy.InvalidTarget", () => AssertEx.Throws<DomainValidationException>(() => ProductCatalogPolicy.Replenish(product,4,0,2,3,2,2)));
        var warehouse = new Warehouse { Id = "w", Code = "W", Capacity = 100, MinimumTemperature = 5, MaximumTemperature = 10 };
        yield return Case("WarehousePolicy.Utilization", () => AssertEx.Equal(50m, WarehouseCapacityPolicy.UtilizationPercent(warehouse,50)));
        yield return Case("WarehousePolicy.Capacity", () => AssertEx.Equal(50, WarehouseCapacityPolicy.FreeCapacity(warehouse,50)));
        yield return Case("WarehousePolicy.ReceiveAtCapacity", () => AssertEx.True(WarehouseCapacityPolicy.CanReceive(warehouse,50,50,0,20)));
        yield return Case("WarehousePolicy.OverCapacity", () => AssertEx.True(!WarehouseCapacityPolicy.CanReceive(warehouse,50,51,0,20)));
        yield return Case("WarehousePolicy.TemperatureRejected", () => AssertEx.True(!WarehouseCapacityPolicy.CanReceive(warehouse,50,10,6,20)));
        var lots = new[] { new StorageLot("later",5,date,date.AddDays(2)), new StorageLot("first",5,date,date.AddDays(1)) };
        yield return Case("WarehousePolicy.FirstExpiring", () => AssertEx.Equal("first", WarehouseCapacityPolicy.PickFirstExpiring(lots,6,date)[0].LotId));
        yield return Case("WarehousePolicy.PickConserves", () => AssertEx.Equal(6, WarehouseCapacityPolicy.PickFirstExpiring(lots,6,date).Sum(x=>x.Quantity)));
        yield return Case("WarehousePolicy.ExpiredRejected", () => AssertEx.Throws<DomainValidationException>(() => WarehouseCapacityPolicy.PickFirstExpiring(lots,1,date.AddDays(3))));
        yield return Case("WarehousePolicy.DuplicateLotRejected", () => AssertEx.Throws<DomainValidationException>(() => WarehouseCapacityPolicy.PickFirstExpiring(new[]{lots[0],lots[0]},1,date)));
        var friday = new DateOnly(2026,1,2);
        yield return Case("ShipmentPolicy.WeekendSkipped", () => AssertEx.Equal(new DateOnly(2026,1,5),ShipmentPlanningPolicy.AddWorkingDays(friday,1,new HashSet<DateOnly>())));
        yield return Case("ShipmentPolicy.HolidaySkipped", () => AssertEx.Equal(new DateOnly(2026,1,6),ShipmentPlanningPolicy.AddWorkingDays(friday,1,new HashSet<DateOnly>{new(2026,1,5)})));
        yield return Case("ShipmentPolicy.QuoteTotal", () => AssertEx.Equal(25m,ShipmentPlanningPolicy.Quote(2,10,10,0.5m,20,100,1).Total));
        var shipment = new Shipment { Id="ship",Code="SHIP",Amount=100,DispatchDate=date,ArrivalDate=date.AddDays(2) };
        yield return Case("ShipmentPolicy.Transit", () => AssertEx.Equal(2,ShipmentPlanningPolicy.TransitDays(shipment)));
        yield return Case("ShipmentPolicy.PenaltyCap", () => AssertEx.Equal(10m,ShipmentPlanningPolicy.DelayPenalty(shipment,date.AddDays(20),2,10)));
        yield return Case("ShipmentPolicy.NoEarlyPenalty", () => AssertEx.Equal(0m,ShipmentPlanningPolicy.DelayPenalty(shipment,date,2,10)));
        yield return Case("ShipmentPolicy.DraftCannotDispatch", () => AssertEx.True(!ShipmentPlanningPolicy.CanDispatch(shipment,date,true)));
        yield return Case("ShipmentPolicy.ApprovedDispatch", () => AssertEx.True(ShipmentPlanningPolicy.CanDispatch(shipment with {Status=DocumentStatus.Approved},date,true)));
        var work = new WorkOrder { Id="work",Code="WORK",PlannedHours=4,ActualHours=5,Priority=2 };
        var instant = new DateTimeOffset(2026,1,1,0,0,0,TimeSpan.Zero);
        yield return Case("WorkPolicy.ResponseDue", () => AssertEx.Equal(instant.AddHours(4),WorkOrderSchedulingPolicy.DueAt(work,instant,new Dictionary<int,int>{[2]=4})));
        yield return Case("WorkPolicy.MissingResponse", () => AssertEx.Throws<DomainValidationException>(()=>WorkOrderSchedulingPolicy.DueAt(work,instant,new Dictionary<int,int>())));
        yield return Case("WorkPolicy.Cost", () => AssertEx.Equal(120m,WorkOrderSchedulingPolicy.Cost(work,20,20)));
        yield return Case("WorkPolicy.Variance", () => AssertEx.Equal(25m,WorkOrderSchedulingPolicy.VariancePercent(work)));
        yield return Case("WorkPolicy.RemainingFloor", () => AssertEx.Equal(0m,WorkOrderSchedulingPolicy.RemainingHours(work)));
        var slot = new MaintenanceSlot("w",instant,instant.AddHours(2),"technician");
        yield return Case("WorkPolicy.Overlap", () => AssertEx.True(WorkOrderSchedulingPolicy.Overlaps(slot,slot with {WorkOrderId="other",Start=instant.AddHours(1)})));
        yield return Case("WorkPolicy.TouchingNotOverlap", () => AssertEx.True(!WorkOrderSchedulingPolicy.Overlaps(slot,slot with {Start=instant.AddHours(2),End=instant.AddHours(3)})));
        yield return Case("WorkPolicy.OtherTechnician", () => AssertEx.True(!WorkOrderSchedulingPolicy.Overlaps(slot,slot with {Technician="another"})));
        yield return Case("WorkPolicy.PriorityOrder", () => AssertEx.Equal(1,WorkOrderSchedulingPolicy.Prioritize(new[]{work,work with {Id="high",Priority=1}})[0].Priority));
        var employee = new Employee { Id="e",Code="E",HireDate=new(2025,1,1),WeeklyHours=40 };
        yield return Case("EmployeePolicy.ServiceMonths", () => AssertEx.Equal(12,EmployeeSchedulingPolicy.CompletedServiceMonths(employee,date)));
        yield return Case("EmployeePolicy.FutureHireNoService", () => AssertEx.Equal(0,EmployeeSchedulingPolicy.CompletedServiceMonths(employee,new(2024,1,1))));
        yield return Case("EmployeePolicy.LeaveAccrual", () => AssertEx.Equal(19m,EmployeeSchedulingPolicy.AccruedLeave(employee,date,24,5)));
        yield return Case("EmployeePolicy.AllocateBoundary", () => AssertEx.True(EmployeeSchedulingPolicy.CanAllocate(employee,30,10)));
        yield return Case("EmployeePolicy.AllocateExceeded", () => AssertEx.True(!EmployeeSchedulingPolicy.CanAllocate(employee,30,11)));
        var entries=Enumerable.Range(0,5).Select(i=>new WorkEntry(date.AddDays(i),9,"project")).ToArray();
        yield return Case("EmployeePolicy.Overtime", () => AssertEx.Equal(5m,EmployeeSchedulingPolicy.Summarize(employee,entries,10,1.5m).OvertimeHours));
        yield return Case("EmployeePolicy.Cost", () => AssertEx.Equal(475m,EmployeeSchedulingPolicy.Summarize(employee,entries,10,1.5m).Cost));
        yield return Case("EmployeePolicy.DayOverflow", () => AssertEx.Throws<DomainValidationException>(()=>EmployeeSchedulingPolicy.Summarize(employee,new[]{new WorkEntry(date,20,"p"),new WorkEntry(date,5,"q")},10,1.5m)));
        yield return Case("EmployeePolicy.WeekOverflow", () => AssertEx.Throws<DomainValidationException>(()=>EmployeeSchedulingPolicy.Summarize(employee,new[]{new WorkEntry(date,1,"p"),new WorkEntry(date.AddDays(7),1,"q")},10,1.5m)));
    }
}
