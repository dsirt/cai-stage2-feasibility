using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;

public static class WorkflowCases
{
    private static PurchaseOrder Order(string id = "po") => new() { Id = id, Code = id, DiscountPercent = 10m };
    private static PurchaseOrderLine Line(string id = "line", string order = "po") => new() { Id = id, Code = id, OrderId = order, ProductId = "product", Quantity = 2, UnitPrice = 50m };
    public static IEnumerable<(string, Func<Task>)> All()
    {
        yield return ("Purchase.TotalIncludesDiscount", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            var saved = await service.AddLineAsync(Line(), 1);
            AssertEx.Equal(90m, saved.Amount);
            AssertEx.Equal(2, saved.Version);
            AssertEx.Equal(1, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.RemoveRecalculates", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            var saved = await service.RemoveLineAsync("po", "line", 2);
            AssertEx.Equal(0m, saved.Amount);
            AssertEx.Equal(0, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.EmptySubmitRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.SubmitAsync("po", 1));
        });
        yield return ("Purchase.ApprovalLifecycle", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            await service.SubmitAsync("po", 2);
            var saved = await service.ApproveAsync("po", 3);
            AssertEx.Equal(DocumentStatus.Approved, saved.Status);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.AddLineAsync(Line("another"), 4));
        });
        yield return ("Purchase.StaleLineRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.AddLineAsync(Line("another"), 1));
            AssertEx.Equal(1, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.CrossOrderDeletionRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.CreateAsync(Order("other"));
            await service.AddLineAsync(Line(), 1);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.RemoveLineAsync("other", "line", 1));
        });
        yield return ("Storage.RollbackOnException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<InvalidOperationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(Order(), token);
                throw new InvalidOperationException("test");
            }));
            AssertEx.True(await session.FindAsync<PurchaseOrder>("po") is null);
        });
        yield return ("Storage.VersionCompare", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await session.SaveAsync(Order() with { Version = 1 });
            AssertEx.True(!await session.TryReplaceAsync(Order() with { Version = 2 }, 0));
            AssertEx.True(await session.TryReplaceAsync(Order() with { Version = 2 }, 1));
        });
        yield return ("Sales.DescriptionPersists", async () =>
        {
            var service = new SalesOrderService(new InMemoryDatabaseSession(), new InMemoryAuditSink(), new SystemClock());
            await service.CreateAsync(new SalesOrder { Id = "so", Code = "SO" });
            var saved = await service.UpdateDescriptionAsync("so", "New delivery notes", "operator", 1);
            AssertEx.Equal("New delivery notes", saved.Description);
            AssertEx.Equal(2, saved.Version);
        });
        yield return ("Sales.InvalidAmountRollsBack", async () =>
        {
            var service = new SalesOrderService(new InMemoryDatabaseSession(), new InMemoryAuditSink(), new SystemClock());
            await service.CreateAsync(new SalesOrder { Id = "so", Code = "SO", Amount = 100m });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.ChangeAmountAsync("so", 200000m, "operator", 1));
            AssertEx.Equal(100m, (await service.GetAsync("so")).Amount);
        });
        yield return ("Inventory.SequentialReservation", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            AssertEx.True((await service.ReserveAsync("sku", 6)).Success);
            AssertEx.True(!(await service.ReserveAsync("sku", 6)).Success);
            AssertEx.Equal(6, (await service.GetAsync("sku")).Reserved);
        });
        yield return ("Inventory.ReleaseAndAdjust", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            await service.ReserveAsync("sku", 4);
            var saved = await service.ReleaseAsync("sku", 2, 2);
            AssertEx.Equal(2, saved.Reserved);
            saved = await service.AdjustAsync("sku", 20, 3);
            AssertEx.Equal(18, saved.Available);
        });
        yield return ("Inventory.InvalidQuantity", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.ReserveAsync("sku", 0));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.AdjustAsync("sku", -1, 1));
        });
        yield return ("Architecture.DomainHasNoApplicationReference", () =>
        {
            var references = typeof(BusinessDocument).Assembly.GetReferencedAssemblies();
            AssertEx.True(!references.Any(x => x.Name is "Benchmark.Application" or "Benchmark.Infrastructure" or "Benchmark.Api"));
            return Task.CompletedTask;
        });
        yield return ("Architecture.ApplicationHasNoInfrastructureReference", () =>
        {
            var references = typeof(PurchaseOrderService).Assembly.GetReferencedAssemblies();
            AssertEx.True(!references.Any(x => x.Name is "Benchmark.Infrastructure" or "Benchmark.Api"));
            return Task.CompletedTask;
        });
    }
}
