using System.Diagnostics;
using System.Text.Json;
using Benchmark.Tests;

var tests = ModuleCases.All().Concat(WorkflowCases.All()).Concat(PartitionCases.All()).Concat(LogisticsPolicyCases.All()).Concat(PolicyCasesFinance.All()).ToArray();
var results = new List<object>();
var failures = 0;
foreach (var (name, test) in tests)
{
    var watch = Stopwatch.StartNew();
    try
    {
        await test();
        results.Add(new { name, passed = true, durationMs = watch.Elapsed.TotalMilliseconds, error = "" });
    }
    catch (Exception error)
    {
        failures++;
        results.Add(new { name, passed = false, durationMs = watch.Elapsed.TotalMilliseconds, error = error.ToString() });
        Console.Error.WriteLine($"FAIL {name}: {error.Message}");
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { total = tests.Length, passed = tests.Length - failures, failed = failures, results }));
return failures == 0 ? 0 : 1;
