using Benchmark.Domain;
using Benchmark.Application.Policies;

namespace Benchmark.Tests;

// Synthetic finance-policy examples; this file is reproducibly emitted by generate_finance_policies.py.
public static class PolicyCasesFinance
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
        yield return ("Finance.Invoice_Aging_0", Case000);
        yield return ("Finance.Invoice_Aging_1", Case001);
        yield return ("Finance.Invoice_Aging_2", Case002);
        yield return ("Finance.Invoice_Aging_30", Case003);
        yield return ("Finance.Invoice_Aging_31", Case004);
        yield return ("Finance.Invoice_Aging_32", Case005);
        yield return ("Finance.Invoice_Aging_61", Case006);
        yield return ("Finance.Invoice_Aging_62", Case007);
        yield return ("Finance.Invoice_Aging_91", Case008);
        yield return ("Finance.Invoice_Aging_92", Case009);
        yield return ("Finance.Invoice_Balance_100_20_0", Case010);
        yield return ("Finance.Invoice_Balance_100_20_50", Case011);
        yield return ("Finance.Invoice_Balance_100_20_120", Case012);
        yield return ("Finance.Invoice_Balance_0_0_0", Case013);
        yield return ("Finance.Invoice_Balance_100_0_25", Case014);
        yield return ("Finance.Invoice_Interest_365_.10_0", Case015);
        yield return ("Finance.Invoice_Interest_30_.10_0", Case016);
        yield return ("Finance.Invoice_Interest_30_.10_30", Case017);
        yield return ("Finance.Invoice_Interest_31_.10_30", Case018);
        yield return ("Finance.Invoice_Interest_365_0_0", Case019);
        yield return ("Finance.Invoice_Interest_365_1_0", Case020);
        yield return ("Finance.Invoice_Apply_1", Case021);
        yield return ("Finance.Invoice_Apply_60", Case022);
        yield return ("Finance.Invoice_Apply_120", Case023);
        yield return ("Finance.Invoice_RejectPayment_0", Case024);
        yield return ("Finance.Invoice_RejectPayment_-1", Case025);
        yield return ("Finance.Invoice_RejectPayment_121", Case026);
        yield return ("Finance.Invoice_Closed_Closed", Case027);
        yield return ("Finance.Invoice_Closed_Cancelled", Case028);
        yield return ("Finance.Invoice_AllocateDueOrder", Case029);
        yield return ("Finance.Invoice_AllocateRemainder", Case030);
        yield return ("Finance.Invoice_AllocateClosed", Case031);
        yield return ("Finance.Invoice_DuplicateInput", Case032);
        yield return ("Finance.Invoice_CurrencyMismatch", Case033);
        yield return ("Finance.Invoice_InvalidRate", Case034);
        yield return ("Finance.Invoice_AgingPaid", Case035);
        yield return ("Finance.Invoice_AgingTotals", Case036);
        yield return ("Finance.Payment_Fee_Cash_0", Case037);
        yield return ("Finance.Payment_Fee_Cash_100", Case038);
        yield return ("Finance.Payment_Fee_Transfer_0", Case039);
        yield return ("Finance.Payment_Fee_Transfer_.50", Case040);
        yield return ("Finance.Payment_Fee_Transfer_100", Case041);
        yield return ("Finance.Payment_Fee_Card_0", Case042);
        yield return ("Finance.Payment_Fee_Card_1", Case043);
        yield return ("Finance.Payment_Fee_Card_100", Case044);
        yield return ("Finance.Payment_Fee_Card_1000", Case045);
        yield return ("Finance.Payment_Convert_100_2", Case046);
        yield return ("Finance.Payment_Convert_100_.5", Case047);
        yield return ("Finance.Payment_Convert_1_1.005", Case048);
        yield return ("Finance.Payment_Convert_0_30", Case049);
        yield return ("Finance.Payment_Convert_3_1.333", Case050);
        yield return ("Finance.Payment_Invalid_51", Case051);
        yield return ("Finance.Payment_Invalid_52", Case052);
        yield return ("Finance.Payment_Invalid_53", Case053);
        yield return ("Finance.Payment_Invalid_54", Case054);
        yield return ("Finance.Payment_Invalid_55", Case055);
        yield return ("Finance.Payment_SettlementDate_2_0", Case056);
        yield return ("Finance.Payment_SettlementDate_2_1", Case057);
        yield return ("Finance.Payment_SettlementDate_2_2", Case058);
        yield return ("Finance.Payment_SettlementDate_3_0", Case059);
        yield return ("Finance.Payment_SettlementDate_4_0", Case060);
        yield return ("Finance.Payment_SettlementDate_5_5", Case061);
        yield return ("Finance.Payment_Net", Case062);
        yield return ("Finance.Payment_Settle", Case063);
        yield return ("Finance.Payment_SettleReject_64", Case064);
        yield return ("Finance.Payment_SettleReject_65", Case065);
        yield return ("Finance.Payment_SettleReject_66", Case066);
        yield return ("Finance.Payment_SettleReject_67", Case067);
        yield return ("Finance.Payment_SettleReject_68", Case068);
        yield return ("Finance.Payment_Refund_0_20_true", Case069);
        yield return ("Finance.Payment_Refund_20_80_true", Case070);
        yield return ("Finance.Payment_Refund_0_100_true", Case071);
        yield return ("Finance.Payment_Refund_0_20_false", Case072);
        yield return ("Finance.Payment_RefundInvalid_-1_1", Case073);
        yield return ("Finance.Payment_RefundInvalid_0_0", Case074);
        yield return ("Finance.Payment_RefundInvalid_100_1", Case075);
        yield return ("Finance.Payment_RefundInvalid_50_51", Case076);
        yield return ("Finance.Payment_DuplicateReference", Case077);
        yield return ("Finance.Payment_CancelledNotDuplicate", Case078);
        yield return ("Finance.Asset_BookMonth_0", Case079);
        yield return ("Finance.Asset_BookMonth_1", Case080);
        yield return ("Finance.Asset_BookMonth_2", Case081);
        yield return ("Finance.Asset_BookMonth_3", Case082);
        yield return ("Finance.Asset_BookMonth_4", Case083);
        yield return ("Finance.Asset_BookMonth_5", Case084);
        yield return ("Finance.Asset_BookMonth_6", Case085);
        yield return ("Finance.Asset_BookMonth_7", Case086);
        yield return ("Finance.Asset_BookMonth_8", Case087);
        yield return ("Finance.Asset_BookMonth_9", Case088);
        yield return ("Finance.Asset_BookMonth_10", Case089);
        yield return ("Finance.Asset_BookMonth_11", Case090);
        yield return ("Finance.Asset_BookMonth_12", Case091);
        yield return ("Finance.Asset_BeforeAcquisition", Case092);
        yield return ("Finance.Asset_BeforeAnniversary", Case093);
        yield return ("Finance.Asset_MonthEndAnniversary", Case094);
        yield return ("Finance.Asset_BeyondLife", Case095);
        yield return ("Finance.Asset_ResidualSchedule", Case096);
        yield return ("Finance.Asset_SalvageSchedule", Case097);
        yield return ("Finance.Asset_ZeroBasis", Case098);
        yield return ("Finance.Asset_Interval", Case099);
        yield return ("Finance.Asset_LifePercent", Case100);
        yield return ("Finance.Asset_RemainingLife", Case101);
        yield return ("Finance.Asset_Disposal_80", Case102);
        yield return ("Finance.Asset_Disposal_60", Case103);
        yield return ("Finance.Asset_Disposal_40", Case104);
        yield return ("Finance.Asset_Impairment_100", Case105);
        yield return ("Finance.Asset_Impairment_60", Case106);
        yield return ("Finance.Asset_Impairment_40", Case107);
        yield return ("Finance.Asset_Impairment_0", Case108);
        yield return ("Finance.Asset_Invalid_109", Case109);
        yield return ("Finance.Asset_Invalid_110", Case110);
        yield return ("Finance.Asset_Invalid_111", Case111);
        yield return ("Finance.Asset_Invalid_112", Case112);
        yield return ("Finance.Asset_Invalid_113", Case113);
        yield return ("Finance.Expense_Cap_Travel_1", Case114);
        yield return ("Finance.Expense_Cap_Travel_2", Case115);
        yield return ("Finance.Expense_Cap_Meal_1", Case116);
        yield return ("Finance.Expense_Cap_Meal_3", Case117);
        yield return ("Finance.Expense_Cap_Accommodation_1", Case118);
        yield return ("Finance.Expense_Cap_Accommodation_2", Case119);
        yield return ("Finance.Expense_Cap_Office_1", Case120);
        yield return ("Finance.Expense_Cap_Office_3", Case121);
        yield return ("Finance.Expense_Assess_0", Case122);
        yield return ("Finance.Expense_Assess_80", Case123);
        yield return ("Finance.Expense_Assess_100", Case124);
        yield return ("Finance.Expense_Assess_150", Case125);
        yield return ("Finance.Expense_CurrencyConversion", Case126);
        yield return ("Finance.Expense_Approve_Submitted_boss", Case127);
        yield return ("Finance.Expense_Approve_Draft_boss", Case128);
        yield return ("Finance.Expense_Approve_Approved_boss", Case129);
        yield return ("Finance.Expense_Approve_Submitted_E-1", Case130);
        yield return ("Finance.Expense_Manager_false", Case131);
        yield return ("Finance.Expense_Manager_true", Case132);
        yield return ("Finance.Expense_Window_-1_30", Case133);
        yield return ("Finance.Expense_Window_0_0", Case134);
        yield return ("Finance.Expense_Window_0_30", Case135);
        yield return ("Finance.Expense_Window_30_30", Case136);
        yield return ("Finance.Expense_Window_31_30", Case137);
        yield return ("Finance.Expense_Window_365_366", Case138);
        yield return ("Finance.Expense_Budget_Draft", Case139);
        yield return ("Finance.Expense_Budget_Submitted", Case140);
        yield return ("Finance.Expense_Budget_Approved", Case141);
        yield return ("Finance.Expense_Budget_Cancelled", Case142);
        yield return ("Finance.Expense_Budget_Closed", Case143);
        yield return ("Finance.Expense_BudgetFloor", Case144);
        yield return ("Finance.Expense_Duplicate", Case145);
        yield return ("Finance.Expense_Invalid_146", Case146);
        yield return ("Finance.Expense_Invalid_147", Case147);
        yield return ("Finance.Expense_Invalid_148", Case148);
        yield return ("Finance.Expense_Invalid_149", Case149);
        yield return ("Finance.Contract_Phase_2025_12_31", Case150);
        yield return ("Finance.Contract_Phase_2026_1_1", Case151);
        yield return ("Finance.Contract_Phase_2026_6_1", Case152);
        yield return ("Finance.Contract_Phase_2026_12_31", Case153);
        yield return ("Finance.Contract_Phase_2027_1_1", Case154);
        yield return ("Finance.Contract_Cancelled", Case155);
        yield return ("Finance.Contract_Duration", Case156);
        yield return ("Finance.Contract_LeapDuration", Case157);
        yield return ("Finance.Contract_Deadline", Case158);
        yield return ("Finance.Contract_Window_2026_10_31", Case159);
        yield return ("Finance.Contract_Window_2026_11_1", Case160);
        yield return ("Finance.Contract_Window_2026_12_1", Case161);
        yield return ("Finance.Contract_Window_2026_12_2", Case162);
        yield return ("Finance.Contract_Window_2026_12_31", Case163);
        yield return ("Finance.Contract_Earned_2025_12_31", Case164);
        yield return ("Finance.Contract_Earned_2026_1_1", Case165);
        yield return ("Finance.Contract_Earned_2026_1_31", Case166);
        yield return ("Finance.Contract_Earned_2026_12_31", Case167);
        yield return ("Finance.Contract_Earned_2027_1_1", Case168);
        yield return ("Finance.Contract_Renew_-1", Case169);
        yield return ("Finance.Contract_Renew_0", Case170);
        yield return ("Finance.Contract_Renew_.1", Case171);
        yield return ("Finance.Contract_TerminationNotice", Case172);
        yield return ("Finance.Contract_TerminationShortNotice", Case173);
        yield return ("Finance.Contract_TerminationEnd", Case174);
        yield return ("Finance.Contract_Remaining", Case175);
        yield return ("Finance.Contract_CancelledRemaining", Case176);
        yield return ("Finance.Contract_Overlap", Case177);
        yield return ("Finance.Contract_NoOverlap", Case178);
        yield return ("Finance.Contract_Invalid_179", Case179);
        yield return ("Finance.Contract_Invalid_180", Case180);
        yield return ("Finance.Contract_Invalid_181", Case181);
        yield return ("Finance.Contract_Invalid_182", Case182);
        yield return ("Finance.Contract_Invalid_183", Case183);
        yield return ("Finance.Return_Eligibility_-1_30_0", Case184);
        yield return ("Finance.Return_Eligibility_0_30_0", Case185);
        yield return ("Finance.Return_Eligibility_30_30_0", Case186);
        yield return ("Finance.Return_Eligibility_31_30_0", Case187);
        yield return ("Finance.Return_Eligibility_0_0_0", Case188);
        yield return ("Finance.Return_Eligibility_1_0_0", Case189);
        yield return ("Finance.Return_Eligibility_14_30_8", Case190);
        yield return ("Finance.Return_Eligibility_14_30_9", Case191);
        yield return ("Finance.Return_Quote_Damaged_false_false", Case192);
        yield return ("Finance.Return_Quote_Damaged_false_true", Case193);
        yield return ("Finance.Return_Quote_Damaged_true_false", Case194);
        yield return ("Finance.Return_Quote_Damaged_true_true", Case195);
        yield return ("Finance.Return_Quote_WrongItem_false_false", Case196);
        yield return ("Finance.Return_Quote_WrongItem_false_true", Case197);
        yield return ("Finance.Return_Quote_WrongItem_true_false", Case198);
        yield return ("Finance.Return_Quote_WrongItem_true_true", Case199);
        yield return ("Finance.Return_Quote_Unwanted_false_false", Case200);
        yield return ("Finance.Return_Quote_Unwanted_false_true", Case201);
        yield return ("Finance.Return_Quote_Unwanted_true_false", Case202);
        yield return ("Finance.Return_Quote_Unwanted_true_true", Case203);
        yield return ("Finance.Return_Discount_0", Case204);
        yield return ("Finance.Return_Discount_1", Case205);
        yield return ("Finance.Return_Discount_2", Case206);
        yield return ("Finance.Return_Discount_3", Case207);
        yield return ("Finance.Return_RefundRemaining", Case208);
        yield return ("Finance.Return_History_Draft", Case209);
        yield return ("Finance.Return_History_Submitted", Case210);
        yield return ("Finance.Return_History_Approved", Case211);
        yield return ("Finance.Return_History_Cancelled", Case212);
        yield return ("Finance.Return_History_Closed", Case213);
        yield return ("Finance.Return_Restock_true", Case214);
        yield return ("Finance.Return_Restock_false", Case215);
        yield return ("Finance.Return_Invalid_216", Case216);
        yield return ("Finance.Return_Invalid_217", Case217);
        yield return ("Finance.Return_Invalid_218", Case218);
        yield return ("Finance.Return_Invalid_219", Case219);
        yield return ("Finance.Return_Invalid_220", Case220);
        yield return ("Finance.Return_Invalid_221", Case221);
    }

    private static Task Case000()
    {
        AssertEx.Equal(InvoiceAgingBucket.Current, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(-1)));
        return Task.CompletedTask;
    }

    private static Task Case001()
    {
        AssertEx.Equal(InvoiceAgingBucket.Current, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(0)));
        return Task.CompletedTask;
    }

    private static Task Case002()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days1To30, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(1)));
        return Task.CompletedTask;
    }

    private static Task Case003()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days1To30, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(29)));
        return Task.CompletedTask;
    }

    private static Task Case004()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days1To30, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(30)));
        return Task.CompletedTask;
    }

    private static Task Case005()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days31To60, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(31)));
        return Task.CompletedTask;
    }

    private static Task Case006()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days31To60, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(60)));
        return Task.CompletedTask;
    }

    private static Task Case007()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days61To90, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(61)));
        return Task.CompletedTask;
    }

    private static Task Case008()
    {
        AssertEx.Equal(InvoiceAgingBucket.Days61To90, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(90)));
        return Task.CompletedTask;
    }

    private static Task Case009()
    {
        AssertEx.Equal(InvoiceAgingBucket.Over90, InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays(91)));
        return Task.CompletedTask;
    }

    private static Task Case010()
    {
        var invoice = Inv() with { Amount = 100m, TaxAmount = 20m, PaidAmount = 0m };
        AssertEx.Equal(120m, InvoicePolicy.Total(invoice));
        AssertEx.Equal(120m, InvoicePolicy.Outstanding(invoice));
        return Task.CompletedTask;
    }

    private static Task Case011()
    {
        var invoice = Inv() with { Amount = 100m, TaxAmount = 20m, PaidAmount = 50m };
        AssertEx.Equal(120m, InvoicePolicy.Total(invoice));
        AssertEx.Equal(70m, InvoicePolicy.Outstanding(invoice));
        return Task.CompletedTask;
    }

    private static Task Case012()
    {
        var invoice = Inv() with { Amount = 100m, TaxAmount = 20m, PaidAmount = 120m };
        AssertEx.Equal(120m, InvoicePolicy.Total(invoice));
        AssertEx.Equal(0m, InvoicePolicy.Outstanding(invoice));
        return Task.CompletedTask;
    }

    private static Task Case013()
    {
        var invoice = Inv() with { Amount = 0m, TaxAmount = 0m, PaidAmount = 0m };
        AssertEx.Equal(0m, InvoicePolicy.Total(invoice));
        AssertEx.Equal(0m, InvoicePolicy.Outstanding(invoice));
        return Task.CompletedTask;
    }

    private static Task Case014()
    {
        var invoice = Inv() with { Amount = 100m, TaxAmount = 0m, PaidAmount = 25m };
        AssertEx.Equal(100m, InvoicePolicy.Total(invoice));
        AssertEx.Equal(75m, InvoicePolicy.Outstanding(invoice));
        return Task.CompletedTask;
    }

    private static Task Case015()
    {
        AssertEx.Equal(12m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(365), .10m, 0));
        return Task.CompletedTask;
    }

    private static Task Case016()
    {
        AssertEx.Equal(.99m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(30), .10m, 0));
        return Task.CompletedTask;
    }

    private static Task Case017()
    {
        AssertEx.Equal(0m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(30), .10m, 30));
        return Task.CompletedTask;
    }

    private static Task Case018()
    {
        AssertEx.Equal(.03m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(31), .10m, 30));
        return Task.CompletedTask;
    }

    private static Task Case019()
    {
        AssertEx.Equal(0m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(365), 0m, 0));
        return Task.CompletedTask;
    }

    private static Task Case020()
    {
        AssertEx.Equal(120m, InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays(365), 1m, 0));
        return Task.CompletedTask;
    }

    private static Task Case021()
    {
        var original = Inv();
        var updated = InvoicePolicy.ApplyPayment(original, 1m);
        AssertEx.Equal(1m, updated.PaidAmount);
        AssertEx.Equal(0m, original.PaidAmount);
        AssertEx.Equal(1, updated.Version);
        return Task.CompletedTask;
    }

    private static Task Case022()
    {
        var original = Inv();
        var updated = InvoicePolicy.ApplyPayment(original, 60m);
        AssertEx.Equal(60m, updated.PaidAmount);
        AssertEx.Equal(0m, original.PaidAmount);
        AssertEx.Equal(1, updated.Version);
        return Task.CompletedTask;
    }

    private static Task Case023()
    {
        var original = Inv();
        var updated = InvoicePolicy.ApplyPayment(original, 120m);
        AssertEx.Equal(120m, updated.PaidAmount);
        AssertEx.Equal(0m, original.PaidAmount);
        AssertEx.Equal(1, updated.Version);
        return Task.CompletedTask;
    }

    private static Task Case024()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.ApplyPayment(Inv(), 0m));
        return Task.CompletedTask;
    }

    private static Task Case025()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.ApplyPayment(Inv(), -1m));
        return Task.CompletedTask;
    }

    private static Task Case026()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.ApplyPayment(Inv(), 121m));
        return Task.CompletedTask;
    }

    private static Task Case027()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.ApplyPayment(Inv() with { Status = DocumentStatus.Closed }, 1));
        return Task.CompletedTask;
    }

    private static Task Case028()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.ApplyPayment(Inv() with { Status = DocumentStatus.Cancelled }, 1));
        return Task.CompletedTask;
    }

    private static Task Case029()
    {
        var newer = Inv() with { Id = "B", DueDate = new(2026, 2, 28) };
        var plan = InvoicePolicy.Allocate(new[] { newer, Inv() }, 150m, "TRY");
        AssertEx.Equal("INV", plan.Allocations[0].InvoiceId);
        AssertEx.Equal(120m, plan.Allocations[0].Amount);
        AssertEx.Equal(30m, plan.Allocations[1].Amount);
        AssertEx.Equal(0m, plan.Unallocated);
        return Task.CompletedTask;
    }

    private static Task Case030()
    {
        AssertEx.Equal(80m, InvoicePolicy.Allocate(new[] { Inv() }, 200m, "TRY").Unallocated);
        return Task.CompletedTask;
    }

    private static Task Case031()
    {
        AssertEx.Equal(200m, InvoicePolicy.Allocate(new[] { Inv() with { Status = DocumentStatus.Closed } }, 200m, "TRY").Unallocated);
        return Task.CompletedTask;
    }

    private static Task Case032()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.Allocate(new[] { Inv(), Inv() }, 50m, "TRY"));
        return Task.CompletedTask;
    }

    private static Task Case033()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.Allocate(new[] { Inv() }, 50m, "USD"));
        return Task.CompletedTask;
    }

    private static Task Case034()
    {
        AssertEx.Throws<DomainValidationException>(() => InvoicePolicy.Interest(Inv(), new(2026, 3, 1), -0.1m));
        return Task.CompletedTask;
    }

    private static Task Case035()
    {
        AssertEx.Equal(InvoiceAgingBucket.Current, InvoicePolicy.Aging(Inv() with { PaidAmount = 120m }, new(2027, 1, 1)));
        return Task.CompletedTask;
    }

    private static Task Case036()
    {
        AssertEx.Equal(120m, InvoicePolicy.AgingTotals(new[] { Inv(), Inv() with { Id = "X", Status = DocumentStatus.Cancelled } }, new(2026, 2, 15), "TRY")[InvoiceAgingBucket.Days1To30]);
        return Task.CompletedTask;
    }

    private static Task Case037()
    {
        AssertEx.Equal(0m, PaymentPolicy.CalculateFee("Cash", 0m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case038()
    {
        AssertEx.Equal(0m, PaymentPolicy.CalculateFee("Cash", 100m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case039()
    {
        AssertEx.Equal(0m, PaymentPolicy.CalculateFee("Transfer", 0m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case040()
    {
        AssertEx.Equal(.50m, PaymentPolicy.CalculateFee("Transfer", .50m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case041()
    {
        AssertEx.Equal(1m, PaymentPolicy.CalculateFee("Transfer", 100m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case042()
    {
        AssertEx.Equal(0m, PaymentPolicy.CalculateFee("Card", 0m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case043()
    {
        AssertEx.Equal(.33m, PaymentPolicy.CalculateFee("Card", 1m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case044()
    {
        AssertEx.Equal(2.80m, PaymentPolicy.CalculateFee("Card", 100m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case045()
    {
        AssertEx.Equal(25.30m, PaymentPolicy.CalculateFee("Card", 1000m, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case046()
    {
        AssertEx.Equal(200m, PaymentPolicy.Convert(100m, "USD", "TRY", 2m));
        return Task.CompletedTask;
    }

    private static Task Case047()
    {
        AssertEx.Equal(50m, PaymentPolicy.Convert(100m, "USD", "TRY", .5m));
        return Task.CompletedTask;
    }

    private static Task Case048()
    {
        AssertEx.Equal(1.01m, PaymentPolicy.Convert(1m, "USD", "TRY", 1.005m));
        return Task.CompletedTask;
    }

    private static Task Case049()
    {
        AssertEx.Equal(0m, PaymentPolicy.Convert(0m, "USD", "TRY", 30m));
        return Task.CompletedTask;
    }

    private static Task Case050()
    {
        AssertEx.Equal(4m, PaymentPolicy.Convert(3m, "USD", "TRY", 1.333m));
        return Task.CompletedTask;
    }

    private static Task Case051()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Convert(10, "TRY", "TRY", 2));
        return Task.CompletedTask;
    }

    private static Task Case052()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Convert(10, "USD", "TRY", 0));
        return Task.CompletedTask;
    }

    private static Task Case053()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Convert(-1, "USD", "TRY", 1));
        return Task.CompletedTask;
    }

    private static Task Case054()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.CalculateFee("Cheque", 10, Fees()));
        return Task.CompletedTask;
    }

    private static Task Case055()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.CalculateFee("Cash", 10, new(-1, 0, 0)));
        return Task.CompletedTask;
    }

    private static Task Case056()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 2), PaymentPolicy.SettlementDate(new(2026, 1, 2), 0));
        return Task.CompletedTask;
    }

    private static Task Case057()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 5), PaymentPolicy.SettlementDate(new(2026, 1, 2), 1));
        return Task.CompletedTask;
    }

    private static Task Case058()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 6), PaymentPolicy.SettlementDate(new(2026, 1, 2), 2));
        return Task.CompletedTask;
    }

    private static Task Case059()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 5), PaymentPolicy.SettlementDate(new(2026, 1, 3), 0));
        return Task.CompletedTask;
    }

    private static Task Case060()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 5), PaymentPolicy.SettlementDate(new(2026, 1, 4), 0));
        return Task.CompletedTask;
    }

    private static Task Case061()
    {
        AssertEx.Equal(new DateOnly(2026, 1, 12), PaymentPolicy.SettlementDate(new(2026, 1, 5), 5));
        return Task.CompletedTask;
    }

    private static Task Case062()
    {
        AssertEx.Equal(95m, PaymentPolicy.NetAmount(Pay()));
        return Task.CompletedTask;
    }

    private static Task Case063()
    {
        AssertEx.Equal(25m, PaymentPolicy.Settle(Pay(), Inv()).RemainingInvoiceBalance);
        return Task.CompletedTask;
    }

    private static Task Case064()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Settle(Pay() with { InvoiceId = "other" }, Inv()));
        return Task.CompletedTask;
    }

    private static Task Case065()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Settle(Pay() with { Currency = "USD" }, Inv()));
        return Task.CompletedTask;
    }

    private static Task Case066()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Settle(Pay() with { Status = DocumentStatus.Draft }, Inv()));
        return Task.CompletedTask;
    }

    private static Task Case067()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Settle(Pay() with { Amount = 200m }, Inv()));
        return Task.CompletedTask;
    }

    private static Task Case068()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Settle(Pay() with { Fee = 100m }, Inv()));
        return Task.CompletedTask;
    }

    private static Task Case069()
    {
        var r = PaymentPolicy.Refund(Pay(), 0m, 20m, true);
        AssertEx.Equal(1m, r.ReversedFee);
        AssertEx.Equal(19m, r.Net);
        AssertEx.Equal(80m, r.RemainingRefundable);
        return Task.CompletedTask;
    }

    private static Task Case070()
    {
        var r = PaymentPolicy.Refund(Pay(), 20m, 80m, true);
        AssertEx.Equal(4m, r.ReversedFee);
        AssertEx.Equal(76m, r.Net);
        AssertEx.Equal(0m, r.RemainingRefundable);
        return Task.CompletedTask;
    }

    private static Task Case071()
    {
        var r = PaymentPolicy.Refund(Pay(), 0m, 100m, true);
        AssertEx.Equal(5m, r.ReversedFee);
        AssertEx.Equal(95m, r.Net);
        AssertEx.Equal(0m, r.RemainingRefundable);
        return Task.CompletedTask;
    }

    private static Task Case072()
    {
        var r = PaymentPolicy.Refund(Pay(), 0m, 20m, false);
        AssertEx.Equal(0m, r.ReversedFee);
        AssertEx.Equal(20m, r.Net);
        AssertEx.Equal(80m, r.RemainingRefundable);
        return Task.CompletedTask;
    }

    private static Task Case073()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Refund(Pay(), -1, 1, true));
        return Task.CompletedTask;
    }

    private static Task Case074()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Refund(Pay(), 0, 0, true));
        return Task.CompletedTask;
    }

    private static Task Case075()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Refund(Pay(), 100, 1, true));
        return Task.CompletedTask;
    }

    private static Task Case076()
    {
        AssertEx.Throws<DomainValidationException>(() => PaymentPolicy.Refund(Pay(), 50, 51, true));
        return Task.CompletedTask;
    }

    private static Task Case077()
    {
        AssertEx.Equal(true, PaymentPolicy.IsDuplicate(Pay(), new[] { Pay() with { Id = "OTHER", Reference = " pay-ref-1 " } }));
        return Task.CompletedTask;
    }

    private static Task Case078()
    {
        AssertEx.Equal(false, PaymentPolicy.IsDuplicate(Pay(), new[] { Pay() with { Id = "OTHER", Status = DocumentStatus.Cancelled } }));
        return Task.CompletedTask;
    }

    private static Task Case079()
    {
        AssertEx.Equal(120m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(0)));
        AssertEx.Equal(0, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(0)));
        return Task.CompletedTask;
    }

    private static Task Case080()
    {
        AssertEx.Equal(110m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(1)));
        AssertEx.Equal(1, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(1)));
        return Task.CompletedTask;
    }

    private static Task Case081()
    {
        AssertEx.Equal(100m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(2)));
        AssertEx.Equal(2, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(2)));
        return Task.CompletedTask;
    }

    private static Task Case082()
    {
        AssertEx.Equal(90m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(3)));
        AssertEx.Equal(3, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(3)));
        return Task.CompletedTask;
    }

    private static Task Case083()
    {
        AssertEx.Equal(80m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(4)));
        AssertEx.Equal(4, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(4)));
        return Task.CompletedTask;
    }

    private static Task Case084()
    {
        AssertEx.Equal(70m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(5)));
        AssertEx.Equal(5, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(5)));
        return Task.CompletedTask;
    }

    private static Task Case085()
    {
        AssertEx.Equal(60m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(6)));
        AssertEx.Equal(6, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(6)));
        return Task.CompletedTask;
    }

    private static Task Case086()
    {
        AssertEx.Equal(50m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(7)));
        AssertEx.Equal(7, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(7)));
        return Task.CompletedTask;
    }

    private static Task Case087()
    {
        AssertEx.Equal(40m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(8)));
        AssertEx.Equal(8, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(8)));
        return Task.CompletedTask;
    }

    private static Task Case088()
    {
        AssertEx.Equal(30m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(9)));
        AssertEx.Equal(9, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(9)));
        return Task.CompletedTask;
    }

    private static Task Case089()
    {
        AssertEx.Equal(20m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(10)));
        AssertEx.Equal(10, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(10)));
        return Task.CompletedTask;
    }

    private static Task Case090()
    {
        AssertEx.Equal(10m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(11)));
        AssertEx.Equal(11, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(11)));
        return Task.CompletedTask;
    }

    private static Task Case091()
    {
        AssertEx.Equal(0m, AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths(12)));
        AssertEx.Equal(12, AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths(12)));
        return Task.CompletedTask;
    }

    private static Task Case092()
    {
        AssertEx.Equal(120m, AssetPolicy.BookValue(Ast(), new(2025, 12, 31)));
        return Task.CompletedTask;
    }

    private static Task Case093()
    {
        AssertEx.Equal(0, AssetPolicy.CompletedMonths(Ast() with { AcquisitionDate = new(2026, 1, 15), BusinessDate = new(2026, 1, 15) }, new(2026, 2, 14)));
        return Task.CompletedTask;
    }

    private static Task Case094()
    {
        AssertEx.Equal(1, AssetPolicy.CompletedMonths(Ast() with { AcquisitionDate = new(2026, 1, 31), BusinessDate = new(2026, 1, 31) }, new(2026, 2, 28)));
        return Task.CompletedTask;
    }

    private static Task Case095()
    {
        AssertEx.Equal(0m, AssetPolicy.BookValue(Ast(), new(2030, 1, 1)));
        return Task.CompletedTask;
    }

    private static Task Case096()
    {
        var s = AssetPolicy.Schedule(Ast() with { Amount = 100m, UsefulLifeMonths = 3 });
        AssertEx.Equal(33.33m, s[0].Charge);
        AssertEx.Equal(33.34m, s[2].Charge);
        AssertEx.Equal(100m, s.Sum(x => x.Charge));
        AssertEx.Equal(0m, s[^1].BookValue);
        return Task.CompletedTask;
    }

    private static Task Case097()
    {
        var s = AssetPolicy.Schedule(Ast() with { SalvageValue = 12m });
        AssertEx.Equal(9m, s[0].Charge);
        AssertEx.Equal(12m, s[^1].BookValue);
        return Task.CompletedTask;
    }

    private static Task Case098()
    {
        AssertEx.Equal(0m, AssetPolicy.MonthlyCharge(Ast() with { SalvageValue = 120m }));
        return Task.CompletedTask;
    }

    private static Task Case099()
    {
        AssertEx.Equal(20m, AssetPolicy.DepreciationBetween(Ast(), new(2026, 2, 1), new(2026, 4, 1)));
        return Task.CompletedTask;
    }

    private static Task Case100()
    {
        AssertEx.Equal(50m, AssetPolicy.UtilizedLifePercent(Ast(), new(2026, 7, 1)));
        return Task.CompletedTask;
    }

    private static Task Case101()
    {
        AssertEx.Equal(6, AssetPolicy.RemainingMonths(Ast(), new(2026, 7, 1)));
        return Task.CompletedTask;
    }

    private static Task Case102()
    {
        AssertEx.Equal(20m, AssetPolicy.Dispose(Ast(), new(2026, 7, 1), 80).GainOrLoss);
        return Task.CompletedTask;
    }

    private static Task Case103()
    {
        AssertEx.Equal(0m, AssetPolicy.Dispose(Ast(), new(2026, 7, 1), 60).GainOrLoss);
        return Task.CompletedTask;
    }

    private static Task Case104()
    {
        AssertEx.Equal(-20m, AssetPolicy.Dispose(Ast(), new(2026, 7, 1), 40).GainOrLoss);
        return Task.CompletedTask;
    }

    private static Task Case105()
    {
        AssertEx.Equal(0m, AssetPolicy.Impairment(Ast(), new(2026, 7, 1), 100));
        return Task.CompletedTask;
    }

    private static Task Case106()
    {
        AssertEx.Equal(0m, AssetPolicy.Impairment(Ast(), new(2026, 7, 1), 60));
        return Task.CompletedTask;
    }

    private static Task Case107()
    {
        AssertEx.Equal(20m, AssetPolicy.Impairment(Ast(), new(2026, 7, 1), 40));
        return Task.CompletedTask;
    }

    private static Task Case108()
    {
        AssertEx.Equal(60m, AssetPolicy.Impairment(Ast(), new(2026, 7, 1), 0));
        return Task.CompletedTask;
    }

    private static Task Case109()
    {
        AssertEx.Throws<DomainValidationException>(() => AssetPolicy.Dispose(Ast(), new(2025, 12, 1), 0));
        return Task.CompletedTask;
    }

    private static Task Case110()
    {
        AssertEx.Throws<DomainValidationException>(() => AssetPolicy.DepreciationBetween(Ast(), new(2026, 3, 1), new(2026, 2, 1)));
        return Task.CompletedTask;
    }

    private static Task Case111()
    {
        AssertEx.Throws<DomainValidationException>(() => AssetPolicy.Schedule(Ast() with { Amount = 1.001m }));
        return Task.CompletedTask;
    }

    private static Task Case112()
    {
        AssertEx.Throws<DomainValidationException>(() => AssetPolicy.Schedule(Ast() with { UsefulLifeMonths = 0 }));
        return Task.CompletedTask;
    }

    private static Task Case113()
    {
        AssertEx.Throws<DomainValidationException>(() => AssetPolicy.Schedule(Ast() with { SalvageValue = 121m }));
        return Task.CompletedTask;
    }

    private static Task Case114()
    {
        AssertEx.Equal(1000m, ExpenseClaimPolicy.CategoryCap("Travel", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case115()
    {
        AssertEx.Equal(2000m, ExpenseClaimPolicy.CategoryCap("Travel", 2, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case116()
    {
        AssertEx.Equal(100m, ExpenseClaimPolicy.CategoryCap("Meal", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case117()
    {
        AssertEx.Equal(300m, ExpenseClaimPolicy.CategoryCap("Meal", 3, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case118()
    {
        AssertEx.Equal(500m, ExpenseClaimPolicy.CategoryCap("Accommodation", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case119()
    {
        AssertEx.Equal(1000m, ExpenseClaimPolicy.CategoryCap("Accommodation", 2, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case120()
    {
        AssertEx.Equal(250m, ExpenseClaimPolicy.CategoryCap("Office", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case121()
    {
        AssertEx.Equal(250m, ExpenseClaimPolicy.CategoryCap("Office", 3, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case122()
    {
        var a = ExpenseClaimPolicy.Assess(Exp() with { Amount = 0, ReceiptAmount = 0 }, 1, "TRY", 1, Limits());
        AssertEx.Equal(0m, a.Reimbursable);
        AssertEx.Equal(0m, a.Excess);
        return Task.CompletedTask;
    }

    private static Task Case123()
    {
        var a = ExpenseClaimPolicy.Assess(Exp() with { Amount = 80, ReceiptAmount = 80 }, 1, "TRY", 1, Limits());
        AssertEx.Equal(80m, a.Reimbursable);
        AssertEx.Equal(0m, a.Excess);
        return Task.CompletedTask;
    }

    private static Task Case124()
    {
        var a = ExpenseClaimPolicy.Assess(Exp() with { Amount = 100, ReceiptAmount = 100 }, 1, "TRY", 1, Limits());
        AssertEx.Equal(100m, a.Reimbursable);
        AssertEx.Equal(0m, a.Excess);
        return Task.CompletedTask;
    }

    private static Task Case125()
    {
        var a = ExpenseClaimPolicy.Assess(Exp() with { Amount = 150, ReceiptAmount = 150 }, 1, "TRY", 1, Limits());
        AssertEx.Equal(100m, a.Reimbursable);
        AssertEx.Equal(50m, a.Excess);
        return Task.CompletedTask;
    }

    private static Task Case126()
    {
        AssertEx.Equal(100m, ExpenseClaimPolicy.Assess(Exp() with { Currency = "USD" }, 1, "TRY", 2, Limits()).Reimbursable);
        return Task.CompletedTask;
    }

    private static Task Case127()
    {
        var e = Exp() with { Status = DocumentStatus.Submitted };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(true, ExpenseClaimPolicy.Approve(e, a, "boss", false).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case128()
    {
        var e = Exp() with { Status = DocumentStatus.Draft };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(false, ExpenseClaimPolicy.Approve(e, a, "boss", true).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case129()
    {
        var e = Exp() with { Status = DocumentStatus.Approved };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(false, ExpenseClaimPolicy.Approve(e, a, "boss", true).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case130()
    {
        var e = Exp() with { Status = DocumentStatus.Submitted };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(false, ExpenseClaimPolicy.Approve(e, a, "E-1", true).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case131()
    {
        var e = Exp() with { Category = "Travel", Amount = 600, ReceiptAmount = 600 };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(false, ExpenseClaimPolicy.Approve(e, a, "boss", false).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case132()
    {
        var e = Exp() with { Category = "Travel", Amount = 600, ReceiptAmount = 600 };
        var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());
        AssertEx.Equal(true, ExpenseClaimPolicy.Approve(e, a, "boss", true).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case133()
    {
        AssertEx.Equal(false, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(-1), 30));
        return Task.CompletedTask;
    }

    private static Task Case134()
    {
        AssertEx.Equal(true, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(0), 0));
        return Task.CompletedTask;
    }

    private static Task Case135()
    {
        AssertEx.Equal(true, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(0), 30));
        return Task.CompletedTask;
    }

    private static Task Case136()
    {
        AssertEx.Equal(true, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(30), 30));
        return Task.CompletedTask;
    }

    private static Task Case137()
    {
        AssertEx.Equal(false, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(31), 30));
        return Task.CompletedTask;
    }

    private static Task Case138()
    {
        AssertEx.Equal(true, ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays(365), 366));
        return Task.CompletedTask;
    }

    private static Task Case139()
    {
        AssertEx.Equal(100m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() with { Status = DocumentStatus.Draft } }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case140()
    {
        AssertEx.Equal(20m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() with { Status = DocumentStatus.Submitted } }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case141()
    {
        AssertEx.Equal(20m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() with { Status = DocumentStatus.Approved } }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case142()
    {
        AssertEx.Equal(100m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() with { Status = DocumentStatus.Cancelled } }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case143()
    {
        AssertEx.Equal(20m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() with { Status = DocumentStatus.Closed } }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case144()
    {
        AssertEx.Equal(0m, ExpenseClaimPolicy.RemainingBudget(new[] { Exp() }, "E-1", "TRY", 50));
        return Task.CompletedTask;
    }

    private static Task Case145()
    {
        AssertEx.Equal(true, ExpenseClaimPolicy.IsPotentialDuplicate(Exp(), new[] { Exp() with { Id = "OTHER" } }));
        return Task.CompletedTask;
    }

    private static Task Case146()
    {
        AssertEx.Throws<DomainValidationException>(() => ExpenseClaimPolicy.CategoryCap("Unknown", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case147()
    {
        AssertEx.Throws<DomainValidationException>(() => ExpenseClaimPolicy.CategoryCap("Meal", 0, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case148()
    {
        AssertEx.Throws<DomainValidationException>(() => ExpenseClaimPolicy.Assess(Exp() with { ReceiptAttached = false }, 1, "TRY", 1, Limits()));
        return Task.CompletedTask;
    }

    private static Task Case149()
    {
        AssertEx.Throws<DomainValidationException>(() => ExpenseClaimPolicy.RemainingBudget(new[] { Exp(), Exp() }, "E-1", "TRY", 100));
        return Task.CompletedTask;
    }

    private static Task Case150()
    {
        AssertEx.Equal(ContractPhase.NotStarted, ContractPolicy.Phase(Ctr(), new(2025,12,31)));
        return Task.CompletedTask;
    }

    private static Task Case151()
    {
        AssertEx.Equal(ContractPhase.Active, ContractPolicy.Phase(Ctr(), new(2026,1,1)));
        return Task.CompletedTask;
    }

    private static Task Case152()
    {
        AssertEx.Equal(ContractPhase.Active, ContractPolicy.Phase(Ctr(), new(2026,6,1)));
        return Task.CompletedTask;
    }

    private static Task Case153()
    {
        AssertEx.Equal(ContractPhase.Active, ContractPolicy.Phase(Ctr(), new(2026,12,31)));
        return Task.CompletedTask;
    }

    private static Task Case154()
    {
        AssertEx.Equal(ContractPhase.Expired, ContractPolicy.Phase(Ctr(), new(2027,1,1)));
        return Task.CompletedTask;
    }

    private static Task Case155()
    {
        AssertEx.Equal(ContractPhase.Cancelled, ContractPolicy.Phase(Ctr() with { Status = DocumentStatus.Cancelled }, new(2026, 1, 1)));
        return Task.CompletedTask;
    }

    private static Task Case156()
    {
        AssertEx.Equal(365, ContractPolicy.DurationDays(Ctr()));
        return Task.CompletedTask;
    }

    private static Task Case157()
    {
        AssertEx.Equal(366, ContractPolicy.DurationDays(Ctr() with { StartDate = new(2024, 1, 1), EndDate = new(2024, 12, 31) }));
        return Task.CompletedTask;
    }

    private static Task Case158()
    {
        AssertEx.Equal(new DateOnly(2026, 12, 1), ContractPolicy.NoticeDeadline(Ctr()));
        return Task.CompletedTask;
    }

    private static Task Case159()
    {
        AssertEx.Equal(false, ContractPolicy.IsRenewalWindow(Ctr(), new(2026,10,31), 60));
        return Task.CompletedTask;
    }

    private static Task Case160()
    {
        AssertEx.Equal(true, ContractPolicy.IsRenewalWindow(Ctr(), new(2026,11,1), 60));
        return Task.CompletedTask;
    }

    private static Task Case161()
    {
        AssertEx.Equal(true, ContractPolicy.IsRenewalWindow(Ctr(), new(2026,12,1), 60));
        return Task.CompletedTask;
    }

    private static Task Case162()
    {
        AssertEx.Equal(false, ContractPolicy.IsRenewalWindow(Ctr(), new(2026,12,2), 60));
        return Task.CompletedTask;
    }

    private static Task Case163()
    {
        AssertEx.Equal(false, ContractPolicy.IsRenewalWindow(Ctr(), new(2026,12,31), 60));
        return Task.CompletedTask;
    }

    private static Task Case164()
    {
        AssertEx.Equal(0m, ContractPolicy.EarnedAmount(Ctr(), new(2025,12,31)));
        return Task.CompletedTask;
    }

    private static Task Case165()
    {
        AssertEx.Equal(1m, ContractPolicy.EarnedAmount(Ctr(), new(2026,1,1)));
        return Task.CompletedTask;
    }

    private static Task Case166()
    {
        AssertEx.Equal(31m, ContractPolicy.EarnedAmount(Ctr(), new(2026,1,31)));
        return Task.CompletedTask;
    }

    private static Task Case167()
    {
        AssertEx.Equal(365m, ContractPolicy.EarnedAmount(Ctr(), new(2026,12,31)));
        return Task.CompletedTask;
    }

    private static Task Case168()
    {
        AssertEx.Equal(365m, ContractPolicy.EarnedAmount(Ctr(), new(2027,1,1)));
        return Task.CompletedTask;
    }

    private static Task Case169()
    {
        var r = ContractPolicy.Renew(Ctr(), new(2026, 12, 1), 12, -1m);
        AssertEx.Equal(0m, r.Amount);
        AssertEx.Equal(new DateOnly(2027, 1, 1), r.Start);
        AssertEx.Equal(new DateOnly(2027, 12, 31), r.End);
        return Task.CompletedTask;
    }

    private static Task Case170()
    {
        var r = ContractPolicy.Renew(Ctr(), new(2026, 12, 1), 12, 0m);
        AssertEx.Equal(365m, r.Amount);
        AssertEx.Equal(new DateOnly(2027, 1, 1), r.Start);
        AssertEx.Equal(new DateOnly(2027, 12, 31), r.End);
        return Task.CompletedTask;
    }

    private static Task Case171()
    {
        var r = ContractPolicy.Renew(Ctr(), new(2026, 12, 1), 12, .1m);
        AssertEx.Equal(401.50m, r.Amount);
        AssertEx.Equal(new DateOnly(2027, 1, 1), r.Start);
        AssertEx.Equal(new DateOnly(2027, 12, 31), r.End);
        return Task.CompletedTask;
    }

    private static Task Case172()
    {
        var t = ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 1, 1), .1m);
        AssertEx.Equal(31m, t.EarnedAmount);
        AssertEx.Equal(334m, t.Refund);
        AssertEx.Equal(0m, t.Penalty);
        return Task.CompletedTask;
    }

    private static Task Case173()
    {
        var t = ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 1, 30), .1m);
        AssertEx.Equal(300.60m, t.Refund);
        AssertEx.Equal(33.40m, t.Penalty);
        return Task.CompletedTask;
    }

    private static Task Case174()
    {
        AssertEx.Equal(0m, ContractPolicy.Terminate(Ctr(), new(2026, 12, 31), new(2026, 12, 31), 1).Refund);
        return Task.CompletedTask;
    }

    private static Task Case175()
    {
        AssertEx.Equal(334m, ContractPolicy.RemainingCommitment(Ctr(), new(2026, 1, 31)));
        return Task.CompletedTask;
    }

    private static Task Case176()
    {
        AssertEx.Equal(0m, ContractPolicy.RemainingCommitment(Ctr() with { Status = DocumentStatus.Cancelled }, new(2026, 1, 31)));
        return Task.CompletedTask;
    }

    private static Task Case177()
    {
        AssertEx.Equal(true, ContractPolicy.Overlaps(Ctr(), Ctr()));
        return Task.CompletedTask;
    }

    private static Task Case178()
    {
        AssertEx.Equal(false, ContractPolicy.Overlaps(Ctr(), Ctr() with { StartDate = new(2027, 1, 1), EndDate = new(2027, 12, 31) }));
        return Task.CompletedTask;
    }

    private static Task Case179()
    {
        AssertEx.Throws<DomainValidationException>(() => ContractPolicy.Renew(Ctr(), new(2026, 12, 2), 12, 0));
        return Task.CompletedTask;
    }

    private static Task Case180()
    {
        AssertEx.Throws<DomainValidationException>(() => ContractPolicy.Renew(Ctr(), new(2026, 11, 1), 0, 0));
        return Task.CompletedTask;
    }

    private static Task Case181()
    {
        AssertEx.Throws<DomainValidationException>(() => ContractPolicy.IsRenewalWindow(Ctr(), new(2026, 11, 1), 10));
        return Task.CompletedTask;
    }

    private static Task Case182()
    {
        AssertEx.Throws<DomainValidationException>(() => ContractPolicy.Terminate(Ctr(), new(2025, 12, 31), new(2025, 12, 1), 0));
        return Task.CompletedTask;
    }

    private static Task Case183()
    {
        AssertEx.Throws<DomainValidationException>(() => ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 2, 1), 0));
        return Task.CompletedTask;
    }

    private static Task Case184()
    {
        AssertEx.Equal(false, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(-1) }, new(2026, 1, 1), 10, 0, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case185()
    {
        AssertEx.Equal(true, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(0) }, new(2026, 1, 1), 10, 0, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case186()
    {
        AssertEx.Equal(true, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(30) }, new(2026, 1, 1), 10, 0, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case187()
    {
        AssertEx.Equal(false, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(31) }, new(2026, 1, 1), 10, 0, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case188()
    {
        AssertEx.Equal(true, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(0) }, new(2026, 1, 1), 10, 0, 0).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case189()
    {
        AssertEx.Equal(false, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(1) }, new(2026, 1, 1), 10, 0, 0).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case190()
    {
        AssertEx.Equal(true, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(14) }, new(2026, 1, 1), 10, 8, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case191()
    {
        AssertEx.Equal(false, ReturnAuthorizationPolicy.Eligibility(Ret() with { BusinessDate = new DateOnly(2026, 1, 1).AddDays(14) }, new(2026, 1, 1), 10, 9, 30).Allowed);
        return Task.CompletedTask;
    }

    private static Task Case192()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Damaged" }, 50, 5, false, false);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(100m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case193()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Damaged" }, 50, 5, false, true);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(100m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case194()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Damaged" }, 50, 5, true, false);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(5m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(105m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case195()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Damaged" }, 50, 5, true, true);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(5m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(105m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case196()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "WrongItem" }, 50, 5, false, false);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(100m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case197()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "WrongItem" }, 50, 5, false, true);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(true, q.RestockInventory);
        AssertEx.Equal(100m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case198()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "WrongItem" }, 50, 5, true, false);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(5m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(105m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case199()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "WrongItem" }, 50, 5, true, true);
        AssertEx.Equal(0m, q.RestockingFee);
        AssertEx.Equal(5m, q.ShippingRefund);
        AssertEx.Equal(true, q.RestockInventory);
        AssertEx.Equal(105m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case200()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Unwanted" }, 50, 5, false, false);
        AssertEx.Equal(10m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(90m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case201()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Unwanted" }, 50, 5, false, true);
        AssertEx.Equal(10m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(true, q.RestockInventory);
        AssertEx.Equal(90m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case202()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Unwanted" }, 50, 5, true, false);
        AssertEx.Equal(10m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(false, q.RestockInventory);
        AssertEx.Equal(90m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case203()
    {
        var q = ReturnAuthorizationPolicy.Quote(Ret() with { Reason = "Unwanted" }, 50, 5, true, true);
        AssertEx.Equal(10m, q.RestockingFee);
        AssertEx.Equal(0m, q.ShippingRefund);
        AssertEx.Equal(true, q.RestockInventory);
        AssertEx.Equal(90m, q.Refund);
        return Task.CompletedTask;
    }

    private static Task Case204()
    {
        AssertEx.Equal(0m, ReturnAuthorizationPolicy.ProratedDiscount(10, 3, 0));
        return Task.CompletedTask;
    }

    private static Task Case205()
    {
        AssertEx.Equal(3.33m, ReturnAuthorizationPolicy.ProratedDiscount(10, 3, 1));
        return Task.CompletedTask;
    }

    private static Task Case206()
    {
        AssertEx.Equal(6.67m, ReturnAuthorizationPolicy.ProratedDiscount(10, 3, 2));
        return Task.CompletedTask;
    }

    private static Task Case207()
    {
        AssertEx.Equal(10m, ReturnAuthorizationPolicy.ProratedDiscount(10, 3, 3));
        return Task.CompletedTask;
    }

    private static Task Case208()
    {
        AssertEx.Equal(10m, ReturnAuthorizationPolicy.RefundRemaining(100, 0, new(100, 10, 0, 90, true)));
        return Task.CompletedTask;
    }

    private static Task Case209()
    {
        AssertEx.Equal(10, ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret() with { Status = DocumentStatus.Draft } }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case210()
    {
        AssertEx.Equal(8, ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret() with { Status = DocumentStatus.Submitted } }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case211()
    {
        AssertEx.Equal(8, ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret() with { Status = DocumentStatus.Approved } }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case212()
    {
        AssertEx.Equal(10, ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret() with { Status = DocumentStatus.Cancelled } }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case213()
    {
        AssertEx.Equal(8, ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret() with { Status = DocumentStatus.Closed } }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case214()
    {
        AssertEx.Equal(2, ReturnAuthorizationPolicy.RestockQuantity(Ret(), new(100, 0, 0, 100, true)));
        return Task.CompletedTask;
    }

    private static Task Case215()
    {
        AssertEx.Equal(0, ReturnAuthorizationPolicy.RestockQuantity(Ret(), new(100, 0, 0, 100, false)));
        return Task.CompletedTask;
    }

    private static Task Case216()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.Quote(Ret(), 51, 0, false, true));
        return Task.CompletedTask;
    }

    private static Task Case217()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.RefundRemaining(80, 0, new(100, 10, 0, 90, true)));
        return Task.CompletedTask;
    }

    private static Task Case218()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.RefundRemaining(100, 0, new(100, 10, 0, 100, true)));
        return Task.CompletedTask;
    }

    private static Task Case219()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret(), Ret() }, "SO-1"));
        return Task.CompletedTask;
    }

    private static Task Case220()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.ProratedDiscount(10, 0, 0));
        return Task.CompletedTask;
    }

    private static Task Case221()
    {
        AssertEx.Throws<DomainValidationException>(() => ReturnAuthorizationPolicy.RestockQuantity(Ret() with { Status = DocumentStatus.Draft }, new(100, 0, 0, 100, true)));
        return Task.CompletedTask;
    }

    private static Invoice Inv() => new() { Id = "INV", Code = "INV-1", Amount = 100m, TaxAmount = 20m, DueDate = new(2026, 1, 31), Status = DocumentStatus.Approved };
    private static Payment Pay() => new() { Id = "PAY", Code = "PAY-1", InvoiceId = "INV", Amount = 100m, Fee = 5m, Status = DocumentStatus.Fulfilled };
    private static PaymentFeeSchedule Fees() => new(1m, .30m, .025m);
    private static Asset Ast() => new() { Id = "AST", Code = "AST-1", Amount = 120m, UsefulLifeMonths = 12 };
    private static ExpenseClaim Exp() => new() { Id = "EXP", Code = "EXP-1", Amount = 80m, ReceiptAmount = 80m, Category = "Meal", Status = DocumentStatus.Submitted };
    private static ExpenseLimits Limits() => new(1000, 100, 500, 250, 500);
    private static Contract Ctr() => new() { Id = "CTR", Code = "CTR-1", Amount = 365m };
    private static ReturnAuthorization Ret() => new() { Id = "RET", Code = "RET-1", Amount = 100m, Quantity = 2, Reason = "Unwanted", RestockingPercent = 10m, BusinessDate = new(2026, 1, 15), Status = DocumentStatus.Approved };
}
