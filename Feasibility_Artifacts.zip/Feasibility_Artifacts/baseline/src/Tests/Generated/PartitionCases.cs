namespace Benchmark.Tests;
public static class PartitionCases
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
        foreach (var item in PurchaseOrderPartitions.All()) yield return item;
        foreach (var item in SalesOrderPartitions.All()) yield return item;
        foreach (var item in SupplierPartitions.All()) yield return item;
        foreach (var item in CustomerPartitions.All()) yield return item;
        foreach (var item in ProductPartitions.All()) yield return item;
        foreach (var item in WarehousePartitions.All()) yield return item;
        foreach (var item in InvoicePartitions.All()) yield return item;
        foreach (var item in PaymentPartitions.All()) yield return item;
        foreach (var item in ShipmentPartitions.All()) yield return item;
        foreach (var item in AssetPartitions.All()) yield return item;
        foreach (var item in WorkOrderPartitions.All()) yield return item;
        foreach (var item in EmployeePartitions.All()) yield return item;
        foreach (var item in ExpenseClaimPartitions.All()) yield return item;
        foreach (var item in ReturnAuthorizationPartitions.All()) yield return item;
        foreach (var item in ContractPartitions.All()) yield return item;
    }
}
