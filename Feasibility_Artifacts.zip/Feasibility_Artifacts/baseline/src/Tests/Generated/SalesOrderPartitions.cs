// Generated validation partitions from expand_benchmark.py; stable independent case names.
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;
public static class SalesOrderPartitions
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
        yield return ("SalesOrder.Partition.Id.Empty", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.Whitespace", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = " " };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.EmbeddedSpace", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = "bad id" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.TooLong", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = new string('i',65) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.Empty", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.Whitespace", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = " " };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.TooLong", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = new string('c',41) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.NegativeCent", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = -0.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.NegativeWhole", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = -1m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.BeyondLimit", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = 1000000000.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Empty", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Short", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TR" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Long", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TRYY" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Lower", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "try" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Digit", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TR1" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Space", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "T R" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.BusinessDate.TooEarly", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { BusinessDate = new DateOnly(1999,12,31) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.BusinessDate.TooLate", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { BusinessDate = new DateOnly(2101,1,1) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Description.TooLong", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Description = new string('d',2001) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Version.NegativeOne", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Version = -1 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Version.NegativeLarge", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Version = -100 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.BelowEnum", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Status = (DocumentStatus)(-1) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.AboveEnum", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Status = (DocumentStatus)6 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.One.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "a" };
            candidate.Validate();
            AssertEx.Equal("a", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.Limit.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = new string('i',64) };
            candidate.Validate();
            AssertEx.Equal(new string('i',64), candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.Dash.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "id-a" };
            candidate.Validate();
            AssertEx.Equal("id-a", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Id.Digits.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "12345" };
            candidate.Validate();
            AssertEx.Equal("12345", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.One.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = "c" };
            candidate.Validate();
            AssertEx.Equal("c", candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.Limit.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = new string('c',40) };
            candidate.Validate();
            AssertEx.Equal(new string('c',40), candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Code.SpaceInside.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = "CODE A" };
            candidate.Validate();
            AssertEx.Equal("CODE A", candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.Zero.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 0m };
            candidate.Validate();
            AssertEx.Equal(0m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.Cent.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 0.01m };
            candidate.Validate();
            AssertEx.Equal(0.01m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Amount.Normal.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 100m };
            candidate.Validate();
            AssertEx.Equal(100m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.TRY.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "TRY" };
            candidate.Validate();
            AssertEx.Equal("TRY", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.USD.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "USD" };
            candidate.Validate();
            AssertEx.Equal("USD", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.EUR.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "EUR" };
            candidate.Validate();
            AssertEx.Equal("EUR", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Currency.Synthetic.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "ZZZ" };
            candidate.Validate();
            AssertEx.Equal("ZZZ", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Description.Empty.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = "" };
            candidate.Validate();
            AssertEx.Equal("", candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Description.One.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = "d" };
            candidate.Validate();
            AssertEx.Equal("d", candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Description.Limit.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = new string('d',2000) };
            candidate.Validate();
            AssertEx.Equal(new string('d',2000), candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Version.Zero.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 0 };
            candidate.Validate();
            AssertEx.Equal(0, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Version.One.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 1 };
            candidate.Validate();
            AssertEx.Equal(1, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Version.Large.Accepted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 1000000 };
            candidate.Validate();
            AssertEx.Equal(1000000, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Specific.CustomerId.0", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { CustomerId = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Specific.PromisedDate.1", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { PromisedDate = new DateOnly(2025,12,31) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Specific.TaxPercent.2", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { TaxPercent = -0.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Specific.TaxPercent.3", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { TaxPercent = 100.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Specific.CreditLimit.4", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { CreditLimit = -1m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Submitted);
            AssertEx.Equal(DocumentStatus.Submitted, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.DraftToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Draft);
            AssertEx.Equal(DocumentStatus.Draft, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Approved);
            AssertEx.Equal(DocumentStatus.Approved, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.SubmittedToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Fulfilled);
            AssertEx.Equal(DocumentStatus.Fulfilled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ApprovedToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            var updated = (SalesOrder)original.NextStatus(DocumentStatus.Closed);
            AssertEx.Equal(DocumentStatus.Closed, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.FulfilledToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.ClosedToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToDraft", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToSubmitted", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToApproved", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToFulfilled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToClosed", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Status.CancelledToCancelled", async () =>
        {
            var original = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.StaleExpectedVersion.0", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 0));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.StaleExpectedVersion.2", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 2));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.StaleExpectedVersion.7", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 7));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.StaleExpectedVersion.Minus1", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, -1));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.TerminalCreate.Submitted", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var candidate = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.TerminalCreate.Approved", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var candidate = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.TerminalCreate.Fulfilled", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var candidate = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.TerminalCreate.Closed", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var candidate = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.TerminalCreate.Cancelled", async () =>
        {
            var service = new DocumentService<SalesOrder>(new InMemoryDatabaseSession());
            var candidate = new SalesOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Rollback.InvalidOperationException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<InvalidOperationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new InvalidOperationException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<SalesOrder>("id") is null);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Rollback.DomainValidationException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<DomainValidationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new DomainValidationException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<SalesOrder>("id") is null);
            await Task.CompletedTask;
        });
        yield return ("SalesOrder.Partition.Rollback.ConcurrencyConflictException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new SalesOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new ConcurrencyConflictException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<SalesOrder>("id") is null);
            await Task.CompletedTask;
        });
    }
}
