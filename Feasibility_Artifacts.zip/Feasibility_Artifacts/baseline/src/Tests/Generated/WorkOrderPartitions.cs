// Generated validation partitions from expand_benchmark.py; stable independent case names.
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;
public static class WorkOrderPartitions
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
        yield return ("WorkOrder.Partition.Id.Empty", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.Whitespace", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = " " };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.EmbeddedSpace", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = "bad id" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.TooLong", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Id = new string('i',65) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.Empty", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.Whitespace", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = " " };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.TooLong", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Code = new string('c',41) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.NegativeCent", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = -0.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.NegativeWhole", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = -1m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.BeyondLimit", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Amount = 1000000000.01m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Empty", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Short", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TR" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Long", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TRYY" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Lower", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "try" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Digit", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "TR1" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Space", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Currency = "T R" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.BusinessDate.TooEarly", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { BusinessDate = new DateOnly(1999,12,31) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.BusinessDate.TooLate", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { BusinessDate = new DateOnly(2101,1,1) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Description.TooLong", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Description = new string('d',2001) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Version.NegativeOne", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Version = -1 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Version.NegativeLarge", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Version = -100 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.BelowEnum", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Status = (DocumentStatus)(-1) };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.AboveEnum", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Status = (DocumentStatus)6 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.One.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "a" };
            candidate.Validate();
            AssertEx.Equal("a", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.Limit.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = new string('i',64) };
            candidate.Validate();
            AssertEx.Equal(new string('i',64), candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.Dash.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "id-a" };
            candidate.Validate();
            AssertEx.Equal("id-a", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Id.Digits.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Id = "12345" };
            candidate.Validate();
            AssertEx.Equal("12345", candidate.Id);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.One.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = "c" };
            candidate.Validate();
            AssertEx.Equal("c", candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.Limit.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = new string('c',40) };
            candidate.Validate();
            AssertEx.Equal(new string('c',40), candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Code.SpaceInside.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Code = "CODE A" };
            candidate.Validate();
            AssertEx.Equal("CODE A", candidate.Code);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.Zero.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 0m };
            candidate.Validate();
            AssertEx.Equal(0m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.Cent.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 0.01m };
            candidate.Validate();
            AssertEx.Equal(0.01m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Amount.Normal.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Amount = 100m };
            candidate.Validate();
            AssertEx.Equal(100m, candidate.Amount);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.TRY.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "TRY" };
            candidate.Validate();
            AssertEx.Equal("TRY", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.USD.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "USD" };
            candidate.Validate();
            AssertEx.Equal("USD", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.EUR.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "EUR" };
            candidate.Validate();
            AssertEx.Equal("EUR", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Currency.Synthetic.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Currency = "ZZZ" };
            candidate.Validate();
            AssertEx.Equal("ZZZ", candidate.Currency);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Description.Empty.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = "" };
            candidate.Validate();
            AssertEx.Equal("", candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Description.One.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = "d" };
            candidate.Validate();
            AssertEx.Equal("d", candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Description.Limit.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Description = new string('d',2000) };
            candidate.Validate();
            AssertEx.Equal(new string('d',2000), candidate.Description);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Version.Zero.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 0 };
            candidate.Validate();
            AssertEx.Equal(0, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Version.One.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 1 };
            candidate.Validate();
            AssertEx.Equal(1, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Version.Large.Accepted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            var candidate = original with { Version = 1000000 };
            candidate.Validate();
            AssertEx.Equal(1000000, candidate.Version);
            AssertEx.Equal("code", original.Code);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.AssetId.0", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { AssetId = "" };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.Priority.1", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Priority = 0 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.Priority.2", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { Priority = 6 };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.PlannedHours.3", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { PlannedHours = -1m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.PlannedHours.4", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { PlannedHours = 10001m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.ActualHours.5", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { ActualHours = -1m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Specific.ActualHours.6", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m };
            original.Validate();
            var invalid = original with { ActualHours = 10001m };
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Submitted);
            AssertEx.Equal(DocumentStatus.Submitted, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Draft, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.DraftToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Draft, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Draft);
            AssertEx.Equal(DocumentStatus.Draft, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Approved);
            AssertEx.Equal(DocumentStatus.Approved, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Submitted, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.SubmittedToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Fulfilled);
            AssertEx.Equal(DocumentStatus.Fulfilled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Approved, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ApprovedToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Cancelled);
            AssertEx.Equal(DocumentStatus.Cancelled, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            var updated = (WorkOrder)original.NextStatus(DocumentStatus.Closed);
            AssertEx.Equal(DocumentStatus.Closed, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.FulfilledToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Fulfilled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.ClosedToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Closed, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToDraft", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Draft));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToSubmitted", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Submitted));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToApproved", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Approved));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToFulfilled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Fulfilled));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToClosed", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Closed));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Status.CancelledToCancelled", async () =>
        {
            var original = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled, Version = 7 };
            original.Validate();
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.Cancelled));
            AssertEx.Equal(DocumentStatus.Cancelled, original.Status);
            AssertEx.Equal(7, original.Version);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.StaleExpectedVersion.0", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 0));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.StaleExpectedVersion.2", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 2));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.StaleExpectedVersion.7", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, 7));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.StaleExpectedVersion.Minus1", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m });
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with { Description = "stale" }, -1));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.TerminalCreate.Submitted", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var candidate = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Submitted };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.TerminalCreate.Approved", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var candidate = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Approved };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.TerminalCreate.Fulfilled", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var candidate = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Fulfilled };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.TerminalCreate.Closed", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var candidate = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Closed };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.TerminalCreate.Cancelled", async () =>
        {
            var service = new DocumentService<WorkOrder>(new InMemoryDatabaseSession());
            var candidate = new WorkOrder { Id = "id", Code = "code", Amount = 100m } with { Status = DocumentStatus.Cancelled };
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Rollback.InvalidOperationException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<InvalidOperationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new InvalidOperationException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<WorkOrder>("id") is null);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Rollback.DomainValidationException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<DomainValidationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new DomainValidationException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<WorkOrder>("id") is null);
            await Task.CompletedTask;
        });
        yield return ("WorkOrder.Partition.Rollback.ConcurrencyConflictException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(new WorkOrder { Id = "id", Code = "code", Amount = 100m }, token);
                throw new ConcurrencyConflictException("injected persistence fault");
            }));
            AssertEx.True(await session.FindAsync<WorkOrder>("id") is null);
            await Task.CompletedTask;
        });
    }
}
