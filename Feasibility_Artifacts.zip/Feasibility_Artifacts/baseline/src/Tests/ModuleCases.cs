using Benchmark.Domain;
namespace Benchmark.Tests;
public static class ModuleCases
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
        var cases = new List<(string, Func<Task>)>();
        cases.AddRange(GenericDocumentCases.For<PurchaseOrder>(id => new PurchaseOrder { Id = id, Code = "PurchaseOrder-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<SalesOrder>(id => new SalesOrder { Id = id, Code = "SalesOrder-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Supplier>(id => new Supplier { Id = id, Code = "Supplier-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Customer>(id => new Customer { Id = id, Code = "Customer-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Product>(id => new Product { Id = id, Code = "Product-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Warehouse>(id => new Warehouse { Id = id, Code = "Warehouse-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Invoice>(id => new Invoice { Id = id, Code = "Invoice-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Payment>(id => new Payment { Id = id, Code = "Payment-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Shipment>(id => new Shipment { Id = id, Code = "Shipment-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Asset>(id => new Asset { Id = id, Code = "Asset-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<WorkOrder>(id => new WorkOrder { Id = id, Code = "WorkOrder-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Employee>(id => new Employee { Id = id, Code = "Employee-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<ExpenseClaim>(id => new ExpenseClaim { Id = id, Code = "ExpenseClaim-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<ReturnAuthorization>(id => new ReturnAuthorization { Id = id, Code = "ReturnAuthorization-" + id, Amount = 100m }));
        cases.AddRange(GenericDocumentCases.For<Contract>(id => new Contract { Id = id, Code = "Contract-" + id, Amount = 100m }));
        return cases;
    }
}
