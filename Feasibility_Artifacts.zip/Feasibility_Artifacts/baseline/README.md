# CAI enterprise engineering feasibility benchmark

This is a purpose-built synthetic C#/.NET 8 benchmark, generated for a bounded engineering feasibility experiment. It is not production software, a previously observed enterprise codebase, or a participant study. Domain schemas and regression cases are programmatically generated from 15 explicit business-module specifications; shared implementations avoid source padding.

## Architecture

* Domain: immutable ERP documents, validation rules, lifecycle transitions, purchase lines, stock and audit records.
* Application: application-owned storage/audit ports, generic document operations, three task-facing workflow services, and 15 module-specific synthetic business policy classes.
* Infrastructure: in-process immutable-record storage, transaction staging and audit sink.
* Api: ASP.NET Core minimal endpoints for 15 document modules plus workflow routes.
* Tests: package-free console runner with module lifecycle, validation, concurrency-version, rollback and architectural dependency cases.

The adapter has no crash durability and is not a general database. Transaction staging serializes transaction callbacks; direct writes outside those callbacks are not serializable with transactions. All data are synthetic. Endpoints are intentionally local laboratory interfaces and have no production authentication deployment.

## Reproduce

Use .NET SDK 8.0.425 (pinned in global.json). No NuGet packages are required; NuGet.Config clears package sources.

```
dotnet restore Benchmark.sln --configfile NuGet.Config --disable-parallel -m:1 -nr:false
dotnet build Benchmark.sln --no-restore -c Release -m:1 -nr:false
dotnet run --project src/Tests/Benchmark.Tests.csproj --no-build -c Release
dotnet run --project src/Api/Benchmark.Api.csproj --no-build -c Release --urls http://127.0.0.1:5088
```

The test program reports actual assertions and elapsed times as JSON. API startup is not part of the timed gate workload unless the run manifest says so. No xUnit/MSTest or external analyzer download is needed.

## Task snapshots

T1 procurement abstraction refactoring, T2 sales audit delivery, and T3 inventory concurrency correction start from the same frozen commit, with independent resets. Normal public tests pass on the baseline. Task-specific hidden acceptance checks are kept outside this repository. These are distinct independent task patches, not a sequential evolution of one repository.

T1 has direct application access to the application-owned IDatabaseSession port; this is a design refactoring opportunity, not a pre-existing application-to-infrastructure reference violation. T2 currently performs business updates without audit delivery. T3 includes a lost-update path in ReserveAsync; IReservationObserver allows a deterministic interleaving in external tests. The defects/missing features are known seeded task conditions, not natural field prevalence.

The provenance manifest reports 17,914 physical C# lines: 1,895 implementation lines and 16,019 test lines. Generated validation/lifecycle partitions account for much of the test volume and repeat structure across concrete schemas. These counts are not equivalent to production-code volume or industrial representativeness. The frozen baseline passes 2,016 individually named regression cases. Physical/nonblank line counts include braces and, for nonblank counts, comments; they are not lexical NCLOC.

All financial, employment, procurement, and logistics conventions in policy modules are explicit synthetic fixture rules, not jurisdictional or enterprise policy claims. The `provenance/` directory retains actual generation traces and their limits. The git snapshot, not a single generator script, is the authoritative baseline. Task prompts are in `tasks/`.
