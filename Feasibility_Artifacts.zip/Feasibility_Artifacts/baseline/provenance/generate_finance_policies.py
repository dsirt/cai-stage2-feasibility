from pathlib import Path

# Deterministic test-source generator. Policy implementations are hand-written.
# Fixed oracles below represent synthetic fixture business conventions.
cases=[]
def add(group,name,body): cases.append((group+'_'+name,body))
def eq(expected,actual): return f'AssertEx.Equal({expected}, {actual});'
def bad(call): return f'AssertEx.Throws<DomainValidationException>(() => {call});'
# Invoice aging boundaries, payment conservation, oldest-first allocation.
for day,bucket in [(-1,'Current'),(0,'Current'),(1,'Days1To30'),(29,'Days1To30'),(30,'Days1To30'),(31,'Days31To60'),(60,'Days31To60'),(61,'Days61To90'),(90,'Days61To90'),(91,'Over90')]:
 add('Invoice',f'Aging_{day+1}',eq('InvoiceAgingBucket.'+bucket,f'InvoicePolicy.Aging(Inv(), Inv().DueDate.AddDays({day}))'))
for amount,tax,paid,total,open_ in [(100,20,0,120,120),(100,20,50,120,70),(100,20,120,120,0),(0,0,0,0,0),(100,0,25,100,75)]:
 add('Invoice',f'Balance_{amount}_{tax}_{paid}',f'var invoice = Inv() with {{ Amount = {amount}m, TaxAmount = {tax}m, PaidAmount = {paid}m }};'+eq(str(total)+'m','InvoicePolicy.Total(invoice)')+eq(str(open_)+'m','InvoicePolicy.Outstanding(invoice)'))
for days,rate,grace,expected in [(365,'.10',0,'12'),(30,'.10',0,'.99'),(30,'.10',30,'0'),(31,'.10',30,'.03'),(365,'0',0,'0'),(365,'1',0,'120')]:
 add('Invoice',f'Interest_{days}_{rate}_{grace}',eq(expected+'m',f'InvoicePolicy.Interest(Inv(), Inv().DueDate.AddDays({days}), {rate}m, {grace})'))
for paid in [1,60,120]:
 add('Invoice',f'Apply_{paid}',f'var original = Inv(); var updated = InvoicePolicy.ApplyPayment(original, {paid}m);'+eq(str(paid)+'m','updated.PaidAmount')+eq('0m','original.PaidAmount')+eq('1','updated.Version'))
for amount in ['0','-1','121']:
 add('Invoice','RejectPayment_'+amount,bad(f'InvoicePolicy.ApplyPayment(Inv(), {amount}m)'))
for status in ['Closed','Cancelled']:
 add('Invoice','Closed_'+status,bad(f'InvoicePolicy.ApplyPayment(Inv() with {{ Status = DocumentStatus.{status} }}, 1)'))
add('Invoice','AllocateDueOrder','var newer = Inv() with { Id = "B", DueDate = new(2026, 2, 28) }; var plan = InvoicePolicy.Allocate(new[] { newer, Inv() }, 150m, "TRY");'+eq('"INV"','plan.Allocations[0].InvoiceId')+eq('120m','plan.Allocations[0].Amount')+eq('30m','plan.Allocations[1].Amount')+eq('0m','plan.Unallocated'))
add('Invoice','AllocateRemainder',eq('80m','InvoicePolicy.Allocate(new[] { Inv() }, 200m, "TRY").Unallocated'))
add('Invoice','AllocateClosed',eq('200m','InvoicePolicy.Allocate(new[] { Inv() with { Status = DocumentStatus.Closed } }, 200m, "TRY").Unallocated'))
add('Invoice','DuplicateInput',bad('InvoicePolicy.Allocate(new[] { Inv(), Inv() }, 50m, "TRY")'))
add('Invoice','CurrencyMismatch',bad('InvoicePolicy.Allocate(new[] { Inv() }, 50m, "USD")'))
add('Invoice','InvalidRate',bad('InvoicePolicy.Interest(Inv(), new(2026, 3, 1), -0.1m)'))
add('Invoice','AgingPaid',eq('InvoiceAgingBucket.Current','InvoicePolicy.Aging(Inv() with { PaidAmount = 120m }, new(2027, 1, 1))'))
add('Invoice','AgingTotals',eq('120m','InvoicePolicy.AgingTotals(new[] { Inv(), Inv() with { Id = "X", Status = DocumentStatus.Cancelled } }, new(2026, 2, 15), "TRY")[InvoiceAgingBucket.Days1To30]'))
# Payment fee, conversion, settlement and refund contracts.
for method,gross,expected in [('Cash','0','0'),('Cash','100','0'),('Transfer','0','0'),('Transfer','.50','.50'),('Transfer','100','1'),('Card','0','0'),('Card','1','.33'),('Card','100','2.80'),('Card','1000','25.30')]:
 add('Payment',f'Fee_{method}_{gross}',eq(expected+'m',f'PaymentPolicy.CalculateFee("{method}", {gross}m, Fees())'))
for amount,rate,expected in [('100','2','200'),('100','.5','50'),('1','1.005','1.01'),('0','30','0'),('3','1.333','4')]:
 add('Payment',f'Convert_{amount}_{rate}',eq(expected+'m',f'PaymentPolicy.Convert({amount}m, "USD", "TRY", {rate}m)'))
for expression in ['PaymentPolicy.Convert(10, "TRY", "TRY", 2)','PaymentPolicy.Convert(10, "USD", "TRY", 0)','PaymentPolicy.Convert(-1, "USD", "TRY", 1)','PaymentPolicy.CalculateFee("Cheque", 10, Fees())','PaymentPolicy.CalculateFee("Cash", 10, new(-1, 0, 0))']:
 add('Payment',f'Invalid_{len(cases)}',bad(expression))
for day,days,expected in [(2,0,2),(2,1,5),(2,2,6),(3,0,5),(4,0,5),(5,5,12)]:
 add('Payment',f'SettlementDate_{day}_{days}',eq(f'new DateOnly(2026, 1, {expected})',f'PaymentPolicy.SettlementDate(new(2026, 1, {day}), {days})'))
add('Payment','Net',eq('95m','PaymentPolicy.NetAmount(Pay())'))
add('Payment','Settle',eq('25m','PaymentPolicy.Settle(Pay(), Inv()).RemainingInvoiceBalance'))
for mutation in ['InvoiceId = "other"','Currency = "USD"','Status = DocumentStatus.Draft','Amount = 200m','Fee = 100m']:
 add('Payment',f'SettleReject_{len(cases)}',bad(f'PaymentPolicy.Settle(Pay() with {{ {mutation} }}, Inv())'))
for already,requested,reverse,fee,net,remaining in [('0','20','true','1','19','80'),('20','80','true','4','76','0'),('0','100','true','5','95','0'),('0','20','false','0','20','80')]:
 add('Payment',f'Refund_{already}_{requested}_{reverse}',f'var r = PaymentPolicy.Refund(Pay(), {already}m, {requested}m, {reverse});'+eq(fee+'m','r.ReversedFee')+eq(net+'m','r.Net')+eq(remaining+'m','r.RemainingRefundable'))
for already,requested in [(-1,1),(0,0),(100,1),(50,51)]:
 add('Payment',f'RefundInvalid_{already}_{requested}',bad(f'PaymentPolicy.Refund(Pay(), {already}, {requested}, true)'))
add('Payment','DuplicateReference',eq('true','PaymentPolicy.IsDuplicate(Pay(), new[] { Pay() with { Id = "OTHER", Reference = " pay-ref-1 " } })'))
add('Payment','CancelledNotDuplicate',eq('false','PaymentPolicy.IsDuplicate(Pay(), new[] { Pay() with { Id = "OTHER", Status = DocumentStatus.Cancelled } })'))
# Asset anniversary boundaries, residue allocation, impairment and disposal.
for months in range(0,13):
 add('Asset',f'BookMonth_{months}',eq(f'{120-months*10}m',f'AssetPolicy.BookValue(Ast(), new DateOnly(2026, 1, 1).AddMonths({months}))')+eq(str(months),f'AssetPolicy.CompletedMonths(Ast(), new DateOnly(2026, 1, 1).AddMonths({months}))'))
add('Asset','BeforeAcquisition',eq('120m','AssetPolicy.BookValue(Ast(), new(2025, 12, 31))'))
add('Asset','BeforeAnniversary',eq('0','AssetPolicy.CompletedMonths(Ast() with { AcquisitionDate = new(2026, 1, 15), BusinessDate = new(2026, 1, 15) }, new(2026, 2, 14))'))
add('Asset','MonthEndAnniversary',eq('1','AssetPolicy.CompletedMonths(Ast() with { AcquisitionDate = new(2026, 1, 31), BusinessDate = new(2026, 1, 31) }, new(2026, 2, 28))'))
add('Asset','BeyondLife',eq('0m','AssetPolicy.BookValue(Ast(), new(2030, 1, 1))'))
add('Asset','ResidualSchedule','var s = AssetPolicy.Schedule(Ast() with { Amount = 100m, UsefulLifeMonths = 3 });'+eq('33.33m','s[0].Charge')+eq('33.34m','s[2].Charge')+eq('100m','s.Sum(x => x.Charge)')+eq('0m','s[^1].BookValue'))
add('Asset','SalvageSchedule','var s = AssetPolicy.Schedule(Ast() with { SalvageValue = 12m });'+eq('9m','s[0].Charge')+eq('12m','s[^1].BookValue'))
add('Asset','ZeroBasis',eq('0m','AssetPolicy.MonthlyCharge(Ast() with { SalvageValue = 120m })'))
add('Asset','Interval',eq('20m','AssetPolicy.DepreciationBetween(Ast(), new(2026, 2, 1), new(2026, 4, 1))'))
add('Asset','LifePercent',eq('50m','AssetPolicy.UtilizedLifePercent(Ast(), new(2026, 7, 1))'))
add('Asset','RemainingLife',eq('6','AssetPolicy.RemainingMonths(Ast(), new(2026, 7, 1))'))
for proceeds,gain in [(80,20),(60,0),(40,-20)]:
 add('Asset',f'Disposal_{proceeds}',eq(f'{gain}m',f'AssetPolicy.Dispose(Ast(), new(2026, 7, 1), {proceeds}).GainOrLoss'))
for recovery,expected in [(100,0),(60,0),(40,20),(0,60)]:
 add('Asset',f'Impairment_{recovery}',eq(f'{expected}m',f'AssetPolicy.Impairment(Ast(), new(2026, 7, 1), {recovery})'))
for expression in ['AssetPolicy.Dispose(Ast(), new(2025, 12, 1), 0)','AssetPolicy.DepreciationBetween(Ast(), new(2026, 3, 1), new(2026, 2, 1))','AssetPolicy.Schedule(Ast() with { Amount = 1.001m })','AssetPolicy.Schedule(Ast() with { UsefulLifeMonths = 0 })','AssetPolicy.Schedule(Ast() with { SalvageValue = 121m })']:
 add('Asset',f'Invalid_{len(cases)}',bad(expression))
# Expense reimbursement caps, authorization boundaries, budgets and duplicates.
for category,days,expected in [('Travel',1,1000),('Travel',2,2000),('Meal',1,100),('Meal',3,300),('Accommodation',1,500),('Accommodation',2,1000),('Office',1,250),('Office',3,250)]:
 add('Expense',f'Cap_{category}_{days}',eq(f'{expected}m',f'ExpenseClaimPolicy.CategoryCap("{category}", {days}, Limits())'))
for amount,expected,excess in [(0,0,0),(80,80,0),(100,100,0),(150,100,50)]:
 add('Expense',f'Assess_{amount}',f'var a = ExpenseClaimPolicy.Assess(Exp() with {{ Amount = {amount}, ReceiptAmount = {amount} }}, 1, "TRY", 1, Limits());'+eq(f'{expected}m','a.Reimbursable')+eq(f'{excess}m','a.Excess'))
add('Expense','CurrencyConversion',eq('100m','ExpenseClaimPolicy.Assess(Exp() with { Currency = "USD" }, 1, "TRY", 2, Limits()).Reimbursable'))
for status,approver,manager,expected in [('Submitted','boss','false','true'),('Draft','boss','true','false'),('Approved','boss','true','false'),('Submitted','E-1','true','false')]:
 add('Expense',f'Approve_{status}_{approver}',f'var e = Exp() with {{ Status = DocumentStatus.{status} }}; var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());'+eq(expected,f'ExpenseClaimPolicy.Approve(e, a, "{approver}", {manager}).Allowed'))
for manager,expected in [('false','false'),('true','true')]:
 add('Expense','Manager_'+manager,'var e = Exp() with { Category = "Travel", Amount = 600, ReceiptAmount = 600 }; var a = ExpenseClaimPolicy.Assess(e, 1, "TRY", 1, Limits());'+eq(expected,f'ExpenseClaimPolicy.Approve(e, a, "boss", {manager}).Allowed'))
for offset,window,expected in [(-1,30,'false'),(0,0,'true'),(0,30,'true'),(30,30,'true'),(31,30,'false'),(365,366,'true')]:
 add('Expense',f'Window_{offset}_{window}',eq(expected,f'ExpenseClaimPolicy.IsWithinSubmissionWindow(Exp(), Exp().BusinessDate.AddDays({offset}), {window})'))
for status,expected in [('Draft',100),('Submitted',20),('Approved',20),('Cancelled',100),('Closed',20)]:
 add('Expense','Budget_'+status,eq(f'{expected}m',f'ExpenseClaimPolicy.RemainingBudget(new[] {{ Exp() with {{ Status = DocumentStatus.{status} }} }}, "E-1", "TRY", 100)'))
add('Expense','BudgetFloor',eq('0m','ExpenseClaimPolicy.RemainingBudget(new[] { Exp() }, "E-1", "TRY", 50)'))
add('Expense','Duplicate',eq('true','ExpenseClaimPolicy.IsPotentialDuplicate(Exp(), new[] { Exp() with { Id = "OTHER" } })'))
for expression in ['ExpenseClaimPolicy.CategoryCap("Unknown", 1, Limits())','ExpenseClaimPolicy.CategoryCap("Meal", 0, Limits())','ExpenseClaimPolicy.Assess(Exp() with { ReceiptAttached = false }, 1, "TRY", 1, Limits())','ExpenseClaimPolicy.RemainingBudget(new[] { Exp(), Exp() }, "E-1", "TRY", 100)']:
 add('Expense',f'Invalid_{len(cases)}',bad(expression))
# Contract dates are inclusive; notice deadlines are explicit fixture conventions.
for date,phase in [('2025,12,31','NotStarted'),('2026,1,1','Active'),('2026,6,1','Active'),('2026,12,31','Active'),('2027,1,1','Expired')]:
 add('Contract','Phase_'+date.replace(',','_'),eq('ContractPhase.'+phase,f'ContractPolicy.Phase(Ctr(), new({date}))'))
add('Contract','Cancelled',eq('ContractPhase.Cancelled','ContractPolicy.Phase(Ctr() with { Status = DocumentStatus.Cancelled }, new(2026, 1, 1))'))
add('Contract','Duration',eq('365','ContractPolicy.DurationDays(Ctr())'))
add('Contract','LeapDuration',eq('366','ContractPolicy.DurationDays(Ctr() with { StartDate = new(2024, 1, 1), EndDate = new(2024, 12, 31) })'))
add('Contract','Deadline',eq('new DateOnly(2026, 12, 1)','ContractPolicy.NoticeDeadline(Ctr())'))
for date,expected in [('2026,10,31','false'),('2026,11,1','true'),('2026,12,1','true'),('2026,12,2','false'),('2026,12,31','false')]:
 add('Contract','Window_'+date.replace(',','_'),eq(expected,f'ContractPolicy.IsRenewalWindow(Ctr(), new({date}), 60)'))
for date,earned in [('2025,12,31',0),('2026,1,1',1),('2026,1,31',31),('2026,12,31',365),('2027,1,1',365)]:
 add('Contract','Earned_'+date.replace(',','_'),eq(f'{earned}m',f'ContractPolicy.EarnedAmount(Ctr(), new({date}))'))
for rate,expected in [('-1','0'),('0','365'),('.1','401.50')]:
 add('Contract','Renew_'+rate,'var r = ContractPolicy.Renew(Ctr(), new(2026, 12, 1), 12, '+rate+'m);'+eq(expected+'m','r.Amount')+eq('new DateOnly(2027, 1, 1)','r.Start')+eq('new DateOnly(2027, 12, 31)','r.End'))
add('Contract','TerminationNotice','var t = ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 1, 1), .1m);'+eq('31m','t.EarnedAmount')+eq('334m','t.Refund')+eq('0m','t.Penalty'))
add('Contract','TerminationShortNotice','var t = ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 1, 30), .1m);'+eq('300.60m','t.Refund')+eq('33.40m','t.Penalty'))
add('Contract','TerminationEnd',eq('0m','ContractPolicy.Terminate(Ctr(), new(2026, 12, 31), new(2026, 12, 31), 1).Refund'))
add('Contract','Remaining',eq('334m','ContractPolicy.RemainingCommitment(Ctr(), new(2026, 1, 31))'))
add('Contract','CancelledRemaining',eq('0m','ContractPolicy.RemainingCommitment(Ctr() with { Status = DocumentStatus.Cancelled }, new(2026, 1, 31))'))
add('Contract','Overlap',eq('true','ContractPolicy.Overlaps(Ctr(), Ctr())'))
add('Contract','NoOverlap',eq('false','ContractPolicy.Overlaps(Ctr(), Ctr() with { StartDate = new(2027, 1, 1), EndDate = new(2027, 12, 31) })'))
for expression in ['ContractPolicy.Renew(Ctr(), new(2026, 12, 2), 12, 0)','ContractPolicy.Renew(Ctr(), new(2026, 11, 1), 0, 0)','ContractPolicy.IsRenewalWindow(Ctr(), new(2026, 11, 1), 10)','ContractPolicy.Terminate(Ctr(), new(2025, 12, 31), new(2025, 12, 1), 0)','ContractPolicy.Terminate(Ctr(), new(2026, 1, 31), new(2026, 2, 1), 0)']:
 add('Contract',f'Invalid_{len(cases)}',bad(expression))
# Return windows, seller-fault fee waivers, stock eligibility and refund conservation.
for age,window,returned,expected in [(-1,30,0,'false'),(0,30,0,'true'),(30,30,0,'true'),(31,30,0,'false'),(0,0,0,'true'),(1,0,0,'false'),(14,30,8,'true'),(14,30,9,'false')]:
 add('Return',f'Eligibility_{age}_{window}_{returned}',eq(expected,f'ReturnAuthorizationPolicy.Eligibility(Ret() with {{ BusinessDate = new DateOnly(2026, 1, 1).AddDays({age}) }}, new(2026, 1, 1), 10, {returned}, {window}).Allowed'))
for reason in ['Damaged','WrongItem','Unwanted']:
 for full in ['false','true']:
  for resalable in ['false','true']:
   fee='10' if reason=='Unwanted' else '0'; shipping='5' if reason!='Unwanted' and full=='true' else '0'; restock='true' if reason!='Damaged' and resalable=='true' else 'false'
   add('Return',f'Quote_{reason}_{full}_{resalable}',f'var q = ReturnAuthorizationPolicy.Quote(Ret() with {{ Reason = "{reason}" }}, 50, 5, {full}, {resalable});'+eq(fee+'m','q.RestockingFee')+eq(shipping+'m','q.ShippingRefund')+eq(restock,'q.RestockInventory')+eq(str(100-int(fee)+int(shipping))+'m','q.Refund'))
for qty,expected in [(0,'0'),(1,'3.33'),(2,'6.67'),(3,'10')]:
 add('Return',f'Discount_{qty}',eq(expected+'m',f'ReturnAuthorizationPolicy.ProratedDiscount(10, 3, {qty})'))
add('Return','RefundRemaining',eq('10m','ReturnAuthorizationPolicy.RefundRemaining(100, 0, new(100, 10, 0, 90, true))'))
for status,expected in [('Draft',10),('Submitted',8),('Approved',8),('Cancelled',10),('Closed',8)]:
 add('Return','History_'+status,eq(str(expected),f'ReturnAuthorizationPolicy.RemainingReturnable(10, new[] {{ Ret() with {{ Status = DocumentStatus.{status} }} }}, "SO-1")'))
for restock,expected in [('true',2),('false',0)]:
 add('Return','Restock_'+restock,eq(str(expected),f'ReturnAuthorizationPolicy.RestockQuantity(Ret(), new(100, 0, 0, 100, {restock}))'))
for expression in ['ReturnAuthorizationPolicy.Quote(Ret(), 51, 0, false, true)','ReturnAuthorizationPolicy.RefundRemaining(80, 0, new(100, 10, 0, 90, true))','ReturnAuthorizationPolicy.RefundRemaining(100, 0, new(100, 10, 0, 100, true))','ReturnAuthorizationPolicy.RemainingReturnable(10, new[] { Ret(), Ret() }, "SO-1")','ReturnAuthorizationPolicy.ProratedDiscount(10, 0, 0)','ReturnAuthorizationPolicy.RestockQuantity(Ret() with { Status = DocumentStatus.Draft }, new(100, 0, 0, 100, true))']:
 add('Return',f'Invalid_{len(cases)}',bad(expression))

header='''using Benchmark.Domain;
using Benchmark.Application.Policies;

namespace Benchmark.Tests;

// Synthetic finance-policy examples; this file is reproducibly emitted by generate_finance_policies.py.
public static class PolicyCasesFinance
{
    public static IEnumerable<(string, Func<Task>)> All()
    {
'''
lines=[header]
for i,(name,body) in enumerate(cases):
 lines.append(f'        yield return ("Finance.{name}", Case{i:03d});\n')
lines.append('    }\n\n')
for i,(name,body) in enumerate(cases):
 lines.append(f'    private static Task Case{i:03d}()\n    {{\n')
 # Line break after statement terminators; object initializers and generics stay intact.
 for statement in body.split(';'):
  if statement.strip(): lines.append('        '+statement.strip()+';\n')
 lines.append('        return Task.CompletedTask;\n    }\n\n')
lines.append('''    private static Invoice Inv() => new() { Id = "INV", Code = "INV-1", Amount = 100m, TaxAmount = 20m, DueDate = new(2026, 1, 31), Status = DocumentStatus.Approved };
    private static Payment Pay() => new() { Id = "PAY", Code = "PAY-1", InvoiceId = "INV", Amount = 100m, Fee = 5m, Status = DocumentStatus.Fulfilled };
    private static PaymentFeeSchedule Fees() => new(1m, .30m, .025m);
    private static Asset Ast() => new() { Id = "AST", Code = "AST-1", Amount = 120m, UsefulLifeMonths = 12 };
    private static ExpenseClaim Exp() => new() { Id = "EXP", Code = "EXP-1", Amount = 80m, ReceiptAmount = 80m, Category = "Meal", Status = DocumentStatus.Submitted };
    private static ExpenseLimits Limits() => new(1000, 100, 500, 250, 500);
    private static Contract Ctr() => new() { Id = "CTR", Code = "CTR-1", Amount = 365m };
    private static ReturnAuthorization Ret() => new() { Id = "RET", Code = "RET-1", Amount = 100m, Quantity = 2, Reason = "Unwanted", RestockingPercent = 10m, BusinessDate = new(2026, 1, 15), Status = DocumentStatus.Approved };
}
''')
root=Path(__file__).parent
(root/'benchmark/src/Tests/PolicyCasesFinance.cs').write_text(''.join(lines))
from collections import Counter
print(dict(Counter(name.split('_')[0] for name,_ in cases)))
print('total',len(cases))
