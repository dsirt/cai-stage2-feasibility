from pathlib import Path
import json, datetime, hashlib

ROOT = Path(__file__).resolve().parent / 'benchmark'

def put(name, text):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.strip()+'\n', encoding='utf-8')

put('global.json', json.dumps({'sdk': {'version':'8.0.425','rollForward':'disable'}}, indent=2))
put('NuGet.Config', '''<?xml version="1.0" encoding="utf-8"?>
<configuration><packageSources><clear /></packageSources></configuration>''')
put('Directory.Build.props', '''<Project>
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <LangVersion>12</LangVersion>
    <Deterministic>true</Deterministic>
    <EnableNETAnalyzers>true</EnableNETAnalyzers>
    <AnalysisLevel>8.0</AnalysisLevel>
  </PropertyGroup>
</Project>''')
put('.gitignore', 'bin/\nobj/\nartifacts/\n*.user\n')
for name,refs,sdk,exe in [
    ('Domain',[], 'Microsoft.NET.Sdk',False),
    ('Application',['Domain'], 'Microsoft.NET.Sdk',False),
    ('Infrastructure',['Domain','Application'], 'Microsoft.NET.Sdk',False),
    ('Api',['Application','Infrastructure'], 'Microsoft.NET.Sdk.Web',False),
    ('Tests',['Domain','Application','Infrastructure'], 'Microsoft.NET.Sdk',True)]:
    body=f'<Project Sdk="{sdk}">\n'
    if exe: body+='  <PropertyGroup><OutputType>Exe</OutputType></PropertyGroup>\n'
    if refs:
        body+='  <ItemGroup>\n'
        body+=''.join(f'    <ProjectReference Include="../{r}/Benchmark.{r}.csproj" />\n' for r in refs)
        body+='  </ItemGroup>\n'
    body+='</Project>'
    put(f'src/{name}/Benchmark.{name}.csproj',body)

put('src/Domain/DocumentStatus.cs','''namespace Benchmark.Domain;
public enum DocumentStatus { Draft, Submitted, Approved, Fulfilled, Closed, Cancelled }
public sealed class DomainValidationException(string message) : Exception(message);
public sealed class ConcurrencyConflictException(string message) : Exception(message);
public sealed class MissingEntityException(string message) : Exception(message);
''')
put('src/Domain/BusinessDocument.cs','''namespace Benchmark.Domain;

public abstract record BusinessDocument
{
    public required string Id { get; init; }
    public required string Code { get; init; }
    public string PartyId { get; init; } = "";
    public DateOnly BusinessDate { get; init; } = new(2026, 1, 1);
    public decimal Amount { get; init; }
    public string Currency { get; init; } = "TRY";
    public string Description { get; init; } = "";
    public DocumentStatus Status { get; init; } = DocumentStatus.Draft;
    public int Version { get; init; }
    public abstract string Kind { get; }

    public virtual void Validate()
    {
        Rules.Required(Id, nameof(Id), 64);
        Rules.Required(Code, nameof(Code), 40);
        if (Id.Any(char.IsWhiteSpace)) throw new DomainValidationException("Id cannot contain whitespace.");
        if (Amount < 0 || Amount > 1_000_000_000m) throw new DomainValidationException("Amount is outside the supported range.");
        if (Currency.Length != 3 || Currency.Any(c => c < 'A' || c > 'Z'))
            throw new DomainValidationException("Currency must be a three-letter uppercase code.");
        if (BusinessDate.Year < 2000 || BusinessDate.Year > 2100)
            throw new DomainValidationException("BusinessDate must be between 2000 and 2100.");
        if (Description.Length > 2000) throw new DomainValidationException("Description exceeds 2000 characters.");
        if (Version < 0) throw new DomainValidationException("Version cannot be negative.");
        if (!Enum.IsDefined(Status)) throw new DomainValidationException("Unknown document status.");
    }

    public BusinessDocument NextStatus(DocumentStatus target)
    {
        if (!WorkflowRules.Allows(Status, target))
            throw new DomainValidationException($"Transition from {Status} to {target} is not allowed.");
        return this with { Status = target, Version = checked(Version + 1) };
    }
}

public static class Rules
{
    public static void Required(string value, string field, int limit)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new DomainValidationException($"{field} is required.");
        if (value.Length > limit) throw new DomainValidationException($"{field} exceeds {limit} characters.");
    }
    public static void Range(decimal value, decimal minimum, decimal maximum, string field)
    {
        if (value < minimum || value > maximum)
            throw new DomainValidationException($"{field} is outside [{minimum}, {maximum}].");
    }
    public static void DateOrder(DateOnly first, DateOnly last, string field)
    {
        if (last < first) throw new DomainValidationException($"{field} cannot precede its start date.");
    }
}

public static class WorkflowRules
{
    public static bool Allows(DocumentStatus source, DocumentStatus target) => (source, target) switch
    {
        (DocumentStatus.Draft, DocumentStatus.Submitted) => true,
        (DocumentStatus.Draft, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Submitted, DocumentStatus.Draft) => true,
        (DocumentStatus.Submitted, DocumentStatus.Approved) => true,
        (DocumentStatus.Submitted, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Approved, DocumentStatus.Fulfilled) => true,
        (DocumentStatus.Approved, DocumentStatus.Cancelled) => true,
        (DocumentStatus.Fulfilled, DocumentStatus.Closed) => true,
        _ => false
    };
}
''')

# Each tuple defines distinct business fields, validations, and valid fixture values.
MODULES = [
 ('PurchaseOrder', [('string','SupplierId','"SUP-1"'),('DateOnly','ExpectedDate','new(2026, 2, 1)'),('decimal','DiscountPercent','0m'),('string','DeliveryTerms','"DAP"')],
  ['Rules.Required(SupplierId, nameof(SupplierId), 64);','Rules.DateOrder(BusinessDate, ExpectedDate, nameof(ExpectedDate));','Rules.Range(DiscountPercent, 0, 100, nameof(DiscountPercent));','Rules.Required(DeliveryTerms, nameof(DeliveryTerms), 30);']),
 ('SalesOrder',[('string','CustomerId','"CUS-1"'),('DateOnly','PromisedDate','new(2026, 2, 1)'),('decimal','TaxPercent','20m'),('decimal','CreditLimit','100000m')],
  ['Rules.Required(CustomerId, nameof(CustomerId), 64);','Rules.DateOrder(BusinessDate, PromisedDate, nameof(PromisedDate));','Rules.Range(TaxPercent, 0, 100, nameof(TaxPercent));','if (Amount > CreditLimit) throw new DomainValidationException("Order exceeds customer credit limit.");']),
 ('Supplier',[('string','TaxNumber','"1234567890"'),('int','PaymentDays','30'),('string','Country','"TR"'),('bool','IsApproved','false')],
  ['Rules.Required(TaxNumber, nameof(TaxNumber), 20);','if (!TaxNumber.All(char.IsDigit)) throw new DomainValidationException("Tax number must contain digits only.");','Rules.Range(PaymentDays, 0, 365, nameof(PaymentDays));','if (Country.Length != 2) throw new DomainValidationException("Country must have two characters.");']),
 ('Customer',[('string','TaxNumber','"9876543210"'),('decimal','CreditLimit','50000m'),('int','PaymentDays','15'),('string','Email','"test@example.invalid"')],
  ['Rules.Required(TaxNumber, nameof(TaxNumber), 20);','Rules.Range(CreditLimit, 0, 100000000, nameof(CreditLimit));','Rules.Range(PaymentDays, 0, 365, nameof(PaymentDays));','if (!Email.Contains("@", StringComparison.Ordinal)) throw new DomainValidationException("Email must contain an at sign.");']),
 ('Product',[('string','Sku','"SKU-1"'),('string','Unit','"EA"'),('decimal','UnitPrice','10m'),('decimal','WeightKg','1m')],
  ['Rules.Required(Sku, nameof(Sku), 40);','Rules.Required(Unit, nameof(Unit), 12);','Rules.Range(UnitPrice, 0, 10000000, nameof(UnitPrice));','Rules.Range(WeightKg, 0, 100000, nameof(WeightKg));']),
 ('Warehouse',[('string','LocationCode','"IST-01"'),('int','Capacity','10000'),('decimal','MinimumTemperature','0m'),('decimal','MaximumTemperature','40m')],
  ['Rules.Required(LocationCode, nameof(LocationCode), 30);','Rules.Range(Capacity, 1, 10000000, nameof(Capacity));','if (MinimumTemperature > MaximumTemperature) throw new DomainValidationException("Minimum temperature exceeds maximum.");','Rules.Range(MinimumTemperature, -100, 100, nameof(MinimumTemperature));']),
 ('Invoice',[('string','OrderId','"SO-1"'),('DateOnly','DueDate','new(2026, 2, 1)'),('decimal','TaxAmount','20m'),('decimal','PaidAmount','0m')],
  ['Rules.Required(OrderId, nameof(OrderId), 64);','Rules.DateOrder(BusinessDate, DueDate, nameof(DueDate));','Rules.Range(TaxAmount, 0, 1000000000, nameof(TaxAmount));','if (PaidAmount < 0 || PaidAmount > Amount + TaxAmount) throw new DomainValidationException("Paid amount exceeds invoice total.");']),
 ('Payment',[('string','InvoiceId','"INV-1"'),('string','Method','"Transfer"'),('string','Reference','"PAY-REF-1"'),('decimal','Fee','0m')],
  ['Rules.Required(InvoiceId, nameof(InvoiceId), 64);','if (Method is not ("Transfer" or "Card" or "Cash")) throw new DomainValidationException("Unsupported payment method.");','Rules.Required(Reference, nameof(Reference), 80);','if (Fee < 0 || Fee > Amount) throw new DomainValidationException("Payment fee is invalid.");']),
 ('Shipment',[('string','OrderId','"SO-1"'),('string','Carrier','"Carrier-1"'),('DateOnly','DispatchDate','new(2026, 1, 2)'),('DateOnly','ArrivalDate','new(2026, 1, 3)')],
  ['Rules.Required(OrderId, nameof(OrderId), 64);','Rules.Required(Carrier, nameof(Carrier), 80);','Rules.DateOrder(BusinessDate, DispatchDate, nameof(DispatchDate));','Rules.DateOrder(DispatchDate, ArrivalDate, nameof(ArrivalDate));']),
 ('Asset',[('string','SerialNumber','"SN-1"'),('DateOnly','AcquisitionDate','new(2026, 1, 1)'),('int','UsefulLifeMonths','60'),('decimal','SalvageValue','0m')],
  ['Rules.Required(SerialNumber, nameof(SerialNumber), 80);','Rules.Range(UsefulLifeMonths, 1, 1200, nameof(UsefulLifeMonths));','if (SalvageValue < 0 || SalvageValue > Amount) throw new DomainValidationException("Salvage value exceeds asset cost.");','if (AcquisitionDate > BusinessDate) throw new DomainValidationException("Asset acquisition cannot follow business date.");']),
 ('WorkOrder',[('string','AssetId','"ASSET-1"'),('int','Priority','2'),('decimal','PlannedHours','4m'),('decimal','ActualHours','0m')],
  ['Rules.Required(AssetId, nameof(AssetId), 64);','Rules.Range(Priority, 1, 5, nameof(Priority));','Rules.Range(PlannedHours, 0, 10000, nameof(PlannedHours));','Rules.Range(ActualHours, 0, 10000, nameof(ActualHours));']),
 ('Employee',[('string','Department','"Operations"'),('string','PersonnelNumber','"E-1"'),('DateOnly','HireDate','new(2025, 1, 1)'),('decimal','WeeklyHours','40m')],
  ['Rules.Required(Department, nameof(Department), 80);','Rules.Required(PersonnelNumber, nameof(PersonnelNumber), 40);','if (HireDate > BusinessDate) throw new DomainValidationException("Hire date cannot follow business date.");','Rules.Range(WeeklyHours, 1, 60, nameof(WeeklyHours));']),
 ('ExpenseClaim',[('string','EmployeeId','"E-1"'),('string','Category','"Travel"'),('decimal','ReceiptAmount','100m'),('bool','ReceiptAttached','true')],
  ['Rules.Required(EmployeeId, nameof(EmployeeId), 64);','if (Category is not ("Travel" or "Meal" or "Accommodation" or "Office")) throw new DomainValidationException("Unknown expense category.");','if (Amount > ReceiptAmount) throw new DomainValidationException("Claim exceeds receipt amount.");','if (Amount > 50m && !ReceiptAttached) throw new DomainValidationException("Receipt attachment required above 50.");']),
 ('ReturnAuthorization',[('string','OrderId','"SO-1"'),('string','Reason','"Damaged"'),('int','Quantity','1'),('decimal','RestockingPercent','0m')],
  ['Rules.Required(OrderId, nameof(OrderId), 64);','if (Reason is not ("Damaged" or "WrongItem" or "Unwanted")) throw new DomainValidationException("Unknown return reason.");','Rules.Range(Quantity, 1, 100000, nameof(Quantity));','Rules.Range(RestockingPercent, 0, 100, nameof(RestockingPercent));']),
 ('Contract',[('string','Counterparty','"Partner-1"'),('DateOnly','StartDate','new(2026, 1, 1)'),('DateOnly','EndDate','new(2026, 12, 31)'),('int','NoticeDays','30')],
  ['Rules.Required(Counterparty, nameof(Counterparty), 100);','Rules.DateOrder(StartDate, EndDate, nameof(EndDate));','Rules.Range(NoticeDays, 0, 365, nameof(NoticeDays));','if (EndDate.DayNumber - StartDate.DayNumber < NoticeDays) throw new DomainValidationException("Notice period exceeds contract duration.");'])
]
for name,fields,checks in MODULES:
    props='\n'.join(f'    public {typ} {field} {{ get; init; }} = {default};' for typ,field,default in fields)
    validations='\n'.join('        '+s for s in checks)
    put(f'src/Domain/Documents/{name}.cs', f'''namespace Benchmark.Domain;

public sealed record {name} : BusinessDocument
{{
    public override string Kind => "{name}";
{props}

    public override void Validate()
    {{
        base.Validate();
{validations}
    }}
}}''')

put('src/Domain/PurchaseOrderLine.cs','''namespace Benchmark.Domain;
public sealed record PurchaseOrderLine : BusinessDocument
{
    public override string Kind => "PurchaseOrderLine";
    public required string OrderId { get; init; }
    public required string ProductId { get; init; }
    public int Quantity { get; init; }
    public decimal UnitPrice { get; init; }
    public decimal NetTotal => decimal.Round(Quantity * UnitPrice, 2, MidpointRounding.AwayFromZero);
    public override void Validate()
    {
        base.Validate();
        Rules.Required(OrderId, nameof(OrderId), 64);
        Rules.Required(ProductId, nameof(ProductId), 64);
        Rules.Range(Quantity, 1, 1000000, nameof(Quantity));
        Rules.Range(UnitPrice, 0, 1000000, nameof(UnitPrice));
    }
}''')
put('src/Domain/InventoryItem.cs','''namespace Benchmark.Domain;
public sealed record InventoryItem : BusinessDocument
{
    public override string Kind => "InventoryItem";
    public required string Sku { get; init; }
    public int OnHand { get; init; }
    public int Reserved { get; init; }
    public int Available => OnHand - Reserved;
    public override void Validate()
    {
        base.Validate();
        Rules.Required(Sku, nameof(Sku), 40);
        if (OnHand < 0 || Reserved < 0 || Reserved > OnHand)
            throw new DomainValidationException("Inventory quantities are inconsistent.");
    }
}
public sealed record ReservationResult(bool Success, string Code, int Available, int Version);''')
put('src/Domain/AuditRecord.cs','''namespace Benchmark.Domain;
public sealed record AuditRecord(
    string Id,
    string EntityKind,
    string EntityId,
    string Action,
    string Actor,
    DateTimeOffset OccurredAt,
    int PreviousVersion,
    int CurrentVersion,
    string BeforeJson,
    string AfterJson);
''')

put('src/Application/Ports/IDatabaseSession.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

// Application-owned storage port. The in-memory adapter is deliberately replaceable.
public interface IDatabaseSession
{
    Task<T?> FindAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task SaveAsync<T>(T document, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task DeleteAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<bool> TryReplaceAsync<T>(T document, int expectedVersion, CancellationToken cancellationToken = default) where T : BusinessDocument;
    Task<T> InTransactionAsync<T>(Func<CancellationToken, Task<T>> action, CancellationToken cancellationToken = default);
}
''')
put('src/Application/Ports/IAuditSink.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public interface IAuditSink
{
    Task AppendAsync(AuditRecord record, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<AuditRecord>> ReadAllAsync(CancellationToken cancellationToken = default);
}
public interface IClock { DateTimeOffset UtcNow { get; } }
public sealed class SystemClock : IClock { public DateTimeOffset UtcNow => DateTimeOffset.UtcNow; }
public interface IReservationObserver
{
    Task AfterReadAsync(InventoryItem snapshot, CancellationToken cancellationToken = default);
}
public sealed class NoOpReservationObserver : IReservationObserver
{
    public Task AfterReadAsync(InventoryItem snapshot, CancellationToken cancellationToken = default)
        => Task.CompletedTask;
}
''')
put('src/Application/Services/DocumentService.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class DocumentService<T>(IDatabaseSession session) where T : BusinessDocument
{
    public Task<T> CreateAsync(T document, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            document.Validate();
            if (document.Status != DocumentStatus.Draft)
                throw new DomainValidationException("New documents must be drafts.");
            if (await session.FindAsync<T>(document.Id, token) is not null)
                throw new DomainValidationException("Duplicate document id.");
            if ((await session.ListAsync<T>(token)).Any(x => x.Code == document.Code))
                throw new DomainValidationException("Duplicate document code.");
            var saved = (T)(document with { Version = 1 });
            await session.SaveAsync(saved, token);
            return saved;
        }, cancellationToken);

    public async Task<T> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<T>(id, cancellationToken)
            ?? throw new MissingEntityException($"{typeof(T).Name} {id} was not found.");

    public Task<IReadOnlyList<T>> ListAsync(CancellationToken cancellationToken = default)
        => session.ListAsync<T>(cancellationToken);

    public Task<T> UpdateDraftAsync(T replacement, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(replacement.Id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Only drafts may be edited.");
            if (replacement.Status != current.Status) throw new DomainValidationException("Use TransitionAsync to change status.");
            replacement.Validate();
            if ((await session.ListAsync<T>(token)).Any(x => x.Id != replacement.Id && x.Code == replacement.Code))
                throw new DomainValidationException("Duplicate document code.");
            var saved = (T)(replacement with { Version = checked(current.Version + 1) });
            await session.SaveAsync(saved, token);
            return saved;
        }, cancellationToken);

    public Task<T> TransitionAsync(string id, DocumentStatus target, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            var updated = (T)current.NextStatus(target);
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<bool> DeleteDraftAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Document changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Only drafts may be deleted.");
            await session.DeleteAsync<T>(id, token);
            return true;
        }, cancellationToken);
}
''')
put('src/Application/Services/PurchaseOrderService.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class PurchaseOrderService(IDatabaseSession session)
{
    public Task<PurchaseOrder> CreateAsync(PurchaseOrder order, CancellationToken cancellationToken = default)
        => new DocumentService<PurchaseOrder>(session).CreateAsync(order, cancellationToken);

    public async Task<PurchaseOrder> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<PurchaseOrder>(id, cancellationToken)
            ?? throw new MissingEntityException($"Purchase order {id} was not found.");

    public async Task<IReadOnlyList<PurchaseOrderLine>> GetLinesAsync(string orderId, CancellationToken cancellationToken = default)
        => (await session.ListAsync<PurchaseOrderLine>(cancellationToken))
            .Where(x => x.OrderId == orderId).OrderBy(x => x.Code, StringComparer.Ordinal).ToArray();

    public Task<PurchaseOrder> AddLineAsync(PurchaseOrderLine line, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            line.Validate();
            var order = await GetAsync(line.OrderId, token);
            RequireEditable(order, expectedVersion);
            if (await session.FindAsync<PurchaseOrderLine>(line.Id, token) is not null)
                throw new DomainValidationException("Duplicate order line id.");
            var lines = await GetLinesAsync(order.Id, token);
            if (lines.Any(x => x.Code == line.Code)) throw new DomainValidationException("Duplicate order line code.");
            var total = decimal.Round((lines.Sum(x => x.NetTotal) + line.NetTotal) * (1 - order.DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
            var updated = order with { Amount = total, Version = checked(order.Version + 1) };
            updated.Validate();
            await session.SaveAsync(line with { Version = 1, Amount = line.NetTotal }, token);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> RemoveLineAsync(string orderId, string lineId, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(orderId, token);
            RequireEditable(order, expectedVersion);
            var line = await session.FindAsync<PurchaseOrderLine>(lineId, token)
                ?? throw new MissingEntityException("Order line was not found.");
            if (line.OrderId != orderId) throw new DomainValidationException("Line belongs to a different order.");
            var remaining = (await GetLinesAsync(orderId, token)).Where(x => x.Id != lineId);
            var total = decimal.Round(remaining.Sum(x => x.NetTotal) * (1 - order.DiscountPercent / 100m), 2, MidpointRounding.AwayFromZero);
            var updated = order with { Amount = total, Version = checked(order.Version + 1) };
            await session.DeleteAsync<PurchaseOrderLine>(lineId, token);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> SubmitAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(id, token);
            RequireEditable(order, expectedVersion);
            if ((await GetLinesAsync(id, token)).Count == 0)
                throw new DomainValidationException("An order requires at least one line before submission.");
            var updated = (PurchaseOrder)order.NextStatus(DocumentStatus.Submitted);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<PurchaseOrder> ApproveAsync(string id, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var order = await GetAsync(id, token);
            if (order.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (order.Status != DocumentStatus.Submitted) throw new DomainValidationException("Only submitted orders may be approved.");
            var updated = (PurchaseOrder)order.NextStatus(DocumentStatus.Approved);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    private static void RequireEditable(PurchaseOrder order, int expectedVersion)
    {
        if (order.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
        if (order.Status != DocumentStatus.Draft) throw new DomainValidationException("Only draft orders may be edited.");
    }
}
''')
put('src/Application/Services/SalesOrderService.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class SalesOrderService(IDatabaseSession session, IAuditSink auditSink, IClock clock)
{
    public Task<SalesOrder> CreateAsync(SalesOrder order, CancellationToken cancellationToken = default)
        => new DocumentService<SalesOrder>(session).CreateAsync(order, cancellationToken);

    public async Task<SalesOrder> GetAsync(string id, CancellationToken cancellationToken = default)
        => await session.FindAsync<SalesOrder>(id, cancellationToken)
            ?? throw new MissingEntityException($"Sales order {id} was not found.");

    public Task<SalesOrder> UpdateDescriptionAsync(string id, string description, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (current.Status is DocumentStatus.Closed or DocumentStatus.Cancelled)
                throw new DomainValidationException("A terminal order cannot be edited.");
            var updated = current with { Description = description, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<SalesOrder> ChangeAmountAsync(string id, decimal amount, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            if (current.Status != DocumentStatus.Draft) throw new DomainValidationException("Amount changes require a draft.");
            var updated = current with { Amount = amount, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<SalesOrder> SubmitAsync(string id, string actor, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            Rules.Required(actor, nameof(actor), 80);
            var current = await GetAsync(id, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Order changed.");
            var updated = (SalesOrder)current.NextStatus(DocumentStatus.Submitted);
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);
}
''')
put('src/Application/Services/InventoryService.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

public sealed class InventoryService(IDatabaseSession session, IReservationObserver observer)
{
    public Task<InventoryItem> CreateAsync(InventoryItem item, CancellationToken cancellationToken = default)
        => new DocumentService<InventoryItem>(session).CreateAsync(item, cancellationToken);

    public async Task<InventoryItem> GetAsync(string sku, CancellationToken cancellationToken = default)
        => await session.FindAsync<InventoryItem>(sku, cancellationToken)
            ?? throw new MissingEntityException($"Inventory item {sku} was not found.");

    public async Task<ReservationResult> ReserveAsync(string sku, int quantity, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (quantity <= 0) throw new DomainValidationException("Reservation quantity must be positive.");
        var current = await GetAsync(sku, cancellationToken);
        if (current.Available < quantity) return new(false, "InsufficientStock", current.Available, current.Version);
        await observer.AfterReadAsync(current, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        var updated = current with { Reserved = checked(current.Reserved + quantity), Version = checked(current.Version + 1) };
        updated.Validate();
        await session.SaveAsync(updated, cancellationToken);
        return new(true, "Reserved", updated.Available, updated.Version);
    }

    public Task<InventoryItem> ReleaseAsync(string sku, int quantity, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            if (quantity <= 0) throw new DomainValidationException("Release quantity must be positive.");
            var current = await GetAsync(sku, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Inventory changed.");
            if (quantity > current.Reserved) throw new DomainValidationException("Release exceeds reservation.");
            var updated = current with { Reserved = current.Reserved - quantity, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);

    public Task<InventoryItem> AdjustAsync(string sku, int newOnHand, int expectedVersion, CancellationToken cancellationToken = default)
        => session.InTransactionAsync(async token =>
        {
            var current = await GetAsync(sku, token);
            if (current.Version != expectedVersion) throw new ConcurrencyConflictException("Inventory changed.");
            var updated = current with { OnHand = newOnHand, Version = checked(current.Version + 1) };
            updated.Validate();
            await session.SaveAsync(updated, token);
            return updated;
        }, cancellationToken);
}
''')
put('src/Infrastructure/InMemoryDatabaseSession.cs','''using System.Collections.Concurrent;
using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Infrastructure;

// Synthetic in-process adapter; no process-crash persistence is claimed.
public sealed class InMemoryDatabaseSession : IDatabaseSession
{
    private readonly ConcurrentDictionary<(Type Type, string Id), BusinessDocument> rows = new();
    private readonly SemaphoreSlim transactionLock = new(1, 1);
    private readonly AsyncLocal<Dictionary<(Type Type, string Id), BusinessDocument>?> transactionRows = new();

    public Task<T?> FindAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (transactionRows.Value is { } pending)
            return Task.FromResult(pending.TryGetValue((typeof(T), id), out var p) ? (T)p : null);
        return Task.FromResult(rows.TryGetValue((typeof(T), id), out var value) ? (T)value : null);
    }

    public Task<IReadOnlyList<T>> ListAsync<T>(CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        IEnumerable<BusinessDocument> values = transactionRows.Value is { } pending ? pending.Values : rows.Values;
        return Task.FromResult<IReadOnlyList<T>>(values.OfType<T>().OrderBy(x => x.Id, StringComparer.Ordinal).ToArray());
    }

    public Task SaveAsync<T>(T document, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        document.Validate();
        if (transactionRows.Value is { } pending) pending[(typeof(T), document.Id)] = document;
        else rows[(typeof(T), document.Id)] = document;
        return Task.CompletedTask;
    }

    public Task DeleteAsync<T>(string id, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (transactionRows.Value is { } pending) pending.Remove((typeof(T), id));
        else rows.TryRemove((typeof(T), id), out _);
        return Task.CompletedTask;
    }

    public Task<bool> TryReplaceAsync<T>(T document, int expectedVersion, CancellationToken cancellationToken = default) where T : BusinessDocument
    {
        cancellationToken.ThrowIfCancellationRequested();
        document.Validate();
        var key = (typeof(T), document.Id);
        if (transactionRows.Value is { } pending)
        {
            if (!pending.TryGetValue(key, out var old) || old.Version != expectedVersion) return Task.FromResult(false);
            pending[key] = document;
            return Task.FromResult(true);
        }
        if (!rows.TryGetValue(key, out var current) || current.Version != expectedVersion) return Task.FromResult(false);
        return Task.FromResult(rows.TryUpdate(key, document, current));
    }

    public async Task<T> InTransactionAsync<T>(Func<CancellationToken, Task<T>> action, CancellationToken cancellationToken = default)
    {
        if (transactionRows.Value is not null) return await action(cancellationToken);
        await transactionLock.WaitAsync(cancellationToken);
        try
        {
            var before = rows.ToDictionary(x => x.Key, x => x.Value);
            transactionRows.Value = new(before);
            var result = await action(cancellationToken);
            cancellationToken.ThrowIfCancellationRequested();
            var after = transactionRows.Value;
            foreach (var removed in before.Keys.Where(key => !after.ContainsKey(key))) rows.TryRemove(removed, out _);
            foreach (var pair in after)
                if (!before.TryGetValue(pair.Key, out var old) || old != pair.Value) rows[pair.Key] = pair.Value;
            return result;
        }
        finally
        {
            transactionRows.Value = null;
            transactionLock.Release();
        }
    }
}
''')
put('src/Infrastructure/InMemoryAuditSink.cs','''using System.Collections.Concurrent;
using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Infrastructure;
public sealed class InMemoryAuditSink : IAuditSink
{
    private readonly ConcurrentQueue<AuditRecord> records = new();
    public Task AppendAsync(AuditRecord record, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        records.Enqueue(record);
        return Task.CompletedTask;
    }
    public Task<IReadOnlyList<AuditRecord>> ReadAllAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult<IReadOnlyList<AuditRecord>>(records.ToArray());
    }
}
''')

put('src/Api/Program.cs','''using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
using Benchmark.Api;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IDatabaseSession, InMemoryDatabaseSession>();
builder.Services.AddSingleton<IAuditSink, InMemoryAuditSink>();
builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton<IReservationObserver, NoOpReservationObserver>();
builder.Services.AddScoped<PurchaseOrderService>();
builder.Services.AddScoped<SalesOrderService>();
builder.Services.AddScoped<InventoryService>();
var app = builder.Build();
app.Use(async (context, next) =>
{
    try { await next(context); }
    catch (DomainValidationException error) { context.Response.StatusCode = 400; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
    catch (MissingEntityException error) { context.Response.StatusCode = 404; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
    catch (ConcurrencyConflictException error) { context.Response.StatusCode = 409; await context.Response.WriteAsJsonAsync(new { error = error.Message }); }
});
app.MapGet("/health", () => Results.Ok(new { status = "ok", storage = "synthetic-memory" }));
ModuleEndpoints.MapAll(app);
app.MapPost("/workflows/purchase-orders/{id}/lines", async (string id, AddLineRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.AddLineAsync(request.Line with { OrderId = id }, request.ExpectedVersion, token)));
app.MapPost("/workflows/purchase-orders/{id}/submit", async (string id, VersionRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.SubmitAsync(id, request.ExpectedVersion, token)));
app.MapPost("/workflows/purchase-orders/{id}/approve", async (string id, VersionRequest request, PurchaseOrderService service, CancellationToken token) =>
    Results.Ok(await service.ApproveAsync(id, request.ExpectedVersion, token)));
app.MapPut("/workflows/sales-orders/{id}/description", async (string id, DescriptionRequest request, SalesOrderService service, CancellationToken token) =>
    Results.Ok(await service.UpdateDescriptionAsync(id, request.Description, request.Actor, request.ExpectedVersion, token)));
app.MapPost("/workflows/inventory", async (InventoryItem item, InventoryService service, CancellationToken token) => Results.Ok(await service.CreateAsync(item, token)));
app.MapPost("/workflows/inventory/{sku}/reserve", async (string sku, QuantityRequest request, InventoryService service, CancellationToken token) =>
    Results.Ok(await service.ReserveAsync(sku, request.Quantity, token)));
app.MapGet("/workflows/audit", async (IAuditSink sink, CancellationToken token) => Results.Ok(await sink.ReadAllAsync(token)));
app.Run();

public sealed record AddLineRequest(PurchaseOrderLine Line, int ExpectedVersion);
public sealed record VersionRequest(int ExpectedVersion);
public sealed record DescriptionRequest(string Description, string Actor, int ExpectedVersion);
public sealed record QuantityRequest(int Quantity);
''')
endpoint_calls='\n'.join(f'        Map<{n}>(app, "/api/{n.lower()}s");' for n,_,_ in MODULES)
put('src/Api/ModuleEndpoints.cs',f'''using Benchmark.Application;
using Benchmark.Domain;
namespace Benchmark.Api;
public static class ModuleEndpoints
{{
    public static void MapAll(WebApplication app)
    {{
{endpoint_calls}
    }}
    private static void Map<T>(WebApplication app, string path) where T : BusinessDocument
    {{
        app.MapGet(path, async (IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).ListAsync(token)));
        app.MapGet(path + "/{{id}}", async (string id, IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).GetAsync(id, token)));
        app.MapPost(path, async (T document, IDatabaseSession session, CancellationToken token) => Results.Ok(await new DocumentService<T>(session).CreateAsync(document, token)));
        app.MapPut(path + "/{{id}}", async (string id, UpdateRequest<T> request, IDatabaseSession session, CancellationToken token) =>
        {{
            if (id != request.Document.Id) throw new DomainValidationException("Route and body id differ.");
            return Results.Ok(await new DocumentService<T>(session).UpdateDraftAsync(request.Document, request.ExpectedVersion, token));
        }});
        app.MapPost(path + "/{{id}}/transition", async (string id, TransitionRequest request, IDatabaseSession session, CancellationToken token) =>
            Results.Ok(await new DocumentService<T>(session).TransitionAsync(id, request.Target, request.ExpectedVersion, token)));
        app.MapDelete(path + "/{{id}}", async (string id, int expectedVersion, IDatabaseSession session, CancellationToken token) =>
            Results.Ok(await new DocumentService<T>(session).DeleteDraftAsync(id, expectedVersion, token)));
    }}
}}
public sealed record UpdateRequest<T>(T Document, int ExpectedVersion);
public sealed record TransitionRequest(DocumentStatus Target, int ExpectedVersion);
''')

put('src/Tests/AssertEx.cs','''namespace Benchmark.Tests;
public static class AssertEx
{
    public static void Equal<T>(T expected, T actual, string label = "")
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new Exception($"{label}: expected {expected}, actual {actual}");
    }
    public static void True(bool value, string label = "") { if (!value) throw new Exception(label); }
    public static async Task ThrowsAsync<T>(Func<Task> action) where T : Exception
    {
        try { await action(); }
        catch (T) { return; }
        throw new Exception($"Expected {typeof(T).Name}.");
    }
    public static void Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T) { return; }
        throw new Exception($"Expected {typeof(T).Name}.");
    }
}
''')

put('src/Tests/GenericDocumentCases.cs','''using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;

public static class GenericDocumentCases
{
    public static IEnumerable<(string, Func<Task>)> For<T>(Func<string, T> factory) where T : BusinessDocument
    {
        var name = typeof(T).Name;
        yield return ($"{name}.CreateAndRead", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            AssertEx.Equal(1, saved.Version);
            AssertEx.Equal(saved, await service.GetAsync("a"));
        });
        yield return ($"{name}.DuplicateId", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(factory("a")));
        });
        yield return ($"{name}.DuplicateCode", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var first = await service.CreateAsync(factory("a"));
            var second = (T)(factory("b") with { Code = first.Code });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(second));
        });
        yield return ($"{name}.DraftEditVersion", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var original = await service.CreateAsync(factory("a"));
            var updated = await service.UpdateDraftAsync((T)(original with { Description = "Edited" }), 1);
            AssertEx.Equal(2, updated.Version);
            AssertEx.Equal("Edited", updated.Description);
        });
        yield return ($"{name}.StaleEditRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var original = await service.CreateAsync(factory("a"));
            await service.UpdateDraftAsync((T)(original with { Description = "Edited" }), 1);
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(original, 1));
        });
        yield return ($"{name}.FullLifecycle", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            foreach (var status in new[] { DocumentStatus.Submitted, DocumentStatus.Approved, DocumentStatus.Fulfilled, DocumentStatus.Closed })
                saved = await service.TransitionAsync(saved.Id, status, saved.Version);
            AssertEx.Equal(DocumentStatus.Closed, saved.Status);
            AssertEx.Equal(5, saved.Version);
        });
        yield return ($"{name}.SubmittedEditRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync(factory("a"));
            saved = await service.TransitionAsync(saved.Id, DocumentStatus.Submitted, saved.Version);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.UpdateDraftAsync(saved, saved.Version));
        });
        yield return ($"{name}.IllegalTransitionRejected", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.TransitionAsync("a", DocumentStatus.Closed, 1));
        });
        yield return ($"{name}.DraftDeletion", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            AssertEx.True(await service.DeleteDraftAsync("a", 1));
            await AssertEx.ThrowsAsync<MissingEntityException>(() => service.GetAsync("a"));
        });
        yield return ($"{name}.Cancellation", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            using var source = new CancellationTokenSource();
            source.Cancel();
            await AssertEx.ThrowsAsync<OperationCanceledException>(() => service.CreateAsync(factory("a"), source.Token));
            AssertEx.Equal(0, (await service.ListAsync()).Count);
        });
        yield return ($"{name}.NegativeAmount", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Amount = -1m }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.InvalidCurrency", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Currency = "try" }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.InvalidDate", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { BusinessDate = new(1900,1,1) }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.LongDescription", () =>
        {
            AssertEx.Throws<DomainValidationException>(() => (factory("a") with { Description = new string('x', 2001) }).Validate());
            return Task.CompletedTask;
        });
        yield return ($"{name}.ListStableOrder", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("b"));
            await service.CreateAsync(factory("a"));
            AssertEx.Equal("a", (await service.ListAsync())[0].Id);
        });
        yield return ($"{name}.CancellationIsTerminal", async () =>
        {
            var service = new DocumentService<T>(new InMemoryDatabaseSession());
            await service.CreateAsync(factory("a"));
            var saved = await service.TransitionAsync("a", DocumentStatus.Cancelled, 1);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.TransitionAsync("a", DocumentStatus.Draft, saved.Version));
        });
    }
}
''')
factory_calls='\n'.join(f'        cases.AddRange(GenericDocumentCases.For<{name}>(id => new {name} {{ Id = id, Code = "{name}-" + id, Amount = 100m }}));' for name,_,_ in MODULES)
put('src/Tests/ModuleCases.cs',f'''using Benchmark.Domain;
namespace Benchmark.Tests;
public static class ModuleCases
{{
    public static IEnumerable<(string, Func<Task>)> All()
    {{
        var cases = new List<(string, Func<Task>)>();
{factory_calls}
        return cases;
    }}
}}
''')
put('src/Tests/WorkflowCases.cs','''using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;

public static class WorkflowCases
{
    private static PurchaseOrder Order(string id = "po") => new() { Id = id, Code = id, DiscountPercent = 10m };
    private static PurchaseOrderLine Line(string id = "line", string order = "po") => new() { Id = id, Code = id, OrderId = order, ProductId = "product", Quantity = 2, UnitPrice = 50m };
    public static IEnumerable<(string, Func<Task>)> All()
    {
        yield return ("Purchase.TotalIncludesDiscount", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            var saved = await service.AddLineAsync(Line(), 1);
            AssertEx.Equal(90m, saved.Amount);
            AssertEx.Equal(2, saved.Version);
            AssertEx.Equal(1, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.RemoveRecalculates", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            var saved = await service.RemoveLineAsync("po", "line", 2);
            AssertEx.Equal(0m, saved.Amount);
            AssertEx.Equal(0, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.EmptySubmitRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.SubmitAsync("po", 1));
        });
        yield return ("Purchase.ApprovalLifecycle", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            await service.SubmitAsync("po", 2);
            var saved = await service.ApproveAsync("po", 3);
            AssertEx.Equal(DocumentStatus.Approved, saved.Status);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.AddLineAsync(Line("another"), 4));
        });
        yield return ("Purchase.StaleLineRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.AddLineAsync(Line(), 1);
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.AddLineAsync(Line("another"), 1));
            AssertEx.Equal(1, (await service.GetLinesAsync("po")).Count);
        });
        yield return ("Purchase.CrossOrderDeletionRejected", async () =>
        {
            var service = new PurchaseOrderService(new InMemoryDatabaseSession());
            await service.CreateAsync(Order());
            await service.CreateAsync(Order("other"));
            await service.AddLineAsync(Line(), 1);
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.RemoveLineAsync("other", "line", 1));
        });
        yield return ("Storage.RollbackOnException", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<InvalidOperationException>(() => session.InTransactionAsync<int>(async token =>
            {
                await session.SaveAsync(Order(), token);
                throw new InvalidOperationException("test");
            }));
            AssertEx.True(await session.FindAsync<PurchaseOrder>("po") is null);
        });
        yield return ("Storage.VersionCompare", async () =>
        {
            var session = new InMemoryDatabaseSession();
            await session.SaveAsync(Order() with { Version = 1 });
            AssertEx.True(!await session.TryReplaceAsync(Order() with { Version = 2 }, 0));
            AssertEx.True(await session.TryReplaceAsync(Order() with { Version = 2 }, 1));
        });
        yield return ("Sales.DescriptionPersists", async () =>
        {
            var service = new SalesOrderService(new InMemoryDatabaseSession(), new InMemoryAuditSink(), new SystemClock());
            await service.CreateAsync(new SalesOrder { Id = "so", Code = "SO" });
            var saved = await service.UpdateDescriptionAsync("so", "New delivery notes", "operator", 1);
            AssertEx.Equal("New delivery notes", saved.Description);
            AssertEx.Equal(2, saved.Version);
        });
        yield return ("Sales.InvalidAmountRollsBack", async () =>
        {
            var service = new SalesOrderService(new InMemoryDatabaseSession(), new InMemoryAuditSink(), new SystemClock());
            await service.CreateAsync(new SalesOrder { Id = "so", Code = "SO", Amount = 100m });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.ChangeAmountAsync("so", 200000m, "operator", 1));
            AssertEx.Equal(100m, (await service.GetAsync("so")).Amount);
        });
        yield return ("Inventory.SequentialReservation", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            AssertEx.True((await service.ReserveAsync("sku", 6)).Success);
            AssertEx.True(!(await service.ReserveAsync("sku", 6)).Success);
            AssertEx.Equal(6, (await service.GetAsync("sku")).Reserved);
        });
        yield return ("Inventory.ReleaseAndAdjust", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            await service.ReserveAsync("sku", 4);
            var saved = await service.ReleaseAsync("sku", 2, 2);
            AssertEx.Equal(2, saved.Reserved);
            saved = await service.AdjustAsync("sku", 20, 3);
            AssertEx.Equal(18, saved.Available);
        });
        yield return ("Inventory.InvalidQuantity", async () =>
        {
            var service = new InventoryService(new InMemoryDatabaseSession(), new NoOpReservationObserver());
            await service.CreateAsync(new InventoryItem { Id = "sku", Code = "SKU", Sku = "sku", OnHand = 10 });
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.ReserveAsync("sku", 0));
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.AdjustAsync("sku", -1, 1));
        });
        yield return ("Architecture.DomainHasNoApplicationReference", () =>
        {
            var references = typeof(BusinessDocument).Assembly.GetReferencedAssemblies();
            AssertEx.True(!references.Any(x => x.Name is "Benchmark.Application" or "Benchmark.Infrastructure" or "Benchmark.Api"));
            return Task.CompletedTask;
        });
        yield return ("Architecture.ApplicationHasNoInfrastructureReference", () =>
        {
            var references = typeof(PurchaseOrderService).Assembly.GetReferencedAssemblies();
            AssertEx.True(!references.Any(x => x.Name is "Benchmark.Infrastructure" or "Benchmark.Api"));
            return Task.CompletedTask;
        });
    }
}
''')
put('src/Tests/Program.cs','''using System.Diagnostics;
using System.Text.Json;
using Benchmark.Tests;

var tests = ModuleCases.All().Concat(WorkflowCases.All()).ToArray();
var results = new List<object>();
var failures = 0;
foreach (var (name, test) in tests)
{
    var watch = Stopwatch.StartNew();
    try
    {
        await test();
        results.Add(new { name, passed = true, durationMs = watch.Elapsed.TotalMilliseconds, error = "" });
    }
    catch (Exception error)
    {
        failures++;
        results.Add(new { name, passed = false, durationMs = watch.Elapsed.TotalMilliseconds, error = error.ToString() });
        Console.Error.WriteLine($"FAIL {name}: {error.Message}");
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { total = tests.Length, passed = tests.Length - failures, failed = failures, results }));
return failures == 0 ? 0 : 1;
''')

put('README.md','''# CAI enterprise engineering feasibility benchmark

This is a purpose-built synthetic C#/.NET 8 benchmark, generated for a bounded engineering feasibility experiment. It is not production software, a previously observed enterprise codebase, or a participant study. Domain schemas and regression cases are programmatically generated from 15 explicit business-module specifications; shared implementations avoid source padding.

## Architecture

* Domain: immutable ERP documents, validation rules, lifecycle transitions, purchase lines, stock and audit records.
* Application: application-owned storage/audit ports, generic document operations and three task-facing workflow services.
* Infrastructure: in-process immutable-record storage, transaction staging and audit sink.
* Api: ASP.NET Core minimal endpoints for 15 document modules plus workflow routes.
* Tests: package-free console runner with module lifecycle, validation, concurrency-version, rollback and architectural dependency cases.

The adapter has no crash durability and is not a general database. Transaction staging serializes transaction callbacks; direct writes outside those callbacks are not serializable with transactions. All data are synthetic. Endpoints are intentionally local laboratory interfaces and have no production authentication deployment.

## Reproduce

Use .NET SDK 8.0.425 (pinned in global.json). No NuGet packages are required; NuGet.Config clears package sources.

```
dotnet restore src/Api/Benchmark.Api.csproj --configfile NuGet.Config
dotnet restore src/Tests/Benchmark.Tests.csproj --configfile NuGet.Config
dotnet build src/Api/Benchmark.Api.csproj --no-restore -c Release
dotnet build src/Tests/Benchmark.Tests.csproj --no-restore -c Release
dotnet run --project src/Tests/Benchmark.Tests.csproj --no-build -c Release
dotnet run --project src/Api/Benchmark.Api.csproj --no-build -c Release --urls http://127.0.0.1:5088
```

The test program reports actual assertions and elapsed times as JSON. API startup is not part of the timed gate workload unless the run manifest says so. No xUnit/MSTest or external analyzer download is needed.

## Task snapshots

T1 procurement abstraction refactoring, T2 sales audit delivery, and T3 inventory concurrency correction start from the same frozen commit, with independent resets. Normal public tests pass on the baseline. Task-specific hidden acceptance checks are kept outside this repository. These are distinct independent task patches, not a sequential evolution of one repository.

T1 has direct application access to the application-owned IDatabaseSession port; this is a design refactoring opportunity, not a pre-existing application-to-infrastructure reference violation. T2 currently performs business updates without audit delivery. T3 includes a lost-update path in ReserveAsync; IReservationObserver allows a deterministic interleaving in external tests. The defects/missing features are known seeded task conditions, not natural field prevalence.

The provenance manifest reports physical and nonblank C# source lines without inflating a nominal eighteen-thousand-line target. The included generator can faithfully recreate the source baseline but should not be run over submitted patches.
''')

files=sorted(ROOT.rglob('*.cs'))
counts=[]
for f in files:
    lines=f.read_text().splitlines()
    counts.append({'path':str(f.relative_to(ROOT)), 'physical_lines':len(lines), 'nonblank_lines':sum(bool(x.strip()) for x in lines),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
manifest={
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'origin':'Purpose-built synthetic benchmark generated in this revision session by ChatGPT coding agent',
 'generator':'../generate_benchmark.py',
 'sdk':'8.0.425','framework':'net8.0','external_packages':[],
 'module_count':len(MODULES),'modules':[x[0] for x in MODULES],
 'source_generation':'15 schema-driven immutable document classes; common shared service and test cases; handwritten task workflow templates. No filler files.',
 'line_count_definition':'Physical and nonblank lines in .cs files; nonblank is not a lexical SLOC estimator and includes comments/braces.',
 'csharp_files':len(counts),'physical_csharp_lines':sum(x['physical_lines'] for x in counts),'nonblank_csharp_lines':sum(x['nonblank_lines'] for x in counts),
 'files':counts
}
put('provenance.json',json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}, indent=2))
