from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent/'benchmark'
def put(path,text):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n')

put('src/Application/Policies/PurchasePlanningPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;

public sealed record SupplierOffer(string SupplierId, decimal UnitPrice, int LeadDays, decimal Reliability);
public sealed record ReceiptMatch(bool QuantityMatches, bool PriceMatches, decimal Difference, string Status);
public static class PurchasePlanningPolicy
{
    public static decimal NetTotal(IEnumerable<PurchaseOrderLine> lines, decimal discountPercent)
    {
        Rules.Range(discountPercent, 0, 100, nameof(discountPercent));
        var items = lines.ToArray();
        foreach (var line in items) line.Validate();
        return decimal.Round(items.Sum(x => x.NetTotal) * (1 - discountPercent / 100m), 2, MidpointRounding.AwayFromZero);
    }
    public static DateOnly LatestOrderDate(DateOnly requiredDate, int leadDays, int safetyDays)
    {
        Rules.Range(leadDays, 0, 730, nameof(leadDays));
        Rules.Range(safetyDays, 0, 365, nameof(safetyDays));
        return requiredDate.AddDays(-leadDays - safetyDays);
    }
    public static SupplierOffer SelectOffer(IEnumerable<SupplierOffer> offers, int maximumLeadDays, decimal minimumReliability)
    {
        Rules.Range(maximumLeadDays, 0, 730, nameof(maximumLeadDays));
        Rules.Range(minimumReliability, 0, 1, nameof(minimumReliability));
        var candidates = offers.ToArray();
        foreach (var offer in candidates)
        {
            Rules.Required(offer.SupplierId, nameof(offer.SupplierId), 64);
            Rules.Range(offer.UnitPrice, 0, 1000000, nameof(offer.UnitPrice));
            Rules.Range(offer.LeadDays, 0, 730, nameof(offer.LeadDays));
            Rules.Range(offer.Reliability, 0, 1, nameof(offer.Reliability));
        }
        return candidates.Where(x => x.LeadDays <= maximumLeadDays && x.Reliability >= minimumReliability)
            .OrderBy(x => x.UnitPrice).ThenBy(x => x.LeadDays).ThenBy(x => x.SupplierId, StringComparer.Ordinal)
            .FirstOrDefault() ?? throw new DomainValidationException("No qualifying supplier offer.");
    }
    public static ReceiptMatch MatchReceipt(int ordered, int received, decimal expectedPrice, decimal invoicePrice, decimal tolerancePercent)
    {
        Rules.Range(ordered, 1, 1000000, nameof(ordered));
        Rules.Range(received, 0, 1000000, nameof(received));
        Rules.Range(expectedPrice, 0, 1000000, nameof(expectedPrice));
        Rules.Range(invoicePrice, 0, 1000000, nameof(invoicePrice));
        Rules.Range(tolerancePercent, 0, 100, nameof(tolerancePercent));
        var difference = decimal.Abs(invoicePrice - expectedPrice);
        var priceMatches = difference <= expectedPrice * tolerancePercent / 100m;
        var quantityMatches = ordered == received;
        var state = quantityMatches && priceMatches ? "Matched" : received > ordered ? "OverReceived" : "Review";
        return new(quantityMatches, priceMatches, difference, state);
    }
    public static bool RequiresSecondApproval(PurchaseOrder order, decimal approvalLimit, bool newSupplier)
    {
        order.Validate();
        Rules.Range(approvalLimit, 0, 1000000000, nameof(approvalLimit));
        return order.Amount > approvalLimit || newSupplier;
    }
    public static int DelayDays(PurchaseOrder order, DateOnly asOf)
    {
        order.Validate();
        if (order.Status is DocumentStatus.Closed or DocumentStatus.Cancelled) return 0;
        return Math.Max(0, asOf.DayNumber - order.ExpectedDate.DayNumber);
    }
}
''')
put('src/Application/Policies/SalesPricingPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record PriceBreakdown(decimal Subtotal, decimal Discount, decimal Net, decimal Tax, decimal Gross);
public sealed record Allocation(string WarehouseId, int Quantity);
public static class SalesPricingPolicy
{
    public static PriceBreakdown Calculate(decimal unitPrice, int quantity, decimal discountPercent, decimal taxPercent)
    {
        Rules.Range(unitPrice, 0, 1000000, nameof(unitPrice));
        Rules.Range(quantity, 1, 1000000, nameof(quantity));
        Rules.Range(discountPercent, 0, 100, nameof(discountPercent));
        Rules.Range(taxPercent, 0, 100, nameof(taxPercent));
        var subtotal = decimal.Round(unitPrice * quantity, 2, MidpointRounding.AwayFromZero);
        var discount = decimal.Round(subtotal * discountPercent / 100m, 2, MidpointRounding.AwayFromZero);
        var net = subtotal - discount;
        var tax = decimal.Round(net * taxPercent / 100m, 2, MidpointRounding.AwayFromZero);
        return new(subtotal, discount, net, tax, net + tax);
    }
    public static decimal AvailableCredit(SalesOrder order, decimal outstanding)
    {
        order.Validate();
        Rules.Range(outstanding, 0, 1000000000, nameof(outstanding));
        return Math.Max(0, order.CreditLimit - outstanding);
    }
    public static IReadOnlyList<Allocation> Allocate(int requested, IReadOnlyDictionary<string, int> stock)
    {
        Rules.Range(requested, 1, 1000000, nameof(requested));
        if (stock.Values.Any(x => x < 0)) throw new DomainValidationException("Stock cannot be negative.");
        var remaining = requested;
        var result = new List<Allocation>();
        foreach (var location in stock.OrderByDescending(x => x.Value).ThenBy(x => x.Key, StringComparer.Ordinal))
        {
            var take = Math.Min(remaining, location.Value);
            if (take > 0) result.Add(new(location.Key, take));
            remaining -= take;
            if (remaining == 0) break;
        }
        if (remaining > 0) throw new DomainValidationException("Insufficient total stock.");
        return result;
    }
    public static DateOnly PromiseDate(DateOnly ordered, int preparationDays, int transportDays)
    {
        Rules.Range(preparationDays, 0, 365, nameof(preparationDays));
        Rules.Range(transportDays, 0, 365, nameof(transportDays));
        return ordered.AddDays(preparationDays + transportDays);
    }
    public static decimal GrossOrderAmount(SalesOrder order)
    {
        order.Validate();
        return decimal.Round(order.Amount * (1 + order.TaxPercent / 100m), 2, MidpointRounding.AwayFromZero);
    }
    public static bool CanPromise(SalesOrder order, DateOnly earliestDelivery)
    {
        order.Validate();
        return order.Status is not (DocumentStatus.Cancelled or DocumentStatus.Closed) && earliestDelivery <= order.PromisedDate;
    }
}
''')
put('src/Application/Policies/SupplierQualificationPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record SupplierPerformance(int Deliveries, int OnTime, int Accepted, decimal AverageLeadDays);
public sealed record SupplierAssessment(decimal OnTimeRate, decimal AcceptanceRate, decimal Score, bool Qualified, string Reason);
public static class SupplierQualificationPolicy
{
    public static SupplierAssessment Assess(Supplier supplier, SupplierPerformance performance, int minimumDeliveries, decimal minimumScore)
    {
        supplier.Validate();
        Rules.Range(minimumDeliveries, 1, 1000000, nameof(minimumDeliveries));
        Rules.Range(minimumScore, 0, 100, nameof(minimumScore));
        ValidatePerformance(performance);
        var onTime = performance.Deliveries == 0 ? 0 : (decimal)performance.OnTime / performance.Deliveries;
        var accepted = performance.Deliveries == 0 ? 0 : (decimal)performance.Accepted / performance.Deliveries;
        var score = decimal.Round((onTime * 0.6m + accepted * 0.4m) * 100m, 2);
        var qualified = supplier.IsApproved && performance.Deliveries >= minimumDeliveries && score >= minimumScore;
        var reason = !supplier.IsApproved ? "NotApproved" : performance.Deliveries < minimumDeliveries ? "InsufficientHistory" : score < minimumScore ? "LowScore" : "Qualified";
        return new(onTime, accepted, score, qualified, reason);
    }
    public static void ValidatePerformance(SupplierPerformance performance)
    {
        Rules.Range(performance.Deliveries, 0, 1000000, nameof(performance.Deliveries));
        Rules.Range(performance.OnTime, 0, performance.Deliveries, nameof(performance.OnTime));
        Rules.Range(performance.Accepted, 0, performance.Deliveries, nameof(performance.Accepted));
        Rules.Range(performance.AverageLeadDays, 0, 730, nameof(performance.AverageLeadDays));
    }
    public static DateOnly PaymentDueDate(Supplier supplier, DateOnly invoiceDate)
    {
        supplier.Validate();
        return invoiceDate.AddDays(supplier.PaymentDays);
    }
    public static decimal EarlyPaymentDiscount(decimal invoiceAmount, decimal percent, DateOnly paidOn, DateOnly discountDeadline)
    {
        Rules.Range(invoiceAmount, 0, 1000000000, nameof(invoiceAmount));
        Rules.Range(percent, 0, 100, nameof(percent));
        return paidOn <= discountDeadline ? decimal.Round(invoiceAmount * percent / 100m, 2, MidpointRounding.AwayFromZero) : 0m;
    }
    public static bool HasDuplicateTaxNumber(Supplier supplier, IEnumerable<Supplier> existing)
    {
        supplier.Validate();
        return existing.Any(x => x.Id != supplier.Id && x.Country == supplier.Country && x.TaxNumber == supplier.TaxNumber);
    }
}
''')
put('src/Application/Policies/CustomerCreditPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record Receivable(decimal Amount, DateOnly DueDate, decimal Paid);
public sealed record AgingBalance(decimal Current, decimal Days1To30, decimal Days31To60, decimal Days61Plus)
{
    public decimal Total => Current + Days1To30 + Days31To60 + Days61Plus;
}
public static class CustomerCreditPolicy
{
    public static AgingBalance Aging(IEnumerable<Receivable> receivables, DateOnly asOf)
    {
        decimal current = 0, first = 0, second = 0, last = 0;
        foreach (var item in receivables)
        {
            Rules.Range(item.Amount, 0, 1000000000, nameof(item.Amount));
            Rules.Range(item.Paid, 0, item.Amount, nameof(item.Paid));
            var remaining = item.Amount - item.Paid;
            var days = asOf.DayNumber - item.DueDate.DayNumber;
            if (days <= 0) current += remaining;
            else if (days <= 30) first += remaining;
            else if (days <= 60) second += remaining;
            else last += remaining;
        }
        return new(current, first, second, last);
    }
    public static decimal CreditRemaining(Customer customer, decimal receivables, decimal openOrders)
    {
        customer.Validate();
        Rules.Range(receivables, 0, 1000000000, nameof(receivables));
        Rules.Range(openOrders, 0, 1000000000, nameof(openOrders));
        return Math.Max(0, customer.CreditLimit - receivables - openOrders);
    }
    public static bool CanAcceptOrder(Customer customer, decimal orderAmount, decimal receivables, decimal openOrders, bool creditHold)
    {
        Rules.Range(orderAmount, 0, 1000000000, nameof(orderAmount));
        return !creditHold && orderAmount <= CreditRemaining(customer, receivables, openOrders);
    }
    public static DateOnly DueDate(Customer customer, DateOnly invoiceDate)
    {
        customer.Validate();
        return invoiceDate.AddDays(customer.PaymentDays);
    }
    public static string CollectionBand(AgingBalance aging)
    {
        if (aging.Current < 0 || aging.Days1To30 < 0 || aging.Days31To60 < 0 || aging.Days61Plus < 0)
            throw new DomainValidationException("Aging balances cannot be negative.");
        if (aging.Days61Plus > 0) return "Escalate";
        if (aging.Days31To60 > 0) return "Contact";
        if (aging.Days1To30 > 0) return "Reminder";
        return "Current";
    }
}
''')
put('src/Application/Policies/ProductCatalogPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record StockPlan(int ReorderPoint, int SuggestedQuantity, decimal StockValue);
public static class ProductCatalogPolicy
{
    public static decimal ConvertQuantity(decimal quantity, decimal unitsPerPack)
    {
        Rules.Range(quantity, 0, 100000000, nameof(quantity));
        if (unitsPerPack <= 0) throw new DomainValidationException("Conversion factor must be positive.");
        return quantity * unitsPerPack;
    }
    public static decimal UnitCost(decimal packageCost, int unitsPerPack)
    {
        Rules.Range(packageCost, 0, 1000000000, nameof(packageCost));
        Rules.Range(unitsPerPack, 1, 1000000, nameof(unitsPerPack));
        return decimal.Round(packageCost / unitsPerPack, 4, MidpointRounding.AwayFromZero);
    }
    public static decimal GrossMarginPercent(Product product, decimal unitCost)
    {
        product.Validate();
        Rules.Range(unitCost, 0, 10000000, nameof(unitCost));
        if (product.UnitPrice == 0) return 0m;
        return decimal.Round((product.UnitPrice - unitCost) / product.UnitPrice * 100m, 2);
    }
    public static decimal ShipmentWeight(Product product, int quantity, decimal packagingWeight)
    {
        product.Validate();
        Rules.Range(quantity, 0, 1000000, nameof(quantity));
        Rules.Range(packagingWeight, 0, 100000, nameof(packagingWeight));
        return product.WeightKg * quantity + packagingWeight;
    }
    public static StockPlan Replenish(Product product, int onHand, int openOrders, decimal dailyDemand, int leadDays, int safetyStock, int targetDays)
    {
        product.Validate();
        Rules.Range(onHand, 0, 10000000, nameof(onHand));
        Rules.Range(openOrders, 0, 10000000, nameof(openOrders));
        Rules.Range(dailyDemand, 0, 100000, nameof(dailyDemand));
        Rules.Range(leadDays, 0, 365, nameof(leadDays));
        Rules.Range(safetyStock, 0, 1000000, nameof(safetyStock));
        Rules.Range(targetDays, leadDays, 730, nameof(targetDays));
        var reorder = checked((int)decimal.Ceiling(dailyDemand * leadDays) + safetyStock);
        var target = checked((int)decimal.Ceiling(dailyDemand * targetDays) + safetyStock);
        var available = checked(onHand + openOrders);
        var suggested = available <= reorder ? Math.Max(0, target - available) : 0;
        return new(reorder, suggested, onHand * product.UnitPrice);
    }
}
''')
put('src/Application/Policies/WarehouseCapacityPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record StorageLot(string Id, int Quantity, DateOnly ReceivedOn, DateOnly ExpiresOn);
public sealed record PickLine(string LotId, int Quantity);
public static class WarehouseCapacityPolicy
{
    public static decimal UtilizationPercent(Warehouse warehouse, int occupied)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        return decimal.Round((decimal)occupied / warehouse.Capacity * 100m, 2);
    }
    public static bool CanReceive(Warehouse warehouse, int occupied, int incoming, decimal requiredMinimum, decimal requiredMaximum)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        Rules.Range(incoming, 0, 10000000, nameof(incoming));
        if (requiredMinimum > requiredMaximum) throw new DomainValidationException("Invalid storage temperature interval.");
        return (long)occupied + incoming <= warehouse.Capacity
            && warehouse.MinimumTemperature >= requiredMinimum && warehouse.MaximumTemperature <= requiredMaximum;
    }
    public static IReadOnlyList<PickLine> PickFirstExpiring(IEnumerable<StorageLot> lots, int requested, DateOnly asOf)
    {
        Rules.Range(requested, 1, 1000000, nameof(requested));
        var source = lots.ToArray();
        if (source.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != source.Length)
            throw new DomainValidationException("Lot identifiers must be unique.");
        foreach (var lot in source)
        {
            Rules.Required(lot.Id, nameof(lot.Id), 64);
            Rules.Range(lot.Quantity, 0, 1000000, nameof(lot.Quantity));
            Rules.DateOrder(lot.ReceivedOn, lot.ExpiresOn, nameof(lot.ExpiresOn));
        }
        var remaining = requested;
        var picks = new List<PickLine>();
        foreach (var lot in source.Where(x => x.ReceivedOn <= asOf && x.ExpiresOn >= asOf).OrderBy(x => x.ExpiresOn).ThenBy(x => x.ReceivedOn).ThenBy(x => x.Id, StringComparer.Ordinal))
        {
            var quantity = Math.Min(remaining, lot.Quantity);
            if (quantity > 0) picks.Add(new(lot.Id, quantity));
            remaining -= quantity;
            if (remaining == 0) break;
        }
        if (remaining > 0) throw new DomainValidationException("Insufficient nonexpired stock.");
        return picks;
    }
    public static int FreeCapacity(Warehouse warehouse, int occupied)
    {
        warehouse.Validate();
        Rules.Range(occupied, 0, warehouse.Capacity, nameof(occupied));
        return warehouse.Capacity - occupied;
    }
}
''')
put('src/Application/Policies/ShipmentPlanningPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record ShippingQuote(decimal BaseCost, decimal FuelSurcharge, decimal Insurance, decimal Total);
public static class ShipmentPlanningPolicy
{
    public static DateOnly AddWorkingDays(DateOnly date, int days, IReadOnlySet<DateOnly> holidays)
    {
        Rules.Range(days, 0, 730, nameof(days));
        var current = date;
        while (days > 0)
        {
            current = current.AddDays(1);
            if (current.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday) && !holidays.Contains(current)) days--;
        }
        return current;
    }
    public static ShippingQuote Quote(decimal weightKg, decimal distanceKm, decimal baseFee, decimal perKgKm, decimal fuelPercent, decimal declaredValue, decimal insurancePercent)
    {
        Rules.Range(weightKg, 0, 1000000, nameof(weightKg));
        Rules.Range(distanceKm, 0, 100000, nameof(distanceKm));
        Rules.Range(baseFee, 0, 1000000, nameof(baseFee));
        Rules.Range(perKgKm, 0, 100, nameof(perKgKm));
        Rules.Range(fuelPercent, 0, 100, nameof(fuelPercent));
        Rules.Range(declaredValue, 0, 1000000000, nameof(declaredValue));
        Rules.Range(insurancePercent, 0, 100, nameof(insurancePercent));
        var cost = decimal.Round(baseFee + weightKg * distanceKm * perKgKm, 2, MidpointRounding.AwayFromZero);
        var fuel = decimal.Round(cost * fuelPercent / 100m, 2, MidpointRounding.AwayFromZero);
        var insurance = decimal.Round(declaredValue * insurancePercent / 100m, 2, MidpointRounding.AwayFromZero);
        return new(cost, fuel, insurance, cost + fuel + insurance);
    }
    public static int TransitDays(Shipment shipment)
    {
        shipment.Validate();
        return shipment.ArrivalDate.DayNumber - shipment.DispatchDate.DayNumber;
    }
    public static decimal DelayPenalty(Shipment shipment, DateOnly actualArrival, decimal dailyPercent, decimal maximumPercent)
    {
        shipment.Validate();
        Rules.Range(dailyPercent, 0, 100, nameof(dailyPercent));
        Rules.Range(maximumPercent, 0, 100, nameof(maximumPercent));
        var days = Math.Max(0, actualArrival.DayNumber - shipment.ArrivalDate.DayNumber);
        return decimal.Round(shipment.Amount * Math.Min(days * dailyPercent, maximumPercent) / 100m, 2, MidpointRounding.AwayFromZero);
    }
    public static bool CanDispatch(Shipment shipment, DateOnly date, bool goodsReady)
    {
        shipment.Validate();
        return goodsReady && shipment.Status == DocumentStatus.Approved && date >= shipment.DispatchDate;
    }
}
''')
put('src/Application/Policies/WorkOrderSchedulingPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record MaintenanceSlot(string WorkOrderId, DateTimeOffset Start, DateTimeOffset End, string Technician);
public static class WorkOrderSchedulingPolicy
{
    public static DateTimeOffset DueAt(WorkOrder order, DateTimeOffset reportedAt, IReadOnlyDictionary<int, int> responseHours)
    {
        order.Validate();
        if (!responseHours.TryGetValue(order.Priority, out var hours) || hours < 0)
            throw new DomainValidationException("No valid response target for priority.");
        return reportedAt.AddHours(hours);
    }
    public static decimal Cost(WorkOrder order, decimal hourlyRate, decimal partsCost)
    {
        order.Validate();
        Rules.Range(hourlyRate, 0, 1000000, nameof(hourlyRate));
        Rules.Range(partsCost, 0, 1000000000, nameof(partsCost));
        return decimal.Round(order.ActualHours * hourlyRate + partsCost, 2, MidpointRounding.AwayFromZero);
    }
    public static decimal VariancePercent(WorkOrder order)
    {
        order.Validate();
        if (order.PlannedHours == 0) return 0;
        return decimal.Round((order.ActualHours - order.PlannedHours) / order.PlannedHours * 100m, 2);
    }
    public static bool Overlaps(MaintenanceSlot first, MaintenanceSlot second)
    {
        ValidateSlot(first);
        ValidateSlot(second);
        return first.Technician == second.Technician && first.Start < second.End && second.Start < first.End;
    }
    public static void ValidateSlot(MaintenanceSlot slot)
    {
        Rules.Required(slot.WorkOrderId, nameof(slot.WorkOrderId), 64);
        Rules.Required(slot.Technician, nameof(slot.Technician), 64);
        if (slot.End <= slot.Start) throw new DomainValidationException("Maintenance slot must have positive duration.");
    }
    public static IReadOnlyList<WorkOrder> Prioritize(IEnumerable<WorkOrder> orders)
    {
        var items = orders.ToArray();
        foreach (var item in items) item.Validate();
        return items.Where(x => x.Status is not (DocumentStatus.Closed or DocumentStatus.Cancelled))
            .OrderBy(x => x.Priority).ThenBy(x => x.BusinessDate).ThenBy(x => x.Id, StringComparer.Ordinal).ToArray();
    }
    public static decimal RemainingHours(WorkOrder order)
    {
        order.Validate();
        return Math.Max(0, order.PlannedHours - order.ActualHours);
    }
}
''')
put('src/Application/Policies/EmployeeSchedulingPolicy.cs','''using Benchmark.Domain;
namespace Benchmark.Application;
public sealed record WorkEntry(DateOnly Date, decimal Hours, string Project);
public sealed record TimeSummary(decimal RegularHours, decimal OvertimeHours, decimal TotalHours, decimal Cost);
public static class EmployeeSchedulingPolicy
{
    // Parameters represent synthetic organization policy, not statutory employment rules.
    public static TimeSummary Summarize(Employee employee, IEnumerable<WorkEntry> entries, decimal hourlyRate, decimal overtimeMultiplier)
    {
        employee.Validate();
        Rules.Range(hourlyRate, 0, 1000000, nameof(hourlyRate));
        Rules.Range(overtimeMultiplier, 1, 10, nameof(overtimeMultiplier));
        var source = entries.ToArray();
        foreach (var entry in source)
        {
            Rules.Range(entry.Hours, 0, 24, nameof(entry.Hours));
            Rules.Required(entry.Project, nameof(entry.Project), 64);
            if (entry.Date < employee.HireDate) throw new DomainValidationException("Work entry precedes hire date.");
        }
        if (source.GroupBy(x => x.Date).Any(day => day.Sum(x => x.Hours) > 24))
            throw new DomainValidationException("A day cannot contain more than 24 hours.");
        if (source.Length > 0 && source.Max(x => x.Date).DayNumber - source.Min(x => x.Date).DayNumber > 6)
            throw new DomainValidationException("Summary must cover at most seven consecutive days.");
        var total = source.Sum(x => x.Hours);
        var regular = Math.Min(total, employee.WeeklyHours);
        var overtime = Math.Max(0, total - employee.WeeklyHours);
        var cost = decimal.Round((regular + overtime * overtimeMultiplier) * hourlyRate, 2, MidpointRounding.AwayFromZero);
        return new(regular, overtime, total, cost);
    }
    public static int CompletedServiceMonths(Employee employee, DateOnly asOf)
    {
        employee.Validate();
        if (asOf < employee.HireDate) return 0;
        var months = (asOf.Year - employee.HireDate.Year) * 12 + asOf.Month - employee.HireDate.Month;
        if (asOf.Day < employee.HireDate.Day) months--;
        return Math.Max(0, months);
    }
    public static decimal AccruedLeave(Employee employee, DateOnly asOf, decimal annualDays, decimal usedDays)
    {
        Rules.Range(annualDays, 0, 100, nameof(annualDays));
        Rules.Range(usedDays, 0, 100000, nameof(usedDays));
        return Math.Max(0, decimal.Round(CompletedServiceMonths(employee, asOf) * annualDays / 12m, 2) - usedDays);
    }
    public static bool CanAllocate(Employee employee, decimal alreadyAllocated, decimal newHours)
    {
        employee.Validate();
        Rules.Range(alreadyAllocated, 0, 168, nameof(alreadyAllocated));
        Rules.Range(newHours, 0, 168, nameof(newHours));
        return alreadyAllocated + newHours <= employee.WeeklyHours;
    }
}
''')

# Explicit regression code is generated so each partition has a stable named test in raw logs.
# Distinct partitions exercise validation, all status pairs, stale writes and rollback behavior.
names=['PurchaseOrder','SalesOrder','Supplier','Customer','Product','Warehouse','Invoice','Payment','Shipment','Asset','WorkOrder','Employee','ExpenseClaim','ReturnAuthorization','Contract']
invalid={
 'Id':[('Empty','""'),('Whitespace','" "'),('EmbeddedSpace','"bad id"'),('TooLong','new string(\'i\',65)')],
 'Code':[('Empty','""'),('Whitespace','" "'),('TooLong','new string(\'c\',41)')],
 'Amount':[('NegativeCent','-0.01m'),('NegativeWhole','-1m'),('BeyondLimit','1000000000.01m')],
 'Currency':[('Empty','""'),('Short','"TR"'),('Long','"TRYY"'),('Lower','"try"'),('Digit','"TR1"'),('Space','"T R"')],
 'BusinessDate':[('TooEarly','new DateOnly(1999,12,31)'),('TooLate','new DateOnly(2101,1,1)')],
 'Description':[('TooLong','new string(\'d\',2001)')],
 'Version':[('NegativeOne','-1'),('NegativeLarge','-100')],
 'Status':[('BelowEnum','(DocumentStatus)(-1)'),('AboveEnum','(DocumentStatus)6')]
}
valid={
 'Id':[('One','"a"'),('Limit','new string(\'i\',64)'),('Dash','"id-a"'),('Digits','"12345"')],
 'Code':[('One','"c"'),('Limit','new string(\'c\',40)'),('SpaceInside','"CODE A"')],
 'Amount':[('Zero','0m'),('Cent','0.01m'),('Normal','100m')],
 'Currency':[('TRY','"TRY"'),('USD','"USD"'),('EUR','"EUR"'),('Synthetic','"ZZZ"')],
 'Description':[('Empty','""'),('One','"d"'),('Limit','new string(\'d\',2000)')],
 'Version':[('Zero','0'),('One','1'),('Large','1000000')],
}
specific_invalid={
 'PurchaseOrder':[('SupplierId','""'),('ExpectedDate','new DateOnly(2025,12,31)'),('DiscountPercent','-0.01m'),('DiscountPercent','100.01m'),('DeliveryTerms','""')],
 'SalesOrder':[('CustomerId','""'),('PromisedDate','new DateOnly(2025,12,31)'),('TaxPercent','-0.01m'),('TaxPercent','100.01m'),('CreditLimit','-1m')],
 'Supplier':[('TaxNumber','""'),('TaxNumber','"ABC123"'),('PaymentDays','-1'),('PaymentDays','366'),('Country','"T"'),('Country','"TUR"')],
 'Customer':[('TaxNumber','""'),('CreditLimit','-1m'),('CreditLimit','100000001m'),('PaymentDays','-1'),('PaymentDays','366'),('Email','"missing-at"')],
 'Product':[('Sku','""'),('Unit','""'),('UnitPrice','-1m'),('UnitPrice','10000001m'),('WeightKg','-1m'),('WeightKg','100001m')],
 'Warehouse':[('LocationCode','""'),('Capacity','0'),('Capacity','10000001'),('MinimumTemperature','41m'),('MinimumTemperature','-101m')],
 'Invoice':[('OrderId','""'),('DueDate','new DateOnly(2025,12,31)'),('TaxAmount','-1m'),('TaxAmount','1000000001m'),('PaidAmount','-1m'),('PaidAmount','1000000m')],
 'Payment':[('InvoiceId','""'),('Method','"Unknown"'),('Reference','""'),('Fee','-1m'),('Fee','101m')],
 'Shipment':[('OrderId','""'),('Carrier','""'),('DispatchDate','new DateOnly(2025,12,31)'),('ArrivalDate','new DateOnly(2026,1,1)')],
 'Asset':[('SerialNumber','""'),('UsefulLifeMonths','0'),('UsefulLifeMonths','1201'),('SalvageValue','-1m'),('SalvageValue','101m'),('AcquisitionDate','new DateOnly(2026,1,2)')],
 'WorkOrder':[('AssetId','""'),('Priority','0'),('Priority','6'),('PlannedHours','-1m'),('PlannedHours','10001m'),('ActualHours','-1m'),('ActualHours','10001m')],
 'Employee':[('Department','""'),('PersonnelNumber','""'),('HireDate','new DateOnly(2026,1,2)'),('WeeklyHours','0m'),('WeeklyHours','61m')],
 'ExpenseClaim':[('EmployeeId','""'),('Category','"Unknown"'),('ReceiptAmount','99m'),('ReceiptAttached','false')],
 'ReturnAuthorization':[('OrderId','""'),('Reason','"Unknown"'),('Quantity','0'),('Quantity','100001'),('RestockingPercent','-1m'),('RestockingPercent','100.01m')],
 'Contract':[('Counterparty','""'),('EndDate','new DateOnly(2025,12,31)'),('NoticeDays','-1'),('NoticeDays','366'),('EndDate','new DateOnly(2026,1,10)')]
}
statuses=['Draft','Submitted','Approved','Fulfilled','Closed','Cancelled']
allowed={('Draft','Submitted'),('Draft','Cancelled'),('Submitted','Draft'),('Submitted','Approved'),('Submitted','Cancelled'),('Approved','Fulfilled'),('Approved','Cancelled'),('Fulfilled','Closed')}
calls=[]
for name in names:
 cases=[]
 def case(label,body):
  cases.append(f'''        yield return ("{name}.Partition.{label}", async () =>
        {{
{body}
            await Task.CompletedTask;
        }});''')
 factory=f'new {name} {{ Id = "id", Code = "code", Amount = 100m }}'
 for field,values in invalid.items():
  for label,value in values:
   case(f'{field}.{label}',f'''            var original = {factory};
            original.Validate();
            var invalid = original with {{ {field} = {value} }};
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);
            AssertEx.Equal("id", original.Id);''')
 for field,values in valid.items():
  for label,value in values:
   # Receipt constraint makes tiny amounts valid; all default other values support these ranges.
   case(f'{field}.{label}.Accepted',f'''            var original = {factory};
            var candidate = original with {{ {field} = {value} }};
            candidate.Validate();
            AssertEx.Equal({value}, candidate.{field});
            AssertEx.Equal("code", original.Code);''')
 for idx,(field,value) in enumerate(specific_invalid[name]):
  case(f'Specific.{field}.{idx}',f'''            var original = {factory};
            original.Validate();
            var invalid = original with {{ {field} = {value} }};
            AssertEx.Throws<DomainValidationException>(() => invalid.Validate());
            AssertEx.Equal(100m, original.Amount);''')
 # Exercise all 36 distinct lifecycle source-target pairs per concrete type.
 for source in statuses:
  for target in statuses:
   body=f'''            var original = {factory} with {{ Status = DocumentStatus.{source}, Version = 7 }};
            original.Validate();'''
   if (source,target) in allowed:
    body+=f'''
            var updated = ({name})original.NextStatus(DocumentStatus.{target});
            AssertEx.Equal(DocumentStatus.{target}, updated.Status);
            AssertEx.Equal(8, updated.Version);
            AssertEx.Equal(original.Id, updated.Id);
            AssertEx.Equal(original.Amount, updated.Amount);'''
   else: body+=f'''
            AssertEx.Throws<DomainValidationException>(() => original.NextStatus(DocumentStatus.{target}));
            AssertEx.Equal(DocumentStatus.{source}, original.Status);
            AssertEx.Equal(7, original.Version);'''
   case(f'Status.{source}To{target}',body)
 # Persistence checks are actual adapter/service calls for each concrete record type.
 for expected in [0,2,7,-1]:
  case(f'StaleExpectedVersion.{str(expected).replace("-","Minus")}',f'''            var service = new DocumentService<{name}>(new InMemoryDatabaseSession());
            var saved = await service.CreateAsync({factory});
            await AssertEx.ThrowsAsync<ConcurrencyConflictException>(() => service.UpdateDraftAsync(saved with {{ Description = "stale" }}, {expected}));
            var actual = await service.GetAsync("id");
            AssertEx.Equal(1, actual.Version);
            AssertEx.Equal("", actual.Description);''')
 for status in ['Submitted','Approved','Fulfilled','Closed','Cancelled']:
  case(f'TerminalCreate.{status}',f'''            var service = new DocumentService<{name}>(new InMemoryDatabaseSession());
            var candidate = {factory} with {{ Status = DocumentStatus.{status} }};
            await AssertEx.ThrowsAsync<DomainValidationException>(() => service.CreateAsync(candidate));
            AssertEx.Equal(0, (await service.ListAsync()).Count);''')
 for failure in ['InvalidOperationException','DomainValidationException','ConcurrencyConflictException']:
  case(f'Rollback.{failure}',f'''            var session = new InMemoryDatabaseSession();
            await AssertEx.ThrowsAsync<{failure}>(() => session.InTransactionAsync<int>(async token =>
            {{
                await session.SaveAsync({factory}, token);
                throw new {failure}("injected persistence fault");
            }}));
            AssertEx.True(await session.FindAsync<{name}>("id") is null);''')
 put(f'src/Tests/Generated/{name}Partitions.cs',f'''// Generated validation partitions from expand_benchmark.py; stable independent case names.
using Benchmark.Application;
using Benchmark.Domain;
using Benchmark.Infrastructure;
namespace Benchmark.Tests;
public static class {name}Partitions
{{
    public static IEnumerable<(string, Func<Task>)> All()
    {{
{chr(10).join(cases)}
    }}
}}''')
 calls.append(f'        foreach (var item in {name}Partitions.All()) yield return item;')
put('src/Tests/Generated/PartitionCases.cs',f'''namespace Benchmark.Tests;
public static class PartitionCases
{{
    public static IEnumerable<(string, Func<Task>)> All()
    {{
{chr(10).join(calls)}
    }}
}}''')
print(json.dumps({'modules':len(names),'partition_files':len(calls),'generator':'expand_benchmark.py','purpose':'explicit boundary partitions, transition-pair coverage, stale writes, transaction rollback'},indent=2))
