# T2 — Asynchronous sales-order audit recording

Extend `SalesOrderService` to record an audit event for each successful sales-order change. Each event must include an immutable snapshot of the old and new order state, the actor, and the event timestamp. Preserve the existing sales-order business rules and provide a way for the caller to observe the audit outcome.

Submit audit work asynchronously through an awaitable queue after the business update has committed. A delivery or enqueue failure must leave the committed business change intact and expose a retryable audit state. Accepted audit work must remain available through a snapshot and restoration of the in-memory queue storage you provide. Retries must preserve the original event and must not apply the business change again or create duplicate delivered events. Await the operations needed to establish the reported outcome.

Preserve cancellation behavior and define clearly how cancellation is reported when the business change has already committed. The implementation must build on .NET 8 without introducing external packages. Run the existing tests and add focused tests where needed. Submit the code changes and a concise explanation of the audit lifecycle and validation performed.
