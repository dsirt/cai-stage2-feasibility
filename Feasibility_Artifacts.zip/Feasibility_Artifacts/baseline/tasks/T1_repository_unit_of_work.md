# T1 — Purchase-order persistence refactoring

Refactor `PurchaseOrderService` so that its purchase-order persistence operations use repository and unit-of-work abstractions instead of calling `IDatabaseSession` directly.

Preserve the existing public service API and observable behavior, including validation, returned values, stored values, transaction boundaries, failure behavior, and cancellation. Keep application-layer dependencies directed toward application or domain contracts. Provide the infrastructure implementations and update composition so that the existing application continues to run.

The implementation must build on .NET 8 without introducing external packages. Run the existing tests and add focused tests where needed to demonstrate the behavior of your changes. Submit the code changes and a concise explanation of the design and validation performed.
