# T3 — Concurrent inventory reservations

Update `InventoryService.ReserveAsync` so that overlapping reservation requests produce correct inventory and reservation results. Each successful request must consume its requested quantity exactly once. A request that cannot be fulfilled must not consume stock, and available stock must never become negative.

Preserve the existing public API, validation, cancellation behavior, and behavior for ordinary sequential requests. Keep `IReservationObserver.AfterReadAsync` available for deterministic coordination in tests. The implementation should also work when separate service instances share the same persistence session or store.

The implementation must build on .NET 8 without introducing external packages. Run the existing tests and add focused tests where needed to demonstrate correctness for overlapping requests. Submit the code changes and a concise explanation of the concurrency approach and validation performed.
