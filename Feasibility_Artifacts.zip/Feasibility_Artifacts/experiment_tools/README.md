# Report-only engineering feasibility runner

This directory contains an executable measurement harness, not empirical results. Unit tests use artificial commands solely to check instrumentation; they must never be counted as benchmark observations. A separate frozen benchmark manifest, real gate commands, and an actual output directory are required for an engineering experiment. No human adjudication, Study A/B participant data, or longitudinal evidence is supplied by this harness.

## Invocation

```bash
python run_measurements.py --manifest manifest.json --gates gates.json --output results --repetitions 3 --parent-repetitions 1 --concurrency 1,2,4
python -m unittest discover -s . -p 'test_runner.py'
```

The output directory must be empty. Neither the runner nor its report-only verdicts reject a change, alter a patch, merge, or deploy. Gate commands must themselves be observational, except for ordinary build/test outputs in the disposable worktree. Do not put secrets in configuration values: the resolved configuration is preserved with the evidence.

## Input contracts

The manifest is a JSON object with `repository_id` and a nonempty `changes` list. Every change requires `change_id`, `parent_commit`, `head_commit`, `parent_path`, and `head_path`; `diff_path` is strongly recommended. Paths are absolute or relative to the manifest directory. Commits must be full immutable git identifiers from the frozen benchmark, not invented IDs. Each unique parent is scheduled once per concurrency scenario by default; `parent_map.csv` links every head to its baseline. Every scheduled job needs a distinct worktree. Repetitions for a given head run sequentially within that job, preventing concurrent writes to the same build directories. Different heads must not share writable build outputs or mutable external services.

The gate configuration is a JSON object with a nonempty `gates` list. Each gate has:

| Key | Meaning |
|---|---|
| `id` | Unique alphanumeric, underscore, or hyphen identifier. |
| `command` | Executable and arguments as a JSON string array; never a shell command string. |
| `kind` | `analysis`, `build`, or `test`, recorded verbatim. |
| `timeout_seconds` | Positive per-command timeout; default 120. |
| `success_exit_codes` | Completed command codes; default `[0]`. |
| `finding_exit_codes` | Completed analysis with findings; default `[1]` for non-build commands, `[]` for builds. Explicitly configure this for each real tool. |
| `requires_success` | IDs of preceding gates that must be analyzable and pass before execution. Omit to run independently. |
| `require_result_json` | If true, a missing or invalid machine-readable result is an analysis error. |
| `version` | Frozen tool/version identifier. |
| `version_command` | Optional argv array, run once before measurements; its output is preserved and hashed. |

Optional top-level `environment` entries extend the inherited environment. Optional `preparation_command` is run once per workspace per concurrency scenario and recorded separately from gate durations; it must not change tracked benchmark source. Its default timeout is 300 seconds, configurable by `preparation_timeout_seconds`. A preparation failure leaves dependent measurements `not_evaluable`. The runner does not infer that preparation establishes a cold cache.

Commands can use `{workspace}`, `{change_id}`, `{parent_commit}`, `{head_commit}`, `{scanned_commit}`, `{scan_role}`, `{diff_path}`, `{result_json}`, `{repetition}`, `{concurrency}`, `{output_dir}`, and `{gate_id}`. Only explicit placeholder tokens are replaced. Tool-side JSON braces remain intact.

An analyzer may write `{result_json}` with these fields:

| Field | Allowed values or type |
|---|---|
| `status` | `ok`, `analysis_error`, `build_failed`, `not_evaluable` |
| `verdict` | `pass`, `finding`, `not_evaluable`, `not_applicable` |
| `finding_count` | Nonnegative integer; omitted means unavailable, not zero. |
| `finding_ids` | List of stable finding identifiers; empty is permitted. |
| `metrics` | JSON object containing declared analyzer metrics and units. |
| `error` | Optional diagnostic string. |

A nonzero exit code that is not explicitly accepted remains an execution error even if JSON claims success. Invalid result JSON, conflicting pass/nonzero-finding outputs, build failure, timeout, and unavailable prerequisites cannot be interpreted as passing scans. An exit-only result establishes a tool-level verdict, not confirmed defects or diagnostic validity. Gate findings require separate adjudication. Existing accepted parent violations and newly introduced head violations must be distinguished by the paired analysis; raw head scanner totals alone do not establish regressions.

## Measurement semantics and limitations

- The concurrency unit is one complete workspace pipeline job, with three head repetitions sequentially inside the job. Gates within a pipeline run serially in configuration order. Unique parents run once per scenario unless configured otherwise. Scenario throughput therefore includes parent-baseline work, and its denominator is stated in `scenario_summary.json`.
- Every command starts a fresh process. The first observed workspace repetition is labeled `fresh_process_restored_cache`; later repetitions use `fresh_process_reused_workspace_cache`. These are process/workspace labels, not claims of a cold OS, package, compiler, or filesystem cache. No OS cache flush is performed. Restore and any dependency download should finish before timing. The same SDK and package cache may be shared; preparation and run order must be reported. Concurrency scenarios run in the supplied order, so cache/order/time effects limit causal interpretations of throughput differences.
- End-to-end job wall time includes preparation, process launch, all gates, and logging overhead. Per-gate wall time includes process launch, waiting, and polling overhead; the poll interval is 10 ms. `job_queue_wait_seconds` is repeated on gate rows for joining convenience: use the single value in `job_runs.csv`; never sum it across gates or repetitions.
- CPU and RSS come from `os.wait4` for the individual command, avoiding cross-thread subtraction of global child counters. CPU includes child usage only to the extent descendants are waited for and included by the OS. Tools must wait for their own children; detached workers and remote services are outside this accounting. The runner sets `DOTNET_CLI_USE_MSBUILD_SERVER=0` and `MSBUILDDISABLENODEREUSE=1`; .NET commands should also disable shared compilation and node reuse where applicable.
- `maxrss_wait4_kib` is Linux wait4 high-water RSS in KiB. It is not a sum of concurrent-process peaks or aggregate instantaneous process-tree memory. Do not add RSS across gates to claim a pipeline peak. Wall time includes waiting; CPU time and monetary compute allocation are separate measures. Neither is human labor.
- Timeouts terminate the command's process group. Timeout rows retain available resource measurements and have `policy_verdict=not_evaluable`. Dependency failures are logged as skipped attempts, not zero-cost passing scans. Counts of planned, executed, analyzable, skipped, and failed attempts must be reported separately.
- Host metadata includes CPU affinity, visible cgroup CPU quota/cpuset/memory limits, CPU model, resource limits, versions, configuration/runner hashes, and cgroup throttling counters around each scenario. The reported effective CPU upper bound is based on visible limits; inaccessible ancestor quotas, shared-host contention, and external load remain limitations.
- No TP/FP/FN/TN classifications are inferred. Those require a predefined detection-unit universe, independent reproducible evidence, and adjudication. No human task/review/triage/waiver time is inferred from process runtimes. No power or general scalability claim follows from three repetitions on a single host.

## Outputs

`gate_runs.jsonl` is append-only during execution, with one row per planned gate attempt. `gate_runs.csv` contains the same records. `job_runs.csv` contains one row per scheduled workspace job. `parent_map.csv` joins heads to unique parent jobs. `scenario_summary.json` records elapsed time, throughput denominator, errors, job order, and visible CPU throttling. `host_metadata.json`, resolved input JSONs, and `logs/` preserve provenance. Analyzer results are hashed; their raw machine-readable files and stdout/stderr remain available. If an experiment is interrupted, partial rows remain evidence of incompletion and must not be described as a complete run.

This engineering harness does not implement the proposed participant trials, independent hidden behavioral harness, manual defect adjudication, economic cost model, or future D30/D90 follow-up. Those require separate protocol artifacts and execution.
