#!/usr/bin/env python3
"""Rebuild and replay the archived frozen change sets. Does not regenerate AI outputs."""
from pathlib import Path
import argparse,json,subprocess,sys,shutil,os
p=argparse.ArgumentParser();p.add_argument('--archive-root',type=Path,required=True);p.add_argument('--dotnet',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
src=a.archive_root.resolve();dest=a.output.resolve();sdk=a.dotnet.resolve()
if dest.exists():raise SystemExit('Choose a new output directory. Existing evidence is never overwritten.')
if not sdk.is_file():raise SystemExit('Pinned .NET8 SDK executable is required.')
dest.mkdir(parents=True)
(dest/'global.json').write_text(json.dumps({'sdk':{'version':'8.0.425','rollForward':'disable'}},indent=2))
version=subprocess.check_output([str(sdk),'--version'],cwd=dest,text=True).strip()
if version!='8.0.425':raise SystemExit('This archive pins .NET SDK8.0.425. Received '+version)
(dest/'dotnet').symlink_to(sdk.parent,target_is_directory=True)
for name in ['gate_analyzer','experiment_tools']:shutil.copytree(src/name,dest/name,ignore=shutil.ignore_patterns('bin','obj','__pycache__','gates.json'))
record=json.loads((src/'records'/'experiment_manifest.json').read_text());base=record['changes'][0]['parent_commit'];repo=dest/'benchmark'
env=dict(os.environ,DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',MSBUILDDISABLENODEREUSE='1')
def run(cmd,cwd=None):subprocess.run([str(x) for x in cmd],cwd=cwd,env=env,check=True)
run(['git','clone',src/'benchmark.bundle',repo]);run(['git','checkout','--detach',base],repo)
changes=[]
for item in record['changes']:
 w=dest/'agent_runs'/item['change_id'];w.parent.mkdir(exist_ok=True)
 run(['git','worktree','add','--detach',w,item['head_commit']],repo)
 r=dict(item,parent_path=str(repo),head_path=str(w),diff_path=str(src/'traces'/(item['change_id']+'.diff')));changes.append(r)
for w in [repo]+[Path(x['head_path']) for x in changes]:
 run([sdk,'restore','Benchmark.sln','--configfile','NuGet.Config','--disable-parallel','-m:1','-nr:false'],w)
# Restore, compile and run the public suite before timing, as in the original run.
# Head failures are retained by the preflight recorder and do not remove changes.
run([sdk,'build','Benchmark.sln','--no-restore','--no-incremental','--disable-build-servers','-m:1','-nr:false','-p:UseSharedCompilation=false'],repo)
with (dest/'baseline_public_tests.log').open('w') as stream:
 subprocess.run([str(sdk),'run','--project','src/Tests/Benchmark.Tests.csproj','--no-build'],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
plan=dest/'preflight_plan.json'
plan.write_text(json.dumps({'runs':[{'run_id':x['change_id'],'base_commit':x['parent_commit'],'head_commit':x['head_commit'],'path':x['head_path']} for x in changes]},indent=2))
run([sys.executable,dest/'experiment_tools'/'preflight_heads.py','--plan',plan,'--dotnet',sdk,'--out',dest/'preflight','--workers','2'])
run([sdk,'build','GateTool.csproj','-c','Release','--configfile','NuGet.Config','--disable-build-servers','-m:1','-nr:false','-p:UseSharedCompilation=false'],dest/'gate_analyzer')
manifest=dest/'manifest.json';manifest.write_text(json.dumps(dict(record,changes=changes),indent=2))
run([sys.executable,dest/'experiment_tools'/'make_gate_config.py','--work-root',dest,'--output',dest/'gates.json'])
run([sys.executable,dest/'experiment_tools'/'run_measurements.py','--manifest',manifest,'--gates',dest/'gates.json','--output',dest/'measurements','--repetitions','3','--parent-repetitions','1','--concurrency','1,2,4'])
run([sys.executable,dest/'experiment_tools'/'aggregate_measurements.py','--run',dest/'measurements','--output',dest/'summary'])
run([sys.executable,dest/'experiment_tools'/'repetition_variability.py','--run',dest/'measurements','--output',dest/'summary'])
print('New replay measurements:',dest/'measurements')
