"""Unit checks using artificial commands, never engineering-feasibility observations."""
import concurrent.futures
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

import run_measurements as rm
import aggregate_measurements as am


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, source, stem="test", timeout=5):
        return rm.run_process([sys.executable, "-c", source], self.root, os.environ.copy(), timeout,
                              self.root / (stem + ".stdout"), self.root / (stem + ".stderr"))

    def test_success_accounts_for_child(self):
        result = self.invoke("sum(i*i for i in range(250000))")
        self.assertEqual(result["exit_code"], 0)
        self.assertGreater(result["cpu_total_seconds"], 0)
        self.assertGreater(result["maxrss_wait4_kib"], 0)
        self.assertFalse(result["timed_out"])

    def test_parallel_measurements_are_per_process(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(self.invoke, "sum(i*i for i in range(500000))", "cpu")
            second = pool.submit(self.invoke, "import time; time.sleep(0.2)", "idle")
            a, b = first.result(), second.result()
        self.assertEqual([a["exit_code"], b["exit_code"]], [0, 0])
        self.assertGreater(a["cpu_total_seconds"], b["cpu_total_seconds"])

    def test_timeout_is_not_a_finding_or_pass(self):
        process = self.invoke("import time; time.sleep(2)", timeout=0.05)
        result = rm.classify(process, {"kind": "analysis"}, self.root / "missing.json")
        self.assertTrue(process["timed_out"])
        self.assertEqual(result["measurement_status"], "timeout")
        self.assertEqual(result["policy_verdict"], "not_evaluable")

    def test_findings_and_build_failure_are_separate(self):
        process = self.invoke("raise SystemExit(1)")
        finding = rm.classify(process, {"kind": "analysis"}, self.root / "missing.json")
        build = rm.classify(process, {"kind": "build"}, self.root / "missing.json")
        self.assertEqual((finding["measurement_status"], finding["policy_verdict"]), ("ok", "finding"))
        self.assertEqual((build["measurement_status"], build["policy_verdict"]), ("build_failed", "not_evaluable"))

    def test_json_findings_with_success_exit(self):
        process = self.invoke("pass")
        path = self.root / "result.json"
        path.write_text(json.dumps({"status": "ok", "verdict": "finding", "finding_count": 2,
                                    "finding_ids": ["a", "b"], "metrics": {"lines": 12}}))
        result = rm.classify(process, {"kind": "analysis"}, path)
        self.assertEqual(result["finding_count"], 2)
        self.assertEqual(result["policy_verdict"], "finding")

    def test_invalid_json_cannot_pass(self):
        process = self.invoke("pass")
        path = self.root / "result.json"
        path.write_text('{"verdict":"pass","finding_count":2}')
        result = rm.classify(process, {}, path)
        self.assertEqual(result["measurement_status"], "analysis_error")

    def test_requires_result_json(self):
        result = rm.classify(self.invoke("pass"), {"require_result_json": True}, self.root / "missing.json")
        self.assertEqual(result["measurement_status"], "analysis_error")

    def test_duplicate_workspace_is_rejected(self):
        manifest = {"changes": [{"change_id": "check", "parent_commit": "test_parent", "head_commit": "test_head",
                                  "parent_path": str(self.root), "head_path": str(self.root)}]}
        with self.assertRaises(ValueError):
            rm.resolve_jobs(manifest, self.root)

    def test_dependencies_must_reference_earlier_gates(self):
        with self.assertRaises(ValueError):
            rm.validate_gates({"gates": [{"id": "g", "command": ["anything"], "requires_success": ["missing"]}]})

    def test_end_to_end_fake_commands_only(self):
        parent, head = self.root / "parent", self.root / "head"
        parent.mkdir()
        head.mkdir()
        manifest = self.root / "manifest.json"
        manifest.write_text(json.dumps({"changes": [{"change_id": "unit", "parent_commit": "test_parent",
            "head_commit": "test_head", "parent_path": str(parent), "head_path": str(head)}]}))
        gates = self.root / "gates.json"
        gates.write_text(json.dumps({"gates": [{"id": "check", "command": [sys.executable, "-c", "pass"]}]}))
        output = self.root / "output"
        result = rm.main(["--manifest", str(manifest), "--gates", str(gates), "--output", str(output),
                          "--repetitions", "2", "--concurrency", "1,2"])
        self.assertEqual(result, 0)
        rows = [json.loads(line) for line in (output / "gate_runs.jsonl").read_text().splitlines()]
        self.assertEqual(len(rows), 6)
        self.assertTrue(all(r["measurement_status"] == "ok" for r in rows))
        self.assertTrue(all(r["enforcement_mode"] == "report_only" for r in rows))
        self.assertTrue(all(r["resource_measurement"] == "linux_wait4_per_command" for r in rows))
        summary = am.summarize(output, self.root / "summary")
        self.assertEqual(summary["total_planned_gate_attempts"], 6)
        self.assertEqual(summary["unique_head_changes"], 1)
        self.assertFalse(summary["independent_adjudication_available"])
        self.assertTrue((self.root / "summary" / "summary.md").is_file())

    def test_summary_quantile_and_missing_values(self):
        self.assertAlmostEqual(am.quantile([1, 2, 3], .95), 2.9)
        self.assertIsNone(am.quantile([], .95))
        self.assertIsNone(am.number(""))
        self.assertIsNone(am.number("nan"))


if __name__ == "__main__":
    unittest.main()
