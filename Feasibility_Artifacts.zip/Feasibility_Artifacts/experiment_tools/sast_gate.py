#!/usr/bin/env python3
"""Run the SDK's real Microsoft NetAnalyzers Security category in report-only mode."""
import argparse,json,pathlib,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--dotnet',required=True);p.add_argument('--workspace',required=True);p.add_argument('--output',required=True);a=p.parse_args()
w=pathlib.Path(a.workspace);out=pathlib.Path(a.output)
solutions=sorted(w.glob('*.sln'))
if not solutions:
 out.write_text(json.dumps({'status':'analysis_error','reason':'solution_not_found','finding_count':None}));sys.exit(2)
cmd=[a.dotnet,'build',str(solutions[0]),'--no-restore','--no-incremental','--disable-build-servers','-m:1','-p:UseSharedCompilation=false','-p:AnalysisMode=None','-p:AnalysisModeSecurity=All','-p:TreatWarningsAsErrors=false','--verbosity','minimal']
r=subprocess.run(cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
log=out.with_suffix('.build.log');log.write_text(r.stdout)
pat=re.compile(r'^(.*?\.cs)\((\d+),(\d+)\): warning (CA\d+): (.*?) \[(.*?)\]$',re.M)
items={}
for m in pat.finditer(r.stdout):
 path,line,col,rule,msg,project=m.groups()
 try:path=str(pathlib.Path(path).relative_to(w))
 except ValueError:pass
 key=(path,line,col,rule,msg);items[key]={'path':path,'line':int(line),'column':int(col),'rule':rule,'message':msg,'category':'security_analyzer_warning'}
findings=list(items.values());status='ok' if r.returncode==0 else 'analysis_error'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({'tool':'Microsoft.NET.Sdk.NetAnalyzers','sdk':'8.0.425','category':'Security','analysis_mode':'All','status':status,'verdict':('finding' if findings else 'pass') if status=='ok' else 'analysis_error','build_exit_code':r.returncode,'finding_count':len(findings) if status=='ok' else None,'findings':findings,'command':cmd,'log':str(log),'scope':'source projects and tests compiled by solution','limitation':'rule coverage is incomplete and a warning is not an adjudicated vulnerability'},indent=2))
print(json.dumps({'status':status,'finding_count':len(findings),'build_exit_code':r.returncode}))
sys.exit(2 if status!='ok' else (1 if findings else 0))
