#!/usr/bin/env python3
"""Descriptive engineering-run summaries; no defect/adjudication or human-cost inference."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path
import statistics
from typing import Any


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def number(value: Any) -> float | None:
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else None
    except (TypeError, ValueError):
        return None


def quantile(values: list[float], q: float) -> float | None:
    """Linear interpolation between order statistics (Hyndman/Fan type 7)."""
    if not values:
        return None
    ordered = sorted(values)
    point = (len(ordered) - 1) * q
    lo, hi = math.floor(point), math.ceil(point)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (point - lo)


def describe(values: list[Any], prefix: str) -> dict[str, Any]:
    numeric = [v for x in values if (v := number(x)) is not None]
    return {prefix + "_n": len(numeric), prefix + "_median": statistics.median(numeric) if numeric else None,
            prefix + "_p95": quantile(numeric, .95), prefix + "_min": min(numeric) if numeric else None,
            prefix + "_max": max(numeric) if numeric else None}


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize(run: Path, output: Path) -> dict[str, Any]:
    rows = load_csv(run / "gate_runs.csv")
    jobs = load_csv(run / "job_runs.csv")
    scenarios = json.loads((run / "scenario_summary.json").read_text())
    parent_map = {r["head_job_id"]: r["parent_job_id"] for r in load_csv(run / "parent_map.csv")}
    metadata = json.loads((run / "host_metadata.json").read_text())
    grouped: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[row["scenario_id"], row["gate_id"], row["scan_role"]].append(row)
    gate_summary = []
    for (scenario, gate, role), group in sorted(grouped.items()):
        status = Counter(r["measurement_status"] for r in group)
        executed = [r for r in group if r["resource_measurement"] != "not_executed"]
        valid = [r for r in group if r["measurement_status"] == "ok"]
        entry = {"scenario_id": scenario, "concurrency": group[0]["concurrency"], "gate_id": gate,
                 "scan_role": role, "planned_attempts": len(group), "executed_attempts": len(executed),
                 "analyzable_attempts": len(valid), "finding_verdict_attempts": sum(r["policy_verdict"] == "finding" for r in valid),
                 "pass_verdict_attempts": sum(r["policy_verdict"] == "pass" for r in valid),
                 "analysis_error_attempts": status["analysis_error"], "timeout_attempts": status["timeout"],
                 "build_failed_attempts": status["build_failed"], "skipped_prerequisite_attempts": status["prerequisite_failure"],
                 "other_not_evaluable_attempts": sum(v for k, v in status.items() if k not in {"ok", "analysis_error", "timeout", "build_failed", "prerequisite_failure"}),
                 "unique_jobs": len({r["job_id"] for r in group}),
                 "unique_jobs_with_finding": len({r["job_id"] for r in valid if r["policy_verdict"] == "finding"})}
        for metric in ["wall_seconds", "cpu_total_seconds", "maxrss_wait4_kib"]:
            entry.update(describe([r[metric] for r in executed], "executed_" + metric))
            entry.update(describe([r[metric] for r in valid], "analyzable_" + metric))
        gate_summary.append(entry)
    pipeline_summary = []
    for scenario in scenarios:
        sid = scenario["scenario_id"]
        head_jobs = [r for r in jobs if r["scenario_id"] == sid and r["scan_role"] == "head"]
        repetitions: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
        for row in rows:
            if row["scenario_id"] == sid and row["scan_role"] == "head":
                repetitions[row["job_id"], row["repetition"]].append(row)
        complete_reps = [group for group in repetitions.values() if all(r["measurement_status"] == "ok" for r in group)]
        all_attempted_reps = [group for group in repetitions.values() if any(r["resource_measurement"] != "not_executed" for r in group)]
        entry = {k: scenario[k] for k in ["scenario_id", "concurrency", "scenario_wall_seconds", "jobs", "head_repetitions", "scan_attempts", "analyzable_attempts", "analysis_error_attempts"]}
        entry.update(head_jobs=len(head_jobs), complete_analyzable_head_repetitions=len(complete_reps),
                     throughput_head_repetitions_per_second_including_parent_jobs=scenario["head_repetitions_per_second_including_parent_baseline_jobs"],
                     throughput_complete_analyzable_head_repetitions_per_second_including_parent_jobs=len(complete_reps) / scenario["scenario_wall_seconds"])
        for metric in ["queue_wait_seconds", "pipeline_wall_seconds"]:
            entry.update(describe([r[metric] for r in head_jobs], "head_job_" + metric))
        entry.update(describe([float(r["queue_wait_seconds"]) + float(r["pipeline_wall_seconds"]) for r in head_jobs], "head_job_queue_plus_pipeline_seconds"))
        # Sum gate durations within ONE repetition; this excludes inter-gate Python/logging overhead.
        entry.update(describe([sum(float(r["wall_seconds"]) for r in group) for group in all_attempted_reps], "attempted_head_repetition_gate_wall_sum_seconds"))
        entry.update(describe([sum(float(r["wall_seconds"]) for r in group) for group in complete_reps], "analyzable_head_repetition_gate_wall_sum_seconds"))
        pipeline_summary.append(entry)
    by_job_gate: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_job_gate[row["scenario_id"], row["job_id"], row["gate_id"]].append(row)
    paired = []
    for (scenario, job, gate), group in sorted(by_job_gate.items()):
        if group[0]["scan_role"] != "head":
            continue
        parent_job = parent_map[job]
        parents = by_job_gate.get((scenario, parent_job, gate), [])
        heads_ok = [r for r in group if r["measurement_status"] == "ok"]
        parents_ok = [r for r in parents if r["measurement_status"] == "ok"]
        head_counts = [v for r in heads_ok if (v := number(r["finding_count"])) is not None]
        parent_counts = [v for r in parents_ok if (v := number(r["finding_count"])) is not None]
        h = statistics.median(head_counts) if head_counts else None
        p = statistics.median(parent_counts) if parent_counts else None
        metric_strings = {r["metrics_json"] for r in heads_ok}
        paired.append({"scenario_id": scenario, "concurrency": group[0]["concurrency"], "change_id": group[0]["change_id"],
                       "head_job_id": job, "parent_job_id": parent_job, "gate_id": gate,
                       "parent_commit": group[0]["parent_commit"], "head_commit": group[0]["head_commit"],
                       "head_planned_attempts": len(group), "head_analyzable_attempts": len(heads_ok),
                       "parent_planned_attempts": len(parents), "parent_analyzable_attempts": len(parents_ok),
                       "head_alert_count_median": h, "parent_alert_count_median": p,
                       "head_minus_parent_alert_count": h - p if h is not None and p is not None else None,
                       "head_alert_count_min": min(head_counts) if head_counts else None,
                       "head_alert_count_max": max(head_counts) if head_counts else None,
                       "head_count_repeat_consistent": len(set(head_counts)) == 1 if head_counts else None,
                       "head_metrics_repeat_consistent": len(metric_strings) == 1 if metric_strings else None,
                       "head_metrics_json": next(iter(metric_strings)) if len(metric_strings) == 1 else "",
                       "independent_adjudication_available": False,
                       "interpretation": "Tool alert count difference only; not confirmed introduced defects or detection accuracy."})
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "gate_timing_summary.csv", gate_summary)
    write_csv(output / "pipeline_timing_summary.csv", pipeline_summary)
    write_csv(output / "paired_alert_summary.csv", paired)
    summary = {"status_counts": dict(Counter(r["measurement_status"] for r in rows)),
               "total_planned_gate_attempts": len(rows), "unique_head_changes": len(parent_map),
               "quantile_method": "Hyndman-Fan type 7 linear interpolation; descriptive p95, no confidence intervals",
               "independent_adjudication_available": False, "human_participant_data_available": False,
               "host_effective_cpu_upper_bound": metadata.get("effective_cpu_upper_bound"),
               "host_cgroup_cpu_quota_cores": metadata.get("cgroup_cpu_quota_cores"),
               "gate_summary": gate_summary, "pipeline_summary": pipeline_summary}
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    md = ["# Descriptive engineering-feasibility measurements\n",
          f"The recorded run contains {len(parent_map)} head changes and {len(rows)} planned gate attempts. "
          f"Measurement statuses: {json.dumps(summary['status_counts'], sort_keys=True)}. "
          "These are tool-execution and policy-alert observations, not independent defect adjudication, human-study outcomes, or longitudinal validation.\n",
          "## Pipeline timing\n",
          "The job unit contains all repeated scans of one workspace. Queue/pipeline medians therefore describe that repeated workload; they are not single-PR developer latency. Repetition wall sums exclude inter-gate runner overhead. Throughput denominators include scheduled parent-baseline scans.\n",
          "| Concurrency | Head repetitions | Analyzable repetitions | Scenario wall (s) | Repetitions/s | Median job queue (s) | Median repetition gate-wall sum (s) | p95 repetition gate-wall sum (s) |\n|---|---:|---:|---:|---:|---:|---:|---:|\n"]
    def fmt(x):
        return "unavailable" if x is None else f"{x:.3f}"
    for row in pipeline_summary:
        md.append(f"| {row['concurrency']} | {row['head_repetitions']} | {row['complete_analyzable_head_repetitions']} | {fmt(row['scenario_wall_seconds'])} | {fmt(row['throughput_head_repetitions_per_second_including_parent_jobs'])} | {fmt(row['head_job_queue_wait_seconds_median'])} | {fmt(row['attempted_head_repetition_gate_wall_sum_seconds_median'])} | {fmt(row['attempted_head_repetition_gate_wall_sum_seconds_p95'])} |\n")
    md.extend(["\n## Per-gate timing for head scans\n",
               "Executed-attempt timing includes timed-out and failed processes when measured. Skipped prerequisites are excluded from execution timing; analyzable-only alternatives are supplied in the CSV.\n",
               "| Concurrency | Gate | Executed / planned | Analyzable | Finding verdicts | Median wall (s) | p95 wall (s) | Median CPU (s) | Median wait4 maxRSS (KiB) |\n|---|---|---:|---:|---:|---:|---:|---:|---:|\n"])
    for row in gate_summary:
        if row["scan_role"] == "head":
            md.append(f"| {row['concurrency']} | {row['gate_id']} | {row['executed_attempts']} / {row['planned_attempts']} | {row['analyzable_attempts']} | {row['finding_verdict_attempts']} | {fmt(row['executed_wall_seconds_median'])} | {fmt(row['executed_wall_seconds_p95'])} | {fmt(row['executed_cpu_total_seconds_median'])} | {fmt(row['executed_maxrss_wait4_kib_median'])} |\n")
    md.extend(["\n## Interpretation limits\n",
        "Repetitions are repeated observations of the same constructed changes, not independent developer samples. p95 uses linear interpolation (type 7) and is descriptive; no inferential confidence intervals or significance tests are produced. Concurrency scenarios run in the recorded sequence on one host without OS cache flushing, so workload, cache/order effects, CPU limits, and shared-host contention bound any scaling interpretation. wait4 CPU and RSS have the process-accounting limits documented in the runner README; RSS is not an aggregate process-tree peak.\n",
        "Paired alert counts link each head to the same-concurrency parent scan. Their arithmetic difference is not a count of newly introduced confirmed defects; rules, locations, and baseline acceptance still require inspection. No TP/FP/FN/TN labels, false-positive rates, sensitivity, human triage/review/waiver costs, or H1–H4 conclusions are inferred. Engineering evidence establishes only what these recorded commands actually measured.\n"])
    (output / "summary.md").write_text("".join(md))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = summarize(args.run, args.output)
    print(json.dumps({"summary_output": str(args.output), "planned_attempts": result["total_planned_gate_attempts"],
                      "status_counts": result["status_counts"]}))
