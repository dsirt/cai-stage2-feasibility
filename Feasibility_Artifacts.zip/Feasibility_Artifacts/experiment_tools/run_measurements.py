#!/usr/bin/env python3
"""Report-only engineering-feasibility runner. No benchmark or observations bundled."""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import signal
import subprocess
import sys
import threading
import time
from typing import Any

SCHEMA_VERSION = "1.0"
ALLOWED_STATUSES = {"ok", "analysis_error", "build_failed", "not_evaluable"}
ALLOWED_VERDICTS = {"pass", "finding", "not_evaluable", "not_applicable"}
CSV_FIELDS = [
    "schema_version", "scenario_id", "concurrency", "job_id", "change_id", "scan_role",
    "parent_commit", "head_commit", "scanned_commit", "workspace", "diff_path", "diff_sha256",
    "repetition", "cache_label", "cache_reset_performed", "gate_id", "gate_kind", "attempt_id",
    "enforcement_mode", "command_json", "gate_definition_sha256", "tool_version_sha256",
    "started_utc", "ended_utc", "job_queue_wait_seconds", "wall_seconds", "cpu_user_seconds",
    "cpu_system_seconds", "cpu_total_seconds", "maxrss_wait4_kib", "resource_measurement",
    "exit_code", "timed_out", "timeout_seconds", "measurement_status", "policy_verdict",
    "finding_count", "finding_ids_json", "metrics_json", "measurement_error", "stdout_path",
    "stderr_path", "result_json_path", "result_json_sha256", "prerequisites_json",
]
JOB_FIELDS = [
    "scenario_id", "concurrency", "job_id", "change_id", "scan_role", "scanned_commit",
    "workspace", "repetitions", "started_utc", "ended_utc", "queue_wait_seconds",
    "pipeline_wall_seconds", "scan_attempts", "analyzable_attempts", "analysis_error_attempts",
    "finding_attempts", "preparation_status", "preparation_wall_seconds",
]


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def json_hash(value: Any) -> str:
    return sha256_bytes(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def file_hash(path: Path) -> str:
    return sha256_bytes(path.read_bytes()) if path.is_file() else ""


def read_text_optional(path: str) -> str | None:
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def host_metadata() -> dict[str, Any]:
    cgroups = {p: read_text_optional(p) for p in [
        "/sys/fs/cgroup/cpu.max", "/sys/fs/cgroup/cpu.stat",
        "/sys/fs/cgroup/cpuset.cpus.effective", "/sys/fs/cgroup/memory.max",
        "/sys/fs/cgroup/cpu/cpu.cfs_quota_us", "/sys/fs/cgroup/cpu/cpu.cfs_period_us",
    ]}
    cpu_quota = None
    raw = cgroups["/sys/fs/cgroup/cpu.max"]
    if raw:
        quota, period = raw.split()[:2]
        if quota != "max":
            cpu_quota = int(quota) / int(period)
    elif cgroups["/sys/fs/cgroup/cpu/cpu.cfs_quota_us"]:
        quota = int(cgroups["/sys/fs/cgroup/cpu/cpu.cfs_quota_us"])
        period = int(cgroups["/sys/fs/cgroup/cpu/cpu.cfs_period_us"] or 0)
        if quota > 0 and period > 0:
            cpu_quota = quota / period
    affinity = sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None
    candidates = [x for x in [cpu_quota, len(affinity) if affinity else None, os.cpu_count()] if x]
    cpu_model = None
    for line in (read_text_optional("/proc/cpuinfo") or "").splitlines():
        if line.startswith("model name"):
            cpu_model = line.partition(":")[2].strip()
            break
    return {
        "recorded_utc": utcnow(), "platform": platform.platform(), "uname": list(platform.uname()),
        "os_release": read_text_optional("/etc/os-release"),
        "python": sys.version, "logical_cpu_count": os.cpu_count(), "cpu_affinity": affinity,
        "cgroup_cpu_quota_cores": cpu_quota, "effective_cpu_upper_bound": min(candidates) if candidates else None,
        "cpu_model": cpu_model, "cgroup_files": cgroups,
        "meminfo": read_text_optional("/proc/meminfo"),
        "resource_limits": {name: list(resource.getrlimit(getattr(resource, name))) for name in
                            ["RLIMIT_CPU", "RLIMIT_AS", "RLIMIT_NOFILE", "RLIMIT_NPROC"] if hasattr(resource, name)},
        "os_cache_flush_performed": False,
        "resource_method": "Per-command Linux wait4 rusage; maxRSS is wait4 high-water RSS, not aggregate simultaneous process-tree RSS.",
    }


def expand_command(command: list[str], values: dict[str, Any]) -> list[str]:
    if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
        raise ValueError("Commands must be nonempty argv string lists; shell strings are not supported")
    # Only declared placeholders are replaced, so JSON braces in tool arguments are safe.
    result = []
    for value in command:
        for key, replacement in values.items():
            value = value.replace("{" + key + "}", str(replacement))
        result.append(value)
    return result


def run_process(command: list[str], cwd: Path, env: dict[str, str], timeout: float,
                stdout_path: Path, stderr_path: Path) -> dict[str, Any]:
    """wait4 avoids cross-thread RUSAGE_CHILDREN contamination and does not use a shell."""
    start = time.monotonic()
    result: dict[str, Any] = {"started_utc": utcnow(), "exit_code": "", "timed_out": False,
                              "cpu_user_seconds": "", "cpu_system_seconds": "", "cpu_total_seconds": "",
                              "maxrss_wait4_kib": "", "measurement_error": ""}
    proc = None
    try:
        with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
            proc = subprocess.Popen(command, cwd=str(cwd), env=env, stdout=out, stderr=err,
                                    stdin=subprocess.DEVNULL, start_new_session=True)
            while True:
                pid, status, usage = os.wait4(proc.pid, os.WNOHANG)
                if pid:
                    break
                if time.monotonic() - start >= timeout:
                    result["timed_out"] = True
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    _, status, usage = os.wait4(proc.pid, 0)
                    break
                time.sleep(0.01)
            proc.returncode = os.waitstatus_to_exitcode(status)
            result.update(exit_code=proc.returncode, cpu_user_seconds=usage.ru_utime,
                          cpu_system_seconds=usage.ru_stime, cpu_total_seconds=usage.ru_utime + usage.ru_stime,
                          maxrss_wait4_kib=usage.ru_maxrss)
    except (OSError, ValueError) as exc:
        result["measurement_error"] = f"{type(exc).__name__}: {exc}"
        if proc is not None and proc.returncode is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
                _, status, _ = os.wait4(proc.pid, 0)
                proc.returncode = os.waitstatus_to_exitcode(status)
            except (OSError, ChildProcessError):
                pass
    result.update(ended_utc=utcnow(), wall_seconds=time.monotonic() - start,
                  resource_measurement="linux_wait4_per_command")
    return result


def classify(process: dict[str, Any], gate: dict[str, Any], result_path: Path) -> dict[str, Any]:
    out: dict[str, Any] = {"measurement_status": "ok", "policy_verdict": "pass", "finding_count": "",
                           "finding_ids_json": "[]", "metrics_json": "{}", "measurement_error": process["measurement_error"]}
    if process["timed_out"]:
        out.update(measurement_status="timeout", policy_verdict="not_evaluable")
        return out
    if process["measurement_error"]:
        out.update(measurement_status="analysis_error", policy_verdict="not_evaluable")
        return out
    code = process["exit_code"]
    success = gate.get("success_exit_codes", [0])
    findings = gate.get("finding_exit_codes", [1] if gate.get("kind", "analysis") != "build" else [])
    if code not in success + findings:
        out.update(measurement_status="build_failed" if gate.get("kind") == "build" else "analysis_error",
                   policy_verdict="not_evaluable", measurement_error=f"Unaccepted exit code {code}")
        return out
    out["policy_verdict"] = "finding" if code in findings else "pass"
    if result_path.is_file():
        try:
            raw = json.loads(result_path.read_text())
            status = raw.get("status", "ok")
            verdict = raw.get("verdict", out["policy_verdict"])
            count = raw.get("finding_count", "")
            if status not in ALLOWED_STATUSES or verdict not in ALLOWED_VERDICTS:
                raise ValueError("Unknown result status or verdict")
            if count != "" and (isinstance(count, bool) or not isinstance(count, int) or count < 0):
                raise ValueError("finding_count must be a nonnegative integer")
            if not isinstance(raw.get("finding_ids", []), list) or not isinstance(raw.get("metrics", {}), dict):
                raise ValueError("finding_ids must be a list; metrics must be an object")
            if status == "ok" and verdict == "pass" and count not in ("", 0):
                raise ValueError("Passing result cannot have nonzero findings")
            if code in findings and verdict == "pass":
                raise ValueError("Finding exit code conflicts with passing JSON result")
            out.update(measurement_status=status, policy_verdict=verdict if status == "ok" else "not_evaluable",
                       finding_count=count, finding_ids_json=json.dumps(raw.get("finding_ids", []), sort_keys=True),
                       metrics_json=json.dumps(raw.get("metrics", {}), sort_keys=True),
                       measurement_error=str(raw.get("error", "")))
        except (ValueError, TypeError, OSError) as exc:
            out.update(measurement_status="analysis_error", policy_verdict="not_evaluable",
                       measurement_error=f"Invalid analyzer JSON: {exc}")
    elif gate.get("require_result_json", False):
        out.update(measurement_status="analysis_error", policy_verdict="not_evaluable",
                   measurement_error="Required analyzer JSON missing")
    return out


def resolve_jobs(manifest: dict[str, Any], base: Path) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    changes = manifest.get("changes")
    if not isinstance(changes, list) or not changes:
        raise ValueError("Manifest requires a nonempty changes list")
    parents: dict[str, dict[str, Any]] = {}
    heads = []
    parent_map = []
    change_ids: set[str] = set()
    for change in changes:
        cid = str(change["change_id"])
        if cid in change_ids or not cid or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in cid):
            raise ValueError(f"Invalid or duplicate change_id {cid!r}")
        change_ids.add(cid)
        for required in ["parent_commit", "head_commit", "parent_path", "head_path"]:
            if not change.get(required):
                raise ValueError(f"Missing {required} for {cid}")
        parent_key = str(change.get("repository_id", manifest.get("repository_id", "repository"))) + ":" + change["parent_commit"]
        paths = {}
        for key in ["parent_path", "head_path", "diff_path"]:
            if change.get(key):
                p = Path(change[key])
                paths[key] = str((p if p.is_absolute() else base / p).resolve())
        for key in ["parent_path", "head_path"]:
            if not Path(paths[key]).is_dir():
                raise ValueError(f"Workspace does not exist: {paths[key]}")
        if parent_key not in parents:
            pid = "parent_" + sha256_bytes(parent_key.encode())[:12]
            parents[parent_key] = dict(change)
            parents[parent_key].update(paths)
            parents[parent_key].update(job_id=pid, change_id=pid, scan_role="parent",
                                      head_commit=change["parent_commit"], scanned_commit=change["parent_commit"],
                                      workspace=paths["parent_path"], diff_path="", diff_sha256="")
        head = dict(change, **paths, job_id="head_" + cid, scan_role="head",
                    scanned_commit=change["head_commit"], workspace=paths["head_path"])
        head["diff_sha256"] = file_hash(Path(paths["diff_path"])) if paths.get("diff_path") else ""
        heads.append(head)
        parent_map.append({"change_id": cid, "head_job_id": head["job_id"],
                           "parent_job_id": parents[parent_key]["job_id"], "parent_commit": change["parent_commit"],
                           "head_commit": change["head_commit"]})
    jobs = list(parents.values()) + heads
    workspace_paths = [x["workspace"] for x in jobs]
    if len(workspace_paths) != len(set(workspace_paths)):
        raise ValueError("Each scheduled parent/head job needs a distinct workspace; concurrent writes would be unsafe")
    return jobs, parent_map


class Runner:
    def __init__(self, output: Path, config: dict[str, Any], jobs: list[dict[str, Any]], repetitions: int,
                 parent_repetitions: int, versions: dict[str, Any]):
        self.output, self.config, self.jobs = output, config, jobs
        self.repetitions, self.parent_repetitions = repetitions, parent_repetitions
        self.versions = versions
        self.lock = threading.Lock()
        self.rows: list[dict[str, Any]] = []
        self.job_rows: list[dict[str, Any]] = []
        self.seen: set[str] = set()
        self.env = os.environ.copy()
        self.env.update({"DOTNET_CLI_USE_MSBUILD_SERVER": "0", "MSBUILDDISABLENODEREUSE": "1"})
        self.env.update({str(k): str(v) for k, v in config.get("environment", {}).items()})

    def record(self, row: dict[str, Any]) -> None:
        with self.lock:
            self.rows.append(row)
            with (self.output / "gate_runs.jsonl").open("a") as stream:
                stream.write(json.dumps(row, sort_keys=True) + "\n")

    def job(self, job: dict[str, Any], scenario: str, concurrency: int, queued: float) -> dict[str, Any]:
        begin = time.monotonic()
        queue_wait = begin - queued
        started = utcnow()
        repetitions = self.parent_repetitions if job["scan_role"] == "parent" else self.repetitions
        directory = self.output / "logs" / scenario / job["job_id"]
        directory.mkdir(parents=True)
        prep_status, prep_wall = "not_requested", 0.0
        prep = self.config.get("preparation_command")
        # Preparation occurs once per scenario, is measured separately, and is never called a cold OS cache.
        if prep:
            command = expand_command(prep, job)
            outcome = run_process(command, Path(job["workspace"]), self.env,
                                  float(self.config.get("preparation_timeout_seconds", 300)),
                                  directory / "preparation.stdout.log", directory / "preparation.stderr.log")
            prep_wall = outcome["wall_seconds"]
            prep_status = "ok" if outcome["exit_code"] == 0 and not outcome["timed_out"] and not outcome["measurement_error"] else "analysis_error"
        job_rows = []
        for repetition in range(1, repetitions + 1):
            outcomes: dict[str, dict[str, Any]] = {}
            seen_before = job["workspace"] in self.seen or repetition > 1
            cache_label = "fresh_process_restored_cache" if not seen_before else "fresh_process_reused_workspace_cache"
            for gate in self.config["gates"]:
                aid = f"{scenario}_{job['job_id']}_r{repetition}_{gate['id']}"
                result_path = directory / f"r{repetition}_{gate['id']}.result.json"
                stdout_path = directory / f"r{repetition}_{gate['id']}.stdout.log"
                stderr_path = directory / f"r{repetition}_{gate['id']}.stderr.log"
                values = dict(job, result_json=str(result_path), repetition=repetition, concurrency=concurrency,
                              output_dir=str(directory), gate_id=gate["id"])
                command = expand_command(gate["command"], values)
                prerequisites = gate.get("requires_success", [])
                blocked = [key for key in prerequisites if outcomes[key]["measurement_status"] != "ok" or outcomes[key]["policy_verdict"] != "pass"]
                row = {key: "" for key in CSV_FIELDS}
                row.update(schema_version=SCHEMA_VERSION, scenario_id=scenario, concurrency=concurrency,
                           job_id=job["job_id"], change_id=job["change_id"], scan_role=job["scan_role"],
                           parent_commit=job["parent_commit"], head_commit=job["head_commit"],
                           scanned_commit=job["scanned_commit"], workspace=job["workspace"],
                           diff_path=job.get("diff_path", ""), diff_sha256=job.get("diff_sha256", ""),
                           repetition=repetition, cache_label=cache_label, cache_reset_performed=False,
                           gate_id=gate["id"], gate_kind=gate.get("kind", "analysis"), attempt_id=aid,
                           enforcement_mode="report_only", command_json=json.dumps(command),
                           gate_definition_sha256=json_hash(gate), tool_version_sha256=self.versions[gate["id"]]["sha256"],
                           job_queue_wait_seconds=queue_wait, timeout_seconds=float(gate.get("timeout_seconds", 120)),
                           stdout_path=str(stdout_path.relative_to(self.output)), stderr_path=str(stderr_path.relative_to(self.output)),
                           result_json_path=str(result_path.relative_to(self.output)), prerequisites_json=json.dumps(prerequisites))
                if prep_status == "analysis_error" or blocked:
                    row.update(started_utc=utcnow(), ended_utc=utcnow(), wall_seconds=0.0,
                               measurement_status="prerequisite_failure", policy_verdict="not_evaluable",
                               measurement_error="Preparation failed" if prep_status == "analysis_error" else "Unavailable prerequisite(s): " + ", ".join(blocked),
                               resource_measurement="not_executed", timed_out=False)
                else:
                    process = run_process(command, Path(job["workspace"]), self.env, row["timeout_seconds"], stdout_path, stderr_path)
                    row.update(process)
                    row.update(classify(process, gate, result_path))
                    row["result_json_sha256"] = file_hash(result_path)
                outcomes[gate["id"]] = row
                job_rows.append(row)
                self.record(row)
        with self.lock:
            self.seen.add(job["workspace"])
        summary = dict(scenario_id=scenario, concurrency=concurrency, job_id=job["job_id"],
                       change_id=job["change_id"], scan_role=job["scan_role"], scanned_commit=job["scanned_commit"],
                       workspace=job["workspace"], repetitions=repetitions, started_utc=started, ended_utc=utcnow(),
                       queue_wait_seconds=queue_wait, pipeline_wall_seconds=time.monotonic() - begin,
                       scan_attempts=len(job_rows), analyzable_attempts=sum(r["measurement_status"] == "ok" for r in job_rows),
                       analysis_error_attempts=sum(r["measurement_status"] != "ok" for r in job_rows),
                       finding_attempts=sum(r["policy_verdict"] == "finding" and r["measurement_status"] == "ok" for r in job_rows),
                       preparation_status=prep_status, preparation_wall_seconds=prep_wall)
        with self.lock:
            self.job_rows.append(summary)
        print(json.dumps({"completed_job": job["job_id"], "scenario": scenario,
                          "attempts": len(job_rows), "errors": summary["analysis_error_attempts"]}), flush=True)
        return summary

    def run(self, concurrency_values: list[int]) -> list[dict[str, Any]]:
        scenarios = []
        for index, concurrency in enumerate(concurrency_values, 1):
            scenario = f"s{index}_c{concurrency}"
            start = time.monotonic()
            utc_start = utcnow()
            before = read_text_optional("/sys/fs/cgroup/cpu.stat")
            # Canonical order is preserved and recorded. Concurrency scenarios are descriptive, not randomized.
            with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
                futures = [pool.submit(self.job, job, scenario, concurrency, time.monotonic()) for job in self.jobs]
                completed = [future.result() for future in futures]
            seconds = time.monotonic() - start
            head_repetitions = sum(x["repetitions"] for x in completed if x["scan_role"] == "head")
            scenarios.append({"scenario_id": scenario, "concurrency": concurrency,
                              "started_utc": utc_start, "ended_utc": utcnow(), "scenario_wall_seconds": seconds,
                              "jobs": len(completed), "head_repetitions": head_repetitions,
                              "head_repetitions_per_second_including_parent_baseline_jobs": head_repetitions / seconds,
                              "scan_attempts": sum(x["scan_attempts"] for x in completed),
                              "analyzable_attempts": sum(x["analyzable_attempts"] for x in completed),
                              "analysis_error_attempts": sum(x["analysis_error_attempts"] for x in completed),
                              "cgroup_cpu_stat_before": before, "cgroup_cpu_stat_after": read_text_optional("/sys/fs/cgroup/cpu.stat"),
                              "job_order": [x["job_id"] for x in self.jobs]})
            self.flush(scenarios)
        return scenarios

    def flush(self, scenarios: list[dict[str, Any]]) -> None:
        write_csv(self.output / "gate_runs.csv", CSV_FIELDS, self.rows)
        write_csv(self.output / "job_runs.csv", JOB_FIELDS, self.job_rows)
        (self.output / "scenario_summary.json").write_text(json.dumps(scenarios, indent=2) + "\n")


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def validate_gates(config: dict[str, Any]) -> None:
    if not isinstance(config.get("gates"), list) or not config["gates"]:
        raise ValueError("Gate configuration requires a nonempty gates list")
    seen = set()
    for gate in config["gates"]:
        gid = gate["id"]
        if gid in seen or not gid or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in gid):
            raise ValueError(f"Invalid or duplicate gate id: {gid}")
        expand_command(gate["command"], {})
        if float(gate.get("timeout_seconds", 120)) <= 0:
            raise ValueError("Timeout must be positive")
        if not set(gate.get("requires_success", [])).issubset(seen):
            raise ValueError(f"Gate {gid} depends on a gate that has not run yet")
        seen.add(gid)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--gates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--parent-repetitions", type=int, default=1)
    parser.add_argument("--concurrency", default="1,2,4")
    args = parser.parse_args(argv)
    if not hasattr(os, "wait4"):
        parser.error("This runner requires Linux/Unix wait4 process accounting")
    concurrency_values = [int(x) for x in args.concurrency.split(",")]
    if args.repetitions < 1 or args.parent_repetitions < 1 or not concurrency_values or min(concurrency_values) < 1:
        parser.error("Repetition and concurrency values must be positive")
    manifest = json.loads(args.manifest.read_text())
    config = json.loads(args.gates.read_text())
    validate_gates(config)
    jobs, parent_map = resolve_jobs(manifest, args.manifest.resolve().parent)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        parser.error("Output directory must be empty to preserve run provenance")
    versions = {}
    environment = os.environ.copy()
    environment.update({str(k): str(v) for k, v in config.get("environment", {}).items()})
    for gate in config["gates"]:
        text = str(gate.get("version", "version_not_supplied"))
        if gate.get("version_command"):
            try:
                measured = subprocess.run(gate["version_command"], capture_output=True, text=True,
                                          timeout=30, env=environment, check=False)
                text += "\n" + measured.stdout + measured.stderr + f"\nexit_code={measured.returncode}"
            except (OSError, subprocess.TimeoutExpired) as exc:
                text += f"\nversion_command_error={exc}"
        versions[gate["id"]] = {"text": text, "sha256": sha256_bytes(text.encode())}
    metadata = host_metadata()
    metadata.update(schema_version=SCHEMA_VERSION, manifest_sha256=file_hash(args.manifest),
                    gate_configuration_sha256=file_hash(args.gates), runner_sha256=file_hash(Path(__file__)),
                    repetitions=args.repetitions, parent_repetitions=args.parent_repetitions,
                    concurrency_values=concurrency_values, tool_versions=versions,
                    configured_environment_keys=sorted(config.get("environment", {}).keys()))
    for filename, value in [("host_metadata.json", metadata), ("resolved_manifest.json", manifest),
                            ("resolved_gates.json", config), ("resolved_jobs.json", jobs)]:
        (output / filename).write_text(json.dumps(value, indent=2) + "\n")
    write_csv(output / "parent_map.csv", ["change_id", "head_job_id", "parent_job_id", "parent_commit", "head_commit"], parent_map)
    runner = Runner(output, config, jobs, args.repetitions, args.parent_repetitions, versions)
    try:
        scenarios = runner.run(concurrency_values)
    except BaseException:
        runner.flush([])
        raise
    print(json.dumps({"completed": True, "output": str(output), "scenarios": len(scenarios),
                      "gate_attempts": len(runner.rows), "report_only": True}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
