"""Create empty prospective human-study schemas; no fabricated observations."""
from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent.parent / "protocol_supplement"
SCHEMAS = {
"report_only_gate_records.csv": """
record_id|id|Unique planned gate-scan-attempt identifier.
schema_version|text|Version of this collection schema.
study_id|enum|engineering_feasibility, A, or B; never pool these populations.
phase|enum|feasibility, pilot, or confirmatory.
participant_id|id|Pseudonymous participant identifier; empty for engineering-only scans.
task_session_id|id|Join to task_sessions when a human session exists.
change_id|id|Immutable change identifier.
paired_scan_id|id|Identifier joining comparable parent and head scans.
scan_role|enum|parent or head.
parent_commit|git_id|Full immutable parent commit identifier.
head_commit|git_id|Full immutable head commit identifier.
scanned_commit|git_id|Commit actually scanned.
diff_reference|reference|Exact reviewed diff artifact.
diff_sha256|sha256|SHA-256 of reviewed diff bytes.
analyzer_name|text|Actual tool name; no inferred capabilities.
analyzer_version|text|Frozen analyzer version.
analyzer_binary_sha256|sha256|Hash of executable or versioned assembly artifact.
rulepack_reference|reference|Frozen rule set and scope.
rulepack_sha256|sha256|Hash of rule configuration.
policy_reference|reference|Frozen threshold and baseline-acceptance policy.
policy_sha256|sha256|Hash of policy bytes.
container_or_runtime_reference|reference|Runtime, SDK, dependency-lock, and container identities.
runtime_manifest_sha256|sha256|Hash of the runtime manifest.
run_id|id|Execution run identifier.
repetition|integer|Repetition index within a workload scenario.
concurrency|integer|Number of simultaneous pipeline jobs; definition frozen in run manifest.
queued_at_utc|datetime|Time job entered execution queue.
started_at_utc|datetime|Time command started.
ended_at_utc|datetime|Time command ended.
queue_wait_seconds|seconds|Queue wait; repeat joins must not be summed multiple times.
wall_seconds|seconds|Elapsed command time including waits.
cpu_user_seconds|seconds|Measured user CPU time for stated accounting scope.
cpu_system_seconds|seconds|Measured system CPU time for stated accounting scope.
maxrss_kib|number|Recorded high-water RSS; accounting method required, not additive across gates.
resource_accounting_method|text|Method and process-tree/remote-worker limitations.
cache_state|text|Observed cache preparation; never call unflushed OS cache cold.
cache_reset_performed|boolean|Whether specified cache contents were explicitly reset.
measurement_status|enum|ok, timeout, build_failed, analysis_error, prerequisite_failure, or not_evaluable.
measurement_quality|enum|valid, partial, invalid, or not_evaluable under frozen rules.
exit_code|integer|Actual process exit code when available.
timeout_seconds|seconds|Configured time limit.
enforcement_mode|enum|report_only for these records.
policy_verdict|enum|pass, finding, not_evaluable, or not_applicable.
parent_baseline_disposition|enum|accepted_clean, accepted_existing_violation, rejected, pending, or not_evaluable.
paired_finding_disposition|enum|new, worsened, unchanged_accepted, resolved, clean, mixed, or not_evaluable.
finding_count|integer|Analyzer findings; not confirmed defect count.
finding_manifest_reference|reference|Stable finding IDs, rule IDs, locations, and evidence.
detection_universe_reference|reference|Prespecified detection unit universe including assessed negatives.
adjudication_reference|reference|Independent finding assessment records.
assessed_tp_count|integer|Adjudicated true positives within declared assessed units.
assessed_fp_count|integer|Adjudicated false positives within declared assessed units.
assessed_fn_count|integer|Adjudicated missed positives in an independently evaluated universe.
assessed_tn_count|integer|Adjudicated true negatives in that same universe; not inferred from no alerts.
unassessed_units|integer|Units lacking a valid independent verdict.
triage_interval_reference|reference|Non-overlapping human triage cost records, if collected.
waiver_id|id|Documented waiver; empty means none recorded, not approval.
waiver_disposition|enum|none, proposed, approved, rejected, expired, or not_applicable.
waiver_owner_id|id|Pseudonymous accountable owner.
waiver_expiry_utc|datetime|Expiry of an approved temporary exception.
rework_event_reference|reference|Linked rework provenance and human activity intervals.
raw_log_reference|reference|Immutable stdout/stderr/results bundle.
raw_log_sha256|sha256|Hash of log bundle or immutable file manifest.
missingness_reference|reference|Reason any planned measurement is unavailable.
""",
"provenance_events.csv": """
event_id|id|Unique ordered provenance event identifier.
event_sequence|integer|Monotone order within the session/run.
schema_version|text|Schema version.
study_id|enum|engineering_feasibility, A, or B.
run_id|id|Run identifier.
task_session_id|id|Human session if present.
participant_id|id|Pseudonymous participant identifier if present.
task_id|id|Task specification identifier.
actor_id|id|Pseudonymous human or separately identified agent/service actor.
actor_type|enum|agent, human, tool, or system.
actor_role|text|Originator, reviewer, adjudicator, administrator, agent, or service role.
event_type|enum|plan, approval, edit, tool_call, checkpoint, gate, review, waiver, rework, submission, or followup.
started_at_utc|datetime|Event start timestamp.
ended_at_utc|datetime|Event end timestamp.
parent_event_id|id|Causal/workflow parent event if known; not inferred causation.
parent_commit|git_id|Pre-event immutable state.
head_commit|git_id|Post-event immutable state.
diff_reference|reference|Ordered patch artifact.
diff_sha256|sha256|Hash of patch bytes.
checkpoint_reference|reference|Restorable local checkpoint and scope.
model_provider|text|Actual provider when an agent is involved.
model_id|text|Actual model identifier; unavailable details explicitly marked in manifest.
model_version|text|Provider-reported immutable version when available.
model_settings_reference|reference|Sampling, context, and runtime settings.
model_settings_sha256|sha256|Hash of settings artifact.
agent_configuration_reference|reference|Agent identity, autonomy scope, and configuration.
agent_configuration_sha256|sha256|Hash of configuration artifact.
prompt_reference|reference|Access-controlled exact prompt or redacted prompt artifact.
prompt_sha256|sha256|Digest of stored prompt artifact; redaction status required.
retrieved_context_reference|reference|Retrieved files, instructions, and external context manifest.
retrieved_context_sha256|sha256|Digest of context manifest.
tool_name|text|Invoked tool name if applicable.
tool_version|text|Frozen tool version.
tool_configuration_sha256|sha256|Hash of tool configuration.
policy_sha256|sha256|Hash of effective capability/review policy.
tool_input_reference|reference|Safely stored/redacted tool input.
tool_output_reference|reference|Safely stored/redacted tool output.
redaction_status|enum|none, redacted, restricted, or unavailable.
approval_id|id|Explicit approval record; a plan alone is not approval.
approver_id|id|Pseudonymous accountable approving actor.
approval_disposition|enum|approved, rejected, revised, overridden, or not_applicable.
gate_record_reference|reference|Linked scan attempt and verdict.
review_disposition|enum|pending, corrected, accepted_waiver, escaped_final_review, or not_applicable.
retry_of_event_id|id|Previous failed/corrected attempt linked to this retry.
evidence_reference|reference|Supporting immutable event artifacts.
evidence_sha256|sha256|Hash of evidence manifest.
missingness_reference|reference|Explicit recording gaps and their implications.
""",
"defect_adjudication.csv": """
candidate_id|id|Candidate or sampled negative detection unit; not necessarily a defect.
schema_version|text|Schema version.
study_id|enum|engineering_feasibility, A, or B.
task_session_id|id|Human session if present.
change_id|id|Change under adjudication.
root_cause_id|id|Shared defect root cause; final counts deduplicate this ID.
episode_id|id|Distinct introduction/fix/reintroduction episode.
linked_prior_episode_id|id|Previous episode for a reintroduced defect.
detection_unit_id|id|Frozen unit for TP/FP/FN/TN assessment.
detection_universe_reference|reference|Universe/sampling frame and unit definition including negatives.
assessment_checkpoint|enum|canonical_parent, pre_review, final_submission, D30, or D90.
snapshot_commit|git_id|Exact state evaluated.
requirement_or_invariant_id|id|Preregistered requirement, security property, architectural invariant, or maintainability policy.
category|enum|functional, security, architecture, or maintainability.
secondary_categories|list|Other applicable categories; do not count root cause twice.
severity|enum|blocker, major, or minor under frozen consequence rubric; orthogonal to category.
severity_rubric_reference|reference|Task-specific severity and consequence rules.
reproducible_evidence_reference|reference|Reproducer, oracle, validated property violation, or corroborated expert evidence.
evidence_sha256|sha256|Hash of evidence packet.
analyzer_alert_present|boolean|Whether frozen analyzer emitted an alert for this unit.
analyzer_finding_ids|list|Associated alert identifiers.
oracle_version_sha256|sha256|Frozen independent oracle/harness manifest digest if available.
blinded_packet_reference|reference|Evidence stripped of condition and actor identity where feasible.
blinding_limitation|text|Residual condition/identity clues disclosed before interpretation.
rater_1_id|id|First independent adjudicator.
rater_1_is_defect|boolean|Independent initial judgment; empty if not completed.
rater_1_category|enum|functional, security, architecture, or maintainability when judged positive.
rater_1_severity|enum|blocker, major, or minor when judged positive.
rater_1_rationale_reference|reference|First independent justification.
rater_2_id|id|Second independent adjudicator.
rater_2_is_defect|boolean|Independent initial judgment before discussion.
rater_2_category|enum|functional, security, architecture, or maintainability when judged positive.
rater_2_severity|enum|blocker, major, or minor when judged positive.
rater_2_rationale_reference|reference|Second independent justification.
pre_consensus_agreement|boolean|Whether initial binary judgments agree; calculate before discussion.
third_adjudicator_id|id|Independent third adjudicator for unresolved disagreement.
consensus_is_defect|boolean|Final resolved judgment; blank if unresolved.
consensus_category|enum|functional, security, architecture, or maintainability when confirmed.
consensus_severity|enum|blocker, major, or minor when confirmed.
resolution_reference|reference|Discussion, unresolved disagreement, and third-adjudicator reasoning.
finding_classification|enum|TP, FP, FN, TN, unassessed, or not_applicable for defined analyzer unit.
first_observed_introduction|enum|agent, human, preexisting, or unresolved; operational provenance, not causal blame.
first_introduction_event_id|id|Earliest supported event introducing the violation.
attribution_evidence_reference|reference|Retrospective snapshot/oracle evidence or ambiguity explanation.
review_disposition|enum|detected_corrected, detected_accepted_waiver, escaped_final_review, or not_applicable.
survives_final_submission|boolean|Whether defect remains at final accepted state.
primary_count_eligible|boolean|Meets frozen primary confirmed-defect criteria; maintainability alerts alone are ineligible.
waiver_id|id|Linked accepted exception where applicable.
discovered_at_utc|datetime|Actual discovery timestamp; future D30/D90 observations stay empty.
followup_window|enum|immediate, D30, D90, or outside_window.
observation_complete|boolean|Whether the planned observation window and challenges were completed.
missingness_reference|reference|Unknown attribution, missing oracle, absent raters, or incomplete followup.
""",
"governance_costs.csv": """
cost_record_id|id|Unique cost/activity record.
schema_version|text|Schema version.
study_id|enum|engineering_feasibility, A, or B.
run_id|id|Run identifier.
task_session_id|id|Human session if present.
change_id|id|Change identifier if attributable.
record_type|enum|human_interval, model_usage, infrastructure_usage, or allocated_setup.
actor_id|id|Pseudonymous human/service identity.
role|text|Originator, reviewer, security expert, administrator, or service role.
activity|enum|task, review, triage, rework, waiver, administration, setup, maintenance, agent_retry, or infrastructure.
started_at_utc|datetime|Actual active interval start or billed usage period.
ended_at_utc|datetime|Actual active interval end or billed usage period.
active_seconds|seconds|Human active work only; unworked waiting is excluded.
overlap_group_id|id|Audit key used to reject duplicate/overlapping intervals for the same person.
human_wait_seconds|seconds|Elapsed inactive wait, recorded separately and excluded from labor totals.
usage_quantity|number|Actual billed tokens, requests, instance-seconds, or other declared units.
usage_unit|text|Explicit unit for usage_quantity.
rate|currency_per_unit|Preregistered or actual disclosed rate in stated unit.
rate_unit|text|Unit underlying rate; e.g., currency per hour or per token.
currency|text|Currency code; use a frozen conversion policy if combined.
direct_cost|currency|Quantity times correctly normalized rate, before allocation.
allocation_fraction|number|Share from 0 to 1 assigned to this task; shares must not exceed 1.
allocated_cost|currency|Direct cost times allocation fraction.
setup_or_recurring|enum|setup or recurring; report separately before amortization.
amortization_horizon_reference|reference|Preregistered tasks/time horizon and allocation assumptions.
allocation_rule_reference|reference|Non-overlapping cost-allocation rule and excluded research instrumentation.
rate_policy_reference|reference|Frozen role rates and sensitivity ranges.
retry_event_id|id|Agent retry link; model/compute and human rework remain separate records.
waiver_id|id|Waiver link for processing cost.
source_evidence_reference|reference|Timer, invoice, token log, CI ledger, or allocation evidence.
source_evidence_sha256|sha256|Hash of evidence artifact.
cost_quality|enum|observed, externally_priced, allocated, estimated, or unavailable.
missingness_reference|reference|Absent measurements; never replace with fabricated labor estimates.
""",
"task_sessions.csv": """
task_session_id|id|One planned participant-task slot; retries remain in provenance events.
schema_version|text|Schema version.
study_id|enum|A or B; engineering scans do not create fictitious participant sessions.
phase|enum|pilot or confirmatory.
cohort_id|id|Disjoint participant cohort identifier.
participant_id|id|Pseudonymous participant identifier.
prior_benchmark_exposure|boolean|Screening result; prior pilot/benchmark exposure excludes confirmatory enrollment under the frozen rule.
screening_reference|reference|Consent/eligibility and prior-exposure assessment, access controlled.
experience_years|years|Continuous professional experience; no causal identification from this proxy.
experience_stratum|enum|lt3, ge3_lt7, or ge7 if these bins are retained for allocation/descriptives.
stack_proficiency_score|number|Frozen pre-assignment instrument score.
proficiency_instrument_reference|reference|Instrument definition, scaling, and administration rules.
baseline_familiarity_score|number|Pre-task codebase/architecture familiarity assessment; not assumed persistent zero.
familiarity_instrument_reference|reference|Frozen familiarity measure.
randomization_unit|enum|participant.
allocation_id|id|Recorded randomization allocation.
allocation_manifest_reference|reference|Concealed randomization procedure, strata, seed/custodian, and timestamp.
assigned_condition|enum|manual, sandboxed_agent_baseline, or CAI; Study A manual/baseline, Study B baseline/CAI.
received_condition|enum|Actual exposure for compliance reporting; primary analysis retains assigned condition.
task_id|id|T1, T2, or T3 with a frozen task specification.
task_order|enum|T1_T2_T3, T1_T3_T2, T2_T1_T3, T2_T3_T1, T3_T1_T2, or T3_T2_T1.
task_period|integer|1, 2, or 3, distinct from task identity.
cumulative_prior_task_exposure|integer|Completed earlier task periods, despite canonical state reset.
task_specification_sha256|sha256|Hash of task requirements and evaluation scope.
canonical_snapshot_commit|git_id|Independent task-specific initial state containing its prerequisites.
final_submission_commit|git_id|Final submitted state; may be unavailable for withdrawal.
agent_configuration_reference|reference|Frozen agent/provider/tool/policy manifest for agent conditions.
started_at_utc|datetime|Session/task start timestamp.
submitted_at_utc|datetime|Final submission or cutoff timestamp.
first_verified_success_at_utc|datetime|First independently verified successful endpoint. Empty if no success before the session cap.
verified_success|boolean|Whether the frozen success criteria were met before the session cap. This is the completion-probability outcome for H4.
time_to_success_or_censor_seconds|seconds|Elapsed time from task release to first verified success, or to the fixed session cap if unsuccessful. Includes waiting.
success_time_censored|boolean|True if no verified success by the cap. A completed-task-only time analysis is secondary.
session_cap_seconds|seconds|Preregistered session cap, 5400 in the proposed protocol. Freeze before collection.
session_status|enum|completed, incomplete, noncompiling, withdrawn, or telemetry_incomplete.
protocol_deviation_reference|reference|Actual deviations and prespecified handling; no post hoc exclusion by outcome.
active_developer_seconds|seconds|Originator active work from deduplicated human intervals.
total_engineering_seconds|seconds|All role-specific active intervals summed once; rework is already included.
elapsed_seconds|seconds|Total elapsed session duration including waits. Distinct from labor and from time to first verified success.
total_allocated_monetary_cost|currency|Human, model, infrastructure, and allocated governance cost under frozen rules.
currency|text|Currency code and frozen conversion rule.
cost_records_reference|reference|Supporting governance_costs rows and allocation manifest.
parent_tdr|number|Tool-specific technical debt ratio at canonical parent, with declared scaling.
final_tdr|number|Same frozen tool/denominator at final state; proxy, not long-term maintenance cost.
tdr_definition_reference|reference|Analyzer version, remediation rule set, denominator, units, and coverage.
parent_complexity|number|Declared structural complexity measure at parent.
final_complexity|number|Same measure at final state.
eligible_methods|integer|Number of methods eligible under frozen structural analysis scope.
parent_duplication_density|number|Declared tool-specific duplicated-line/token density at parent.
final_duplication_density|number|Same density and scope at final state.
changed_nongenerated_production_loc|integer|Added plus deleted production lines excluding generated code under frozen diff rule.
changed_production_files|integer|Changed production source files under frozen scope.
task_structural_opportunities_reference|reference|Prespecified task opportunities and baseline scope; not inferred from treatment outcomes.
pre_review_surviving_defects|integer|Unique confirmed eligible root causes at pre-review checkpoint, if observed.
final_surviving_defects|integer|Unique confirmed eligible root causes surviving final workflow, primary workflow outcome.
adjudication_reference|reference|Independent blinded assessment and disagreement records.
nasa_tlx_global|number|Frozen scoring choice and scale; do not confuse workload with product quality.
workload_instrument_reference|reference|Questionnaire version, permitted instrument, scoring, and timing.
hidden_oracle_reference|reference|Independent frozen behavioral checks unavailable to agents during task iterations.
exploratory_mutation_score|number|Optional scoped exploratory score, with equivalent-mutant/time-budget rules.
followup_D30_status|enum|not_started, pending, completed, incomplete, or not_planned; prospective only until observed.
followup_D90_status|enum|not_started, pending, completed, incomplete, or not_planned; prospective only until observed.
missingness_reference|reference|Preregistered missingness and noncompilation handling with actual reasons.
""",
}

def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    dictionary = [
        "# Prospective protocol data dictionary\n",
        "These are empty templates for planned collection. They contain no participants, observations, ratings, costs, or follow-up results. Actual engineering-run outputs, when available, are separate artifacts with their own executable schema.\n",
        "## Shared conventions\n",
        "UTF-8 CSV uses one header row and no example rows. `id` values are stable pseudonymous identifiers; `reference` is a controlled artifact path/URI with an immutable manifest. `git_id` is a full commit identifier; `sha256` is 64 lowercase hexadecimal characters. `datetime` is RFC 3339 UTC. Booleans are `true` or `false`; numbers use a decimal point, no thousands separators. Lists use JSON arrays inside quoted CSV cells. Empty cells mean unavailable/not collected and require a reason when collection was planned. They never imply zero, a passed scan, an absent defect, or completed follow-up. Units and score scales must be frozen before observation.\n",
        "A gate row is one actual/planned gate scan attempt, including failed or skipped attempts. A provenance row is one ordered event. An adjudication row is one candidate or sampled negative detection unit/episode. A cost row is one non-overlapping activity or allocated usage record. A session row is one planned participant-task slot. Aggregation must preserve these units and avoid double counting.\n",
    ]
    for filename, source in SCHEMAS.items():
        fields = [line.split("|", 2) for line in source.strip().splitlines()]
        with (ROOT / filename).open("w", newline="", encoding="utf-8") as stream:
            csv.writer(stream).writerow([f[0] for f in fields])
        dictionary.extend([f"\n## {filename}\n", "| Field | Type | Definition |\n|---|---|---|\n"])
        dictionary.extend(f"| `{name}` | {kind} | {description} |\n" for name, kind, description in fields)
    (ROOT / "data_dictionary.md").write_text("".join(dictionary), encoding="utf-8")
    print({name: len(source.strip().splitlines()) for name, source in SCHEMAS.items()})

if __name__ == "__main__":
    main()
