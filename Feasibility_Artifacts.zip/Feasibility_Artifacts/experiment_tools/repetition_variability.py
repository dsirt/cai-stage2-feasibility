#!/usr/bin/env python3
"""Descriptive within-change variation over three technical repetitions."""
from pathlib import Path
import argparse,csv,json,statistics,collections
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
rows=list(csv.DictReader((a.run/'gate_runs.csv').open()));groups=collections.defaultdict(list);reps=collections.defaultdict(list)
for r in rows:
 if r['scan_role']!='head' or r['resource_measurement']=='not_executed':continue
 groups[(r['concurrency'],r['change_id'],r['gate_id'])].append(r)
 reps[(r['concurrency'],r['change_id'],r['repetition'])].append(r)
out=[]
def add(c,cid,gate,values,analyzable):
 mean=statistics.mean(values);sd=statistics.stdev(values) if len(values)>1 else None
 out.append({'concurrency':int(c),'change_id':cid,'gate_id':gate,'executed_repetitions':len(values),'fully_analyzable_repetitions':analyzable,'wall_seconds_median':statistics.median(values),'wall_seconds_min':min(values),'wall_seconds_max':max(values),'wall_seconds_sample_sd':sd,'wall_seconds_cv_percent':100*sd/mean if sd is not None and mean else None})
for (c,cid,g),rs in sorted(groups.items()):add(c,cid,g,[float(r['wall_seconds']) for r in rs],sum(r['measurement_status']=='ok' for r in rs))
pipe=collections.defaultdict(list)
for (c,cid,rep),rs in reps.items():pipe[(c,cid)].append((sum(float(r['wall_seconds']) for r in rs),all(r['measurement_status']=='ok' for r in rs)))
for (c,cid),values in sorted(pipe.items()):add(c,cid,'sum_of_six_gate_wall_times',[v for v,ok in values],sum(ok for v,ok in values))
a.output.mkdir(parents=True,exist_ok=True)
with (a.output/'repetition_variability.csv').open('w',newline='') as stream:
 w=csv.DictWriter(stream,list(out[0]));w.writeheader();w.writerows(out)
s={'definition':'Within-change sample SD and CV over technical repetitions. Executed failed attempts remain in timing summaries. No inferential intervals. Parent scans have one repetition and are excluded.','groups':len(out),'pipeline_cv_median_percent':{c:statistics.median(r['wall_seconds_cv_percent'] for r in out if r['gate_id']=='sum_of_six_gate_wall_times' and r['concurrency']==c) for c in [1,2,4]}}
(a.output/'repetition_variability.json').write_text(json.dumps(s,indent=2));print(json.dumps(s))
