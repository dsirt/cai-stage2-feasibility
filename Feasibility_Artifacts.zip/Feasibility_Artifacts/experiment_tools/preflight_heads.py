#!/usr/bin/env python3
"""Verify each frozen head and preserve actual compile/public-test outcomes outside timed scans."""
from pathlib import Path
import subprocess,json,argparse,concurrent.futures,os,datetime
p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--dotnet',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--workers',type=int,default=2);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
plan=json.loads(a.plan.read_text());env=dict(os.environ,DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',MSBUILDDISABLENODEREUSE='1');dotnet=str(a.dotnet.resolve())
def one(row):
 w=Path(row['path']);rid=row['run_id'];d=a.out/rid;d.mkdir(exist_ok=True)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
 if head==row['base_commit']:return {'run_id':rid,'status':'not_submitted'}
 expected_head=row.get('head_commit',head)
 cache=d/'result.json'
 if cache.exists():
  saved=json.loads(cache.read_text())
  if saved.get('head_commit')==head:return saved
 if head!=expected_head:return {'run_id':rid,'status':'head_mismatch'}
 cmds=[('restore',[dotnet,'restore','Benchmark.sln','--configfile','NuGet.Config','--disable-parallel','-m:1','-nr:false']),('build',[dotnet,'build','Benchmark.sln','--no-restore','--no-incremental','--disable-build-servers','-m:1','-nr:false','-p:UseSharedCompilation=false']),('tests',[dotnet,'run','--project','src/Tests/Benchmark.Tests.csproj','--no-build'])]
 result={'run_id':rid,'head_commit':head,'commands':[],'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for kind,cmd in cmds:
  with (d/f'{kind}.stdout.log').open('w') as out,(d/f'{kind}.stderr.log').open('w') as err:
   try:r=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=err,timeout=180);code=r.returncode;status='completed'
   except subprocess.TimeoutExpired:code=None;status='timeout'
  result['commands'].append({'kind':kind,'argv':cmd,'exit_code':code,'status':status})
  if kind=='tests':
   lines=(d/f'{kind}.stdout.log').read_text().splitlines()
   for line in reversed(lines):
    try:obj=json.loads(line)
    except json.JSONDecodeError:continue
    if isinstance(obj,dict) and 'total' in obj:
     result['public_tests']={k:obj[k] for k in ['total','passed','failed']};break
  if code!=0:
   result['status']=kind+'_failed' if code is not None else kind+'_timeout';break
 else:result['status']='build_and_public_tests_passed'
 result['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(d/'result.json').write_text(json.dumps(result,indent=2));return result
with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as ex:rows=list(ex.map(one,plan['runs']))
(a.out/'summary.json').write_text(json.dumps({'scope':'public regression tests, not a hidden task-acceptance score','results':rows},indent=2));print(json.dumps({'count':len(rows),'statuses':{s:sum(r['status']==s for r in rows) for s in sorted(set(r['status'] for r in rows))}}))
