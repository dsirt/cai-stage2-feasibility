#!/usr/bin/env python3
"""Freeze real gate invocations and binary/source hashes once tool builds are complete."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work-root", type=Path, default=Path(__file__).resolve().parent.parent)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    root = a.work_root.resolve()
    dotnet = root / "dotnet" / "dotnet"
    analyzer = root / "gate_analyzer" / "bin" / "Release" / "net8.0" / "GateTool.dll"
    sast = root / "experiment_tools" / "sast_gate.py"
    for path in [dotnet, analyzer, sast]:
        if not path.is_file():
            raise SystemExit(f"Required built tool unavailable: {path}")
    binary_manifest = {path.name: digest(path) for path in sorted(analyzer.parent.glob("*.dll"))}
    gates = []
    for name in ["complexity", "duplication", "architecture", "dependencies", "size"]:
        gates.append({"id": name, "kind": "analysis",
                      "command": [str(dotnet), str(analyzer), "--gate", name, "--base", "{parent_path}",
                                  "--head", "{workspace}", "--output", "{result_json}"],
                      "timeout_seconds": 120, "success_exit_codes": [0], "finding_exit_codes": [1],
                      "require_result_json": True, "version": "Frozen report-only GateTool; see version output and binary manifest",
                      "version_command": [str(dotnet), str(analyzer), "--version"],
                      "binary_sha256": digest(analyzer), "dependency_assembly_sha256": binary_manifest})
    gates.insert(3, {"id": "security", "kind": "analysis",
                     "command": [sys.executable, str(sast), "--dotnet", str(dotnet), "--workspace", "{workspace}",
                                 "--output", "{result_json}"],
                     "timeout_seconds": 180, "success_exit_codes": [0], "finding_exit_codes": [1],
                     "require_result_json": True,
                     "version": "Microsoft SDK NetAnalyzers Security=All, wrapper source SHA-256 recorded",
                     "version_command": [str(dotnet), "--version"], "wrapper_sha256": digest(sast)})
    config = {"schema_version": "1.0", "enforcement_mode": "report_only",
              "environment": {"DOTNET_ROOT": str(root / "dotnet"), "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
                              "DOTNET_CLI_USE_MSBUILD_SERVER": "0", "MSBUILDDISABLENODEREUSE": "1"},
              "preparation": "Dependencies restored and source/tool versions frozen before timing; no OS cache flush.",
              "gates": gates}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(config, indent=2) + "\n")
    print(json.dumps({"configuration": str(a.output), "sha256": digest(a.output), "gates": len(gates)}))


if __name__ == "__main__":
    main()
