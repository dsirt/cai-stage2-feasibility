# Prospective human-study protocol and collection templates

These files specify planned data collection for the manuscript **From Cognitive Augmentation to Cognitive Delegation: A Governance Framework and Evaluation Protocol for Autonomous AI Coding Agents in Enterprise Software Engineering**. They are early machine-readable templates supporting protocol preparation and preregistration. They do not constitute a registration, ethics approval, completed participant study, hidden evaluation harness, or executable statistical analysis. No empirical rows are supplied. Any separately executed engineering-feasibility experiment must be described using its actual repository, tools, runs, and evidence; it does not supply missing human ratings, labor costs, trial outcomes, or longitudinal follow-up.

## Study design to freeze before enrollment

Study A randomizes participants between manual development and a sandboxed agent baseline. Study B recruits an independent, disjoint sample and randomizes between the same sandboxed agent baseline and the proposed CAI condition. The baseline retains essential isolation and capability controls; it is not an unrestricted execution environment. Prior participation in either study, a benchmark pilot, or benchmark-task exposure excludes confirmatory enrollment under a prespecified screening rule. Pilot data are not pooled with confirmatory outcomes.

The allocation unit is the participant, stratified by experience. Each participant remains in one assigned condition for all three tasks. Record continuous experience years and a prespecified stack-proficiency assessment; if experience bins are used, their boundaries are `<3`, `3 to <7`, and `>=7` years. These bins support allocation and description, not claims that years alone measure architectural expertise.

Each task starts from an independent canonical snapshot containing that task's prerequisites. Counterbalance all six task orders: T1–T2–T3, T1–T3–T2, T2–T1–T3, T2–T3–T1, T3–T1–T2, and T3–T2–T1. Preserve task identity and period separately. Repository reset does not erase participant learning; record baseline familiarity and cumulative prior-task exposure. No crossover variant is silently pooled with this participant-level design.

## Estimands and analysis commitments

The primary comparison estimates total effects of randomized assignment, with repeated tasks clustered by participant and task/period effects specified before data collection. Baseline experience, proficiency, and baseline structural measures may be prespecified adjustments. Changed LOC/files can be affected by treatment; therefore primary treatment effects are **not conditioned on changed LOC**. Prespecified size-conditioned sensitivities use changed non-generated production LOC, files, baseline metrics, eligible methods, and task structural opportunities, and are explicitly interpreted as different estimands. No mandatory defect-count LOC offset is assumed.

Separate product outcomes (functional/security/architecture defects and tool-specific structural proxies) from process outcomes (active developer time, total engineering effort, end-to-end elapsed latency, workload, and monetary cost). Maintainability alerts, complexity, duplication, and technical debt ratio are not interchangeable with confirmed defects or measured long-term maintenance burden. A named analyzer, rule set, denominator, and units must be fixed before TDR is an analyzable endpoint; a missing TDR implementation cannot be replaced post hoc with an invented score.

Study B's H4 requires the prespecified TDR superiority criterion, a functional-completion non-inferiority safeguard, and acceptable overhead on **all three** resource dimensions: active developer time, total engineering time, and total monetary cost. Compare CAI with the concurrent agent baseline. Define the acceptable loss as delta_completion >= 0. Require the lower confidence bound for p_CAI minus p_baseline to be greater than -delta_completion. Incomplete or non-compiling work cannot qualify as an efficiency improvement merely because it uses less effort. The upper confidence bounds for each CAI/baseline resource ratio must lie within its preregistered organizational budget. The quality criterion, completion margin, budgets, confidence construction, multiplicity handling, and stakeholder/economic rationale must be fixed before outcomes are observed. No numeric margin is supplied as empirically established. Study B has no manual arm and cannot estimate a fraction of retained manual-to-agent benefit. Cross-study manual outcomes are not an interchangeable randomized comparator.

For H1 and H3c, the primary time endpoint is elapsed time from task release to independently verified success, including agent and CI waiting. Unfinished or non-compiling submissions remain in their assigned groups and are right-censored at the 90-minute session cap. Active developer effort is a separate endpoint. The completed-task-only time analysis is secondary. Record time to verified success and censoring separately from total session duration. H1 and H2 use marginal condition contrasts over the baseline covariate distribution with equal task weights, with experience and proficiency centered under a fixed rule. H3 interactions are interpreted on the stated model scale. The confirmatory Study A family contains five tests, H1, H2, and H3a to H3c, with Holm adjustment. Missing structural measurements are never coded as zero debt.

The preregistration still needs the actual sampling frame, power/sample-size calculation, primary outcome family, models, transformation/diagnostic fallback rules, stopping rule, missingness and noncompilation rules, quality margin, overhead budgets, questionnaire permissions/scoring, and independent-oracle availability. The templates record these decisions but do not imply they have been finalized.

## Gate feasibility and measurement

Use `report_only_gate_records.csv` for one planned/actual gate scan attempt, distinguishing comparable parent and head states. Freeze source/diff, analyzer binaries, rule packs, policies, runtime, dependency locks, and resource-accounting scope. Record queues, wall and CPU time, concurrency, cache preparation, failures, and logs. A failed or unavailable analysis cannot become a passing gate. Record accepted preexisting parent violations separately from new/worsened head violations; parent acceptance is a policy disposition, not an assertion of defect-free code.

TP/FP/FN/TN require a prespecified detection unit and assessed universe. Checking only emitted alerts can estimate precision within sampled alerts, but cannot establish false-negative rates, sensitivity, or true-negative counts. No-alert records are not automatically TN. Report all denominators, selection rules, and unassessed units. Existing engineering instrumentation may emit a different but documented operational schema; map it explicitly before combining records.

## Defects, attribution, and adjudication

A confirmed defect is a reproducible deviation from a frozen requirement, security property, or architectural invariant. Require an independent failing behavioral oracle for functional defects, validated property/exploit evidence or corroborated expert evidence for security defects, and a named dependency/contract invariant for architecture defects. A scanner warning or structural metric increase alone is not a confirmed defect. Maintainability policy violations are recorded separately and do not automatically enter the primary defect count.

Category (`functional`, `security`, `architecture`, `maintainability`) and severity (`blocker`, `major`, `minor`) are orthogonal. Freeze a task-specific consequence rubric. For orientation only, blocker prevents required operation or violates a non-negotiable security property; major materially violates required behavior with a possible workaround; minor has limited consequence under defined use. Actual classification depends on the frozen rubric and reproducible evidence, not these short labels alone.

Two independent adjudicators assess condition-stripped evidence packets. Preserve their initial judgments, report agreement and prevalence before discussion, and use an independent third adjudicator for unresolved disagreement. Keep unresolved cases and blinding limitations visible. No automated or single-author judgment may be described as completed independent human adjudication.

Preserve canonical baseline, every agent patch, every human edit, and pre-/post-review states. Retrospective frozen oracles may identify the **first observed introduction** as `agent`, `human`, `preexisting`, or `unresolved`. This operational provenance is not causal blame. Interleaving, missing artifacts, and interaction effects can remain unresolved. Review survival is separate: a human reviewer missing an agent-introduced defect is an escape, not a new human introduction. Link fixes/reintroductions as episodes and count each eligible final root cause once. The primary defect endpoint is surviving workflow-level defects, not the exploratory actor-attribution breakdown.

## Human effort and cost

Record non-overlapping active intervals per human and role for task work, review, triage, rework, waiver handling, setup, administration, and maintenance. Total engineering time sums these intervals once. Rework is an activity tag already included in that total; do not add it again. Concurrent work by different people contributes both labor intervals, while duplicate intervals for the same person are deduplicated. Inactive waits are elapsed latency, not labor.

Price human intervals under frozen role rates and sensitivity ranges. Record model tokens/requests and retries separately from allocated infrastructure usage. Separate setup from recurring cost and disclose amortization horizon and allocation fractions; allocations may not exceed the underlying cost. Preserve agent retry links without counting the same compute or rework twice. Shared research instrumentation, unrelated project work, and governance overhead need an explicit allocation/exclusion policy. Runtime measurements do not reveal human triage, review, waiver, or administrative effort.

## Follow-up and artifact availability

Immediate assessment may include bounded hidden behavioral, adversarial/boundary, concurrency/load, and dependency/security challenges, subject to frozen budgets. Hidden-oracle feedback must remain unavailable to the agent during task iterations. Optional mutation analysis is exploratory and requires a declared scope, time budget, and treatment of equivalent mutants. No negative scan establishes absence of latent defects.

D30 and D90 are **prospective** follow-up windows, with planned maintenance/change tasks and defect/incident observation where feasible. They are not executed observations in these templates. Freeze window anchors, acceptable timing tolerances, exposure duration, retention procedures, and missing-follow-up handling. Until an observation actually occurs, leave corresponding outcome cells empty. Report `not detected within the observed window`, never `defect-free` on the basis of an incomplete window.

Included: this specification, the complete field dictionary, and five header-only CSVs. Not supplied by this directory: participant observations, independently adjudicated defects, human cost measurements, completed D30/D90 follow-ups, a hidden participant-evaluation harness, a registration identifier, or an executable confirmatory analysis. The presence and scope of separately supplied benchmark or engineering-run artifacts must be assessed from their own manifests and logs.

## Files

| File | Row unit |
|---|---|
| `report_only_gate_records.csv` | One gate scan attempt; includes failed/skipped attempts. |
| `provenance_events.csv` | One ordered actor/tool/change event. |
| `defect_adjudication.csv` | One candidate or sampled negative detection unit/episode. |
| `governance_costs.csv` | One non-overlapping human interval or allocated usage record. |
| `task_sessions.csv` | One planned participant-task slot. |
| `data_dictionary.md` | All field names, types, definitions, and shared missingness rules. |
