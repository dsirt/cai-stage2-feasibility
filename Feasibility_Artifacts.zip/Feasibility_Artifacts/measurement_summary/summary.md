# Descriptive engineering-feasibility measurements
The recorded run contains 24 head changes and 1314 planned gate attempts. Measurement statuses: {"ok": 1314}. These are tool-execution and policy-alert observations, not independent defect adjudication, human-study outcomes, or longitudinal validation.
## Pipeline timing
The job unit contains all repeated scans of one workspace. Queue/pipeline medians therefore describe that repeated workload; they are not single-PR developer latency. Repetition wall sums exclude inter-gate runner overhead. Throughput denominators include scheduled parent-baseline scans.
| Concurrency | Head repetitions | Analyzable repetitions | Scenario wall (s) | Repetitions/s | Median job queue (s) | Median repetition gate-wall sum (s) | p95 repetition gate-wall sum (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 72 | 72 | 1002.874 | 0.072 | 495.254 | 13.692 | 14.592 |
| 2 | 72 | 72 | 564.292 | 0.128 | 261.569 | 15.153 | 16.322 |
| 4 | 72 | 72 | 417.439 | 0.172 | 185.036 | 21.752 | 28.997 |

## Per-gate timing for head scans
Executed-attempt timing includes timed-out and failed processes when measured. Skipped prerequisites are excluded from execution timing; analyzable-only alternatives are supplied in the CSV.
| Concurrency | Gate | Executed / planned | Analyzable | Finding verdicts | Median wall (s) | p95 wall (s) | Median CPU (s) | Median wait4 maxRSS (KiB) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | architecture | 72 / 72 | 72 | 0 | 0.487 | 0.548 | 0.454 | 107482.000 |
| 1 | complexity | 72 / 72 | 72 | 72 | 0.294 | 0.336 | 0.255 | 86380.000 |
| 1 | dependencies | 72 / 72 | 72 | 0 | 0.102 | 0.133 | 0.084 | 45344.000 |
| 1 | duplication | 72 / 72 | 72 | 0 | 0.243 | 0.270 | 0.216 | 76576.000 |
| 1 | security | 72 / 72 | 72 | 0 | 12.406 | 13.277 | 29.677 | 575620.000 |
| 1 | size | 72 / 72 | 72 | 57 | 0.152 | 0.184 | 0.125 | 48048.000 |
| 2 | architecture | 72 / 72 | 72 | 0 | 0.568 | 1.000 | 0.523 | 107310.000 |
| 2 | complexity | 72 / 72 | 72 | 72 | 0.324 | 0.370 | 0.274 | 86264.000 |
| 2 | dependencies | 72 / 72 | 72 | 0 | 0.112 | 0.152 | 0.090 | 45384.000 |
| 2 | duplication | 72 / 72 | 72 | 0 | 0.267 | 0.457 | 0.238 | 76586.000 |
| 2 | security | 72 / 72 | 72 | 0 | 13.637 | 14.683 | 30.120 | 572786.000 |
| 2 | size | 72 / 72 | 72 | 57 | 0.162 | 0.230 | 0.129 | 48010.000 |
| 4 | architecture | 72 / 72 | 72 | 0 | 0.561 | 0.763 | 0.525 | 107316.000 |
| 4 | complexity | 72 / 72 | 72 | 72 | 0.344 | 0.652 | 0.291 | 86324.000 |
| 4 | dependencies | 72 / 72 | 72 | 0 | 0.122 | 0.189 | 0.093 | 45324.000 |
| 4 | duplication | 72 / 72 | 72 | 0 | 0.282 | 0.377 | 0.247 | 76704.000 |
| 4 | security | 72 / 72 | 72 | 0 | 20.267 | 27.123 | 33.599 | 568068.000 |
| 4 | size | 72 / 72 | 72 | 57 | 0.174 | 0.364 | 0.138 | 48032.000 |

## Interpretation limits
Repetitions are repeated observations of the same constructed changes, not independent developer samples. p95 uses linear interpolation (type 7) and is descriptive; no inferential confidence intervals or significance tests are produced. Concurrency scenarios run in the recorded sequence on one host without OS cache flushing, so workload, cache/order effects, CPU limits, and shared-host contention bound any scaling interpretation. wait4 CPU and RSS have the process-accounting limits documented in the runner README; RSS is not an aggregate process-tree peak.
Paired alert counts link each head to the same-concurrency parent scan. Their arithmetic difference is not a count of newly introduced confirmed defects; rules, locations, and baseline acceptance still require inspection. No TP/FP/FN/TN labels, false-positive rates, sensitivity, human triage/review/waiver costs, or H1–H4 conclusions are inferred. Engineering evidence establishes only what these recorded commands actually measured.
