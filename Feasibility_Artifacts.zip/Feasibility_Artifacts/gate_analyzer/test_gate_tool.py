"""Deterministic positive/negative validation for the research gate implementation.

These fixtures validate selected implementation behaviors, not defect-detection
accuracy, security assurance, reviewer agreement or real-PR generalization.
"""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
DOTNET = HERE.parent / "dotnet/dotnet"
DLL = HERE / "bin/Release/net8.0/GateTool.dll"


def put(root, path, text):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def run_gate(root, gate, expected_status="ok"):
    output = root / f"{gate}.json"
    process = subprocess.run([str(DOTNET), str(DLL), "--gate", gate,
                              "--base", str(root / "base"), "--head", str(root / "head"),
                              "--output", str(output)], capture_output=True, text=True)
    result = json.loads(output.read_text())
    assert result["status"] == expected_status, (gate, result, process.stderr)
    assert process.returncode == (0 if expected_status == "ok" else 2)
    assert result["finding_count"] == len(result["findings"])
    return result


def check():
    checked = []
    with tempfile.TemporaryDirectory(prefix="cai-gates-") as temporary:
        root = Path(temporary)
        base, head = root / "base", root / "head"
        put(base, "src/Domain/Benchmark.Domain.csproj", '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>')
        put(base, "src/Infrastructure/Benchmark.Infrastructure.csproj", '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>')
        put(base, "src/Domain/A.cs", 'namespace Benchmark.Domain; public class A { public int Run(int x) { return x; } }\n')
        shutil.copytree(base, head)
        for gate in ("complexity", "duplication", "architecture", "dependencies", "size"):
            result = run_gate(root, gate)
            assert result["verdict"] == "pass", (gate, result)
        checked.append("unchanged simple baseline passes all five policies")

        put(head, "src/Domain/A.cs", '''namespace Benchmark.Domain;
public class A {
 public int Run(int x) {
  if (x > 0 && x < 10) x++;
  for (int i=0; i<3; i++) x++;
  int? y=null;
  x += y ?? 0;
  return x > 0 ? x : -x;
 }
}
''')
        result = run_gate(root, "complexity")
        assert result["metrics"]["head_max_callable_cc"] == 6, result
        assert any(f["type"] == "complexity_class_delta" for f in result["findings"])
        checked.append("six-path edited callable triggers relative class budget")

        put(head, "src/Domain/Added.cs", "namespace Benchmark.Domain; public class Added { public int Many(int x) {\n" + "\n".join(f"if(x=={i}) return {i};" for i in range(17)) + "\nreturn -1; } }\n")
        result = run_gate(root, "complexity")
        assert any(f["type"] == "complexity_method_ceiling" and f["evidence"]["method_cc"] == 18 for f in result["findings"])
        assert not any(f["type"] == "complexity_class_delta" and f["path"].endswith("Added.cs") for f in result["findings"])
        checked.append("new 18-path callable triggers absolute ceiling without undefined zero-baseline delta")

        put(head, "src/Domain/Nested.cs", 'namespace Benchmark.Domain; public class Nested { public int Outer(int x) { int Inner(int y) { if(y==0) return 1; if(y<0) return 2; return 3; } if(x>0) return Inner(x); return 0; } }\n')
        result = run_gate(root, "complexity")
        nested = next(c for c in result["metrics"]["class_details"] if c["type"] == "Benchmark.Domain.Nested")
        assert nested["head_cc"] == 5, nested
        checked.append("nested callable decisions are counted once independently")

        put(head, "src/Domain/PartialOne.cs", "namespace Benchmark.Domain; public partial class Split { public int First(int x) { if(x>0) return x; return 0; } }\n")
        put(head, "src/Domain/PartialTwo.cs", "namespace Benchmark.Domain; public partial class Split { public int Second(int x) { return x; } }\n")
        put(head, "src/Api/Program.cs", "int x=0; if(x==0) x++; int Inner(int y) { if(y>0) return y; return 0; }\n")
        result = run_gate(root, "complexity")
        split = [c for c in result["metrics"]["class_details"] if c["type"] == "Benchmark.Domain.Split"]
        assert len(split) == 1 and split[0]["head_cc"] == 3, split
        top = next(c for c in result["metrics"]["class_details"] if c["type"] == "<top-level:src/Api/Program.cs>")
        assert top["head_cc"] == 4, top
        checked.append("partial types aggregate while top-level and local-function paths stay separate")

        original_count = result["metrics"]["head_class_cc_sum"]
        put(head, "src/Tests/Repeated.cs", "public class Repeated { public void Test() {" + "if(true){}" * 30 + "} }\n")
        put(head, "src/Domain/obj/Generated.cs", "public class Generated { public void Test() {" + "if(true){}" * 30 + "} }\n")
        result = run_gate(root, "complexity")
        assert result["metrics"]["head_class_cc_sum"] == original_count
        checked.append("test and obj code excluded from production structural scope")

        body = "\n".join(f"x += {i};" for i in range(40))
        for name in ("CloneOne", "CloneTwo"):
            put(head, f"src/Domain/{name}.cs", f"namespace Benchmark.Domain; public class {name} {{ public int Work(int x) {{\n{body}\nreturn x;\n}} }}\n")
        result = run_gate(root, "duplication")
        assert result["verdict"] == "finding" and result["metrics"]["head_density_percent"] > 3
        assert any(f["path"].endswith("CloneOne.cs") for f in result["findings"])
        assert any(f["path"].endswith("CloneTwo.cs") for f in result["findings"])
        checked.append("exact repeated token spans yield bounded physical-line clone density")

        put(head, "src/Domain/Benchmark.Domain.csproj", '<Project Sdk="Microsoft.NET.Sdk"><ItemGroup><ProjectReference Include="../Infrastructure/Benchmark.Infrastructure.csproj"/><PackageReference Include="Example.Dependency" Version="1.2.3"/></ItemGroup></Project>')
        put(head, "src/Domain/Forbidden.cs", "using Benchmark.Infrastructure; namespace Benchmark.Domain; public class Forbidden {}\n")
        result = run_gate(root, "architecture")
        assert {f["type"] for f in result["findings"]} == {"forbidden_project_reference", "forbidden_namespace_reference"}
        checked.append("forbidden project edge and explicit namespace use both detected")
        result = run_gate(root, "dependencies")
        assert any(f["type"] == "package_reference_change" and f["evidence"]["change"] == "added" for f in result["findings"])
        assert all(f["severity"] == "review_required" for f in result["findings"])
        checked.append("package addition is a review trigger rather than a vulnerability finding")

        result = run_gate(root, "size")
        assert result["metrics"]["changed_files"] > 4
        assert any(f["path"] == "src/Tests/Repeated.cs" for f in result["metrics"]["files"])
        assert all("/obj/" not in f["path"] for f in result["metrics"]["files"])
        assert result["metrics"]["changed_lines"] == result["metrics"]["added_lines"] + result["metrics"]["deleted_lines"]
        checked.append("size includes source/test edits, excludes obj, counts additions plus removals")

        put(head, "src/Domain/Unparseable.cs", "public class Broken {\n")
        result = run_gate(root, "complexity", "not_evaluable")
        assert result["metrics"]["syntax_error_count"] > 0
        checked.append("syntax failure is not silently converted to a passing measurement")
    print(json.dumps({"status": "passed", "checks": checked, "count": len(checked)}, indent=2))


if __name__ == "__main__":
    check()
