using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

internal static class Program
{
    private const string Version = "CAI-Research-GateTool/1.0.0";
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly HashSet<string> IgnoredDirectories = new(StringComparer.OrdinalIgnoreCase) { "bin", "obj", ".git", ".vs", "node_modules" };

    public static int Main(string[] args)
    {
        if (args.Contains("--version")) { Console.WriteLine(Version); return 0; }
        var options = new Dictionary<string, string>(StringComparer.Ordinal);
        for (int i = 0; i < args.Length; i += 2)
        {
            if (!args[i].StartsWith("--") || i + 1 >= args.Length) { Console.Error.WriteLine("Expected --gate ID --base BASE_TREE --head HEAD_TREE --output PATH"); return 2; }
            options[args[i]] = args[i + 1];
        }
        string output = options.GetValueOrDefault("--output", "");
        try
        {
            string gate = Required(options, "--gate");
            string baseline = Path.GetFullPath(Required(options, "--base"));
            string head = Path.GetFullPath(Required(options, "--head"));
            if (!Directory.Exists(baseline) || !Directory.Exists(head)) throw new ArgumentException("Both snapshot directories must exist");
            Report report = gate switch
            {
                "complexity" => Complexity(baseline, head),
                "duplication" => Duplication(baseline, head),
                "architecture" => Architecture(baseline, head),
                "dependencies" => Dependencies(baseline, head),
                "size" => Size(baseline, head),
                _ => throw new ArgumentException($"Unsupported gate '{gate}'")
            };
            report.gate = gate;
            report.tool_version = Version;
            report.finding_count = report.findings.Count;
            report.finding_ids = report.findings.Select(f => f.id).ToList();
            if (report.status == "ok") report.verdict = report.findings.Count > 0 ? "finding" : "pass";
            WriteOutput(output, report);
            return report.status == "ok" ? 0 : 2;
        }
        catch (Exception exception)
        {
            WriteOutput(output, new { status = "analysis_error", verdict = "not_evaluable", finding_count = 0, finding_ids = Array.Empty<string>(), findings = Array.Empty<object>(), tool_version = Version, error = exception.Message });
            Console.Error.WriteLine(exception.Message);
            return 2;
        }
    }

    private static string Required(Dictionary<string,string> options, string key) => options.TryGetValue(key, out string? value) && value.Length > 0 ? value : throw new ArgumentException($"Missing {key}");
    private static void WriteOutput(string path, object value)
    {
        string text = JsonSerializer.Serialize(value, JsonOptions);
        if (path.Length == 0) Console.WriteLine(text);
        else { Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!); File.WriteAllText(path, text + Environment.NewLine); }
    }
    private static bool Included(string root, string path)
    {
        string relative = Path.GetRelativePath(root, path).Replace('\\', '/');
        string[] parts = relative.Split('/');
        if (parts.Any(IgnoredDirectories.Contains)) return false;
        string name = Path.GetFileName(path);
        return !name.EndsWith(".g.cs", StringComparison.OrdinalIgnoreCase) && !name.EndsWith(".generated.cs", StringComparison.OrdinalIgnoreCase) && !name.EndsWith(".designer.cs", StringComparison.OrdinalIgnoreCase);
    }
    private static Dictionary<string,string> Files(string root, Func<string,bool>? predicate = null) => Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories).Where(p => Included(root,p) && (predicate?.Invoke(p) ?? true)).ToDictionary(p => Path.GetRelativePath(root,p).Replace('\\','/'), p => p, StringComparer.Ordinal);
    private static bool IsSourceScope(string relative) => relative.StartsWith("src/", StringComparison.OrdinalIgnoreCase) || relative.StartsWith("tests/", StringComparison.OrdinalIgnoreCase);
    private static bool IsTestScope(string path) => path.StartsWith("tests/",StringComparison.OrdinalIgnoreCase)||path.StartsWith("src/Tests/",StringComparison.OrdinalIgnoreCase);
    private static List<Source> Sources(string root, bool productionOnly=false) => Files(root,p => p.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)).Where(kv => IsSourceScope(kv.Key)&&(!productionOnly||!IsTestScope(kv.Key))).OrderBy(kv => kv.Key,StringComparer.Ordinal).Select(kv => new Source(kv.Key, File.ReadAllText(kv.Value))).ToList();
    private static string Digest(string value) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value))).ToLowerInvariant()[..16];
    private static Finding Issue(string kind,string path,int line,string message,object? data=null,string severity="policy_review") => new() { id=kind+":"+Digest(path+"|"+line+"|"+message), type=kind,path=path,line=line,severity=severity,message=message,evidence=data };
    private static Report ParseCheck(IEnumerable<Source> sources)
    {
        var report = new Report();
        var errors = sources.SelectMany(s=>s.Tree.GetDiagnostics().Where(d=>d.Severity==DiagnosticSeverity.Error).Select(d=>new { path=s.Path, line=d.Location.GetLineSpan().StartLinePosition.Line+1, diagnostic=d.Id, message=d.GetMessage() })).ToArray();
        report.metrics["syntax_error_count"] = errors.Length;
        if (errors.Length > 0) { report.status="not_evaluable"; report.verdict="not_evaluable"; report.metrics["syntax_errors"]=errors; }
        return report;
    }

    private sealed class Source
    {
        public string Path {get;}
        public string Text {get;}
        public string[] Lines {get;}
        public SyntaxTree Tree {get;}
        public SyntaxNode Root {get;}
        public Source(string path,string text) {Path=path;Text=text;Lines=text.Replace("\r\n","\n").Split('\n');Tree=CSharpSyntaxTree.ParseText(text,new CSharpParseOptions(LanguageVersion.CSharp12),path);Root=Tree.GetRoot();}
    }
    private sealed class MethodMetric { public string Key {get;set;}=""; public string Name {get;set;}=""; public string Path {get;set;}=""; public string Text {get;set;}=""; public int CC {get;set;} public int Line {get;set;} }
    private sealed class ClassMetric { public string Path {get;set;}=""; public string Name {get;set;}=""; public int Line {get;set;} public List<MethodMetric> Methods {get;set;}=new(); public int CC => Methods.Sum(m=>m.CC); }

    private static string TokenSignature(IEnumerable<SyntaxToken> tokens) => string.Join("|",tokens.Select(t=>t.RawKind+":"+t.Text.Length+":"+t.Text));
    private static Dictionary<string,ClassMetric> ClassMetrics(IEnumerable<Source> sources,string root)
    {
        var result = new Dictionary<string,ClassMetric>(StringComparer.Ordinal);
        var projects=Projects(root);
        foreach (var source in sources)
        {
        var owner=projects.Where(p=>source.Path.StartsWith(Path.GetDirectoryName(p.Relative)!.Replace('\\','/')+"/",StringComparison.Ordinal)).OrderByDescending(p=>p.Relative.Length).FirstOrDefault();
        foreach (var type in source.Root.DescendantNodes().OfType<TypeDeclarationSyntax>())
        {
            string name=string.Join(".",type.Ancestors().OfType<BaseNamespaceDeclarationSyntax>().Reverse().Select(n=>n.Name.ToString()).Concat(type.AncestorsAndSelf().OfType<TypeDeclarationSyntax>().Reverse().Select(t=>t.Identifier.ValueText+(t.TypeParameterList?.ToString()??""))));
            string typeKey=(owner?.Relative??"<root>")+"|"+name;
            if(!result.TryGetValue(typeKey,out var metric)){metric=new ClassMetric {Path=source.Path,Name=name,Line=type.GetLocation().GetLineSpan().StartLinePosition.Line+1};result[typeKey]=metric;}
            foreach(var node in type.DescendantNodes().Where(IsCallable))
            {
                if(node.Ancestors().OfType<TypeDeclarationSyntax>().FirstOrDefault()!=type || !HasBody(node)) continue;
                string methodName=CallableName(node);
                string context=string.Join("/",node.Ancestors().TakeWhile(n=>n!=type).Where(IsCallable).Reverse().Select(CallableName));
                string key=source.Path+"|"+context+"/"+methodName;
                // Multiple lambdas with equal signatures are disambiguated by ordinal within this type.
                int ordinal=metric.Methods.Count(m=>m.Key==key || m.Key.StartsWith(key+"#",StringComparison.Ordinal));
                if(ordinal>0) key+="#"+ordinal;
                metric.Methods.Add(new MethodMetric {Key=key,Name=methodName,Path=source.Path,Text=TokenSignature(node.DescendantTokens()),CC=1+node.DescendantNodes(n=>n==node || !IsCallable(n)).Count(IsDecision),Line=node.GetLocation().GetLineSpan().StartLinePosition.Line+1});
            }
        }
        var globals=source.Root.ChildNodes().OfType<GlobalStatementSyntax>().ToList();
        if(globals.Count>0)
        {
            string name="<top-level:"+source.Path+">";var metric=new ClassMetric{Path=source.Path,Name=name,Line=globals[0].GetLocation().GetLineSpan().StartLinePosition.Line+1};
            metric.Methods.Add(new MethodMetric{Key="<top-level>",Name="<top-level>",Path=source.Path,Line=metric.Line,Text=TokenSignature(globals.SelectMany(g=>g.DescendantTokens())),CC=1+globals.SelectMany(g=>g.DescendantNodes(n=>!IsCallable(n))).Count(IsDecision)});
            foreach(var node in globals.SelectMany(g=>g.DescendantNodes()).Where(IsCallable).Where(HasBody))
            {string callableName=CallableName(node);metric.Methods.Add(new MethodMetric{Key=callableName+"#"+metric.Methods.Count,Name=callableName,Path=source.Path,Line=node.GetLocation().GetLineSpan().StartLinePosition.Line+1,Text=TokenSignature(node.DescendantTokens()),CC=1+node.DescendantNodes(n=>n==node||!IsCallable(n)).Count(IsDecision)});}
            result[(owner?.Relative??"<root>")+"|"+name]=metric;
        }
        }
        return result;
    }
    private static bool IsCallable(SyntaxNode n) => n is BaseMethodDeclarationSyntax or AccessorDeclarationSyntax or LocalFunctionStatementSyntax or AnonymousFunctionExpressionSyntax || n is PropertyDeclarationSyntax p && p.ExpressionBody!=null || n is IndexerDeclarationSyntax i && i.ExpressionBody!=null;
    private static bool HasBody(SyntaxNode n) => n switch { BaseMethodDeclarationSyntax b => b.Body!=null||b.ExpressionBody!=null,AccessorDeclarationSyntax a=>a.Body!=null||a.ExpressionBody!=null,LocalFunctionStatementSyntax l=>l.Body!=null||l.ExpressionBody!=null,_=>true };
    private static string CallableName(SyntaxNode n) => n switch
    {
        MethodDeclarationSyntax m=>m.Identifier.ValueText+(m.TypeParameterList?.ToString()??"")+m.ParameterList.ToString(),
        ConstructorDeclarationSyntax c=>".ctor"+c.ParameterList.ToString(),DestructorDeclarationSyntax d=>".dtor"+d.ParameterList.ToString(),
        OperatorDeclarationSyntax o=>"operator"+o.OperatorToken.Text+o.ParameterList.ToString(),ConversionOperatorDeclarationSyntax c=>"operator"+c.Type.ToString()+c.ParameterList.ToString(),
        AccessorDeclarationSyntax a=>(a.Parent?.Parent is PropertyDeclarationSyntax p?p.Identifier.ValueText:"indexer")+"."+a.Keyword.Text,
        LocalFunctionStatementSyntax l=>"local:"+l.Identifier.ValueText+l.ParameterList.ToString(),
        PropertyDeclarationSyntax p=>p.Identifier.ValueText+".expression",IndexerDeclarationSyntax i=>"this"+i.ParameterList.ToString(),
        LambdaExpressionSyntax=>"lambda",AnonymousMethodExpressionSyntax=>"anonymous",_=>n.Kind().ToString()
    };
    private static bool IsDecision(SyntaxNode n) => n is IfStatementSyntax or ForStatementSyntax or ForEachStatementSyntax or ForEachVariableStatementSyntax or WhileStatementSyntax or DoStatementSyntax or CatchClauseSyntax or CaseSwitchLabelSyntax or CasePatternSwitchLabelSyntax or ConditionalExpressionSyntax or WhenClauseSyntax || n is BinaryExpressionSyntax b && (b.IsKind(SyntaxKind.LogicalAndExpression)||b.IsKind(SyntaxKind.LogicalOrExpression)||b.IsKind(SyntaxKind.CoalesceExpression)) || n is SwitchExpressionArmSyntax arm && arm.Pattern is not DiscardPatternSyntax;

    private static Report Complexity(string baseline,string head)
    {
        var oldSources=Sources(baseline,true);var newSources=Sources(head,true);var report=ParseCheck(oldSources.Concat(newSources));
        if(report.status!="ok") return report;
        var previous=ClassMetrics(oldSources,baseline);var current=ClassMetrics(newSources,head);
        var details=new List<object>();int changedClasses=0,newClasses=0;
        foreach(var pair in current.OrderBy(kv=>kv.Key,StringComparer.Ordinal))
        {
            var item=pair.Value;previous.TryGetValue(pair.Key,out var old);
            var oldMethods=old?.Methods.ToDictionary(m=>m.Key,StringComparer.Ordinal)??new Dictionary<string,MethodMetric>();
            var changed=item.Methods.Where(m=>!oldMethods.TryGetValue(m.Key,out var prior)||m.Text!=prior.Text).ToList();
            bool changedClass=old==null||changed.Count>0||old.Methods.Count!=item.Methods.Count;
            if(!changedClass) continue;
            changedClasses++;if(old==null)newClasses++;
            double? delta=old?.CC>0?(double)(item.CC-old.CC)/old.CC:null;
            details.Add(new{path=item.Path,type=item.Name,baseline_cc=old?.CC??0,head_cc=item.CC,relative_delta=delta,changed_callable_count=changed.Count,new_class=old==null});
            if(delta>0.10+1e-12) report.findings.Add(Issue("complexity_class_delta",item.Path,item.Line,$"Changed type {item.Name} exceeds +10% summed callable complexity",new{baseline_cc=old!.CC,head_cc=item.CC,relative_delta=delta,limit=0.10}));
            foreach(var method in changed.Where(m=>m.CC>15)) report.findings.Add(Issue("complexity_method_ceiling",method.Path,method.Line,$"Changed callable {method.Name} exceeds cyclomatic complexity 15",new{method_cc=method.CC,limit=15,type=item.Name}));
        }
        report.metrics["scope"]="Production C# under src/, excluding src/Tests and tests/, bin/obj and generated-name files";
        report.metrics["baseline_class_cc_sum"]=previous.Values.Sum(c=>c.CC);report.metrics["head_class_cc_sum"]=current.Values.Sum(c=>c.CC);
        report.metrics["baseline_max_callable_cc"]=previous.Values.SelectMany(c=>c.Methods).Select(m=>m.CC).DefaultIfEmpty(0).Max();
        report.metrics["head_max_callable_cc"]=current.Values.SelectMany(c=>c.Methods).Select(m=>m.CC).DefaultIfEmpty(0).Max();
        report.metrics["changed_classes"]=changedClasses;report.metrics["new_classes"]=newClasses;report.metrics["class_details"]=details;
        report.metrics["definition"]="CC=1 plus if, for/foreach/while/do, catch, non-default switch labels/arms, conditional expression, when guard, &&, ||, ??. Each callable is separate, nested callables excluded from its parent. Class CC sums body-bearing callable CC, including lambdas/local functions/accessors. Partial declarations aggregate by project and qualified type. Top-level statements form one synthetic callable per file with local functions measured separately. Relative gate applies only to changed existing types with baseline CC>0, absolute ceiling only to changed/new callables. No relative threshold at zero baseline.";
        return report;
    }

    private sealed class TokenFile { public Source Source {get;set;}=null!; public SyntaxToken[] Tokens {get;set;}=Array.Empty<SyntaxToken>(); public string[] Keys {get;set;}=Array.Empty<string>(); public HashSet<int> DuplicateLines {get;set;}=new(); }
    private sealed class CloneStats { public int SourceLines {get;set;} public int DuplicatedLines {get;set;} public int SeedGroups {get;set;} public double Density=>SourceLines==0?0:100.0*DuplicatedLines/SourceLines; public List<TokenFile> Files {get;set;}=new(); }
    private readonly record struct Occurrence(int File,int Start);
    private static ulong TokenHash(string value) { unchecked { ulong h=14695981039346656037UL;foreach(char c in value){h^=c;h*=1099511628211UL;}return h; } }
    private static CloneStats CloneMeasure(List<Source> sources)
    {
        const int length=50;const ulong prime=1000003;
        var stats=new CloneStats();
        foreach(var source in sources){var tokens=source.Root.DescendantTokens().Where(t=>!t.IsKind(SyntaxKind.EndOfFileToken)&&!t.IsMissing).ToArray();stats.Files.Add(new TokenFile{Source=source,Tokens=tokens,Keys=tokens.Select(t=>t.RawKind+":"+t.Text).ToArray()});stats.SourceLines+=source.Lines.Count(l=>!string.IsNullOrWhiteSpace(l));}
        var windows=new Dictionary<ulong,List<Occurrence>>();
        unchecked
        {
            ulong power=1;for(int i=1;i<length;i++)power*=prime;
            for(int f=0;f<stats.Files.Count;f++)
            {
                var keys=stats.Files[f].Keys;if(keys.Length<length)continue;var hashes=keys.Select(TokenHash).ToArray();ulong hash=0;
                for(int k=0;k<length;k++)hash=hash*prime+hashes[k];
                for(int start=0;start<=keys.Length-length;start++)
                {
                    if(start>0)hash=(hash-hashes[start-1]*power)*prime+hashes[start+length-1];
                    if(!windows.TryGetValue(hash,out var bucket)){bucket=new List<Occurrence>();windows[hash]=bucket;}bucket.Add(new Occurrence(f,start));
                }
            }
        }
        foreach(var bucket in windows.Values.Where(b=>b.Count>1))
        {
            // Verify exact token identity, so the rolling-hash collision probability cannot affect results.
            var groups=new List<List<Occurrence>>();
            foreach(var occurrence in bucket)
            {
                var group=groups.FirstOrDefault(g=>SameWindow(stats.Files[g[0].File].Keys,g[0].Start,stats.Files[occurrence.File].Keys,occurrence.Start,length));
                if(group==null){group=new List<Occurrence>();groups.Add(group);}group.Add(occurrence);
            }
            foreach(var group in groups)
            {
                var selected=new List<Occurrence>();var lastEnd=new Dictionary<int,int>();
                foreach(var item in group.OrderBy(o=>o.File).ThenBy(o=>o.Start)){if(lastEnd.TryGetValue(item.File,out int end)&&item.Start<end)continue;selected.Add(item);lastEnd[item.File]=item.Start+length;}
                if(selected.Count<2)continue;stats.SeedGroups++;
                foreach(var item in selected)
                {
                    var file=stats.Files[item.File];
                    for(int i=item.Start;i<item.Start+length;i++)
                    {
                        var span=file.Tokens[i].GetLocation().GetLineSpan();for(int line=span.StartLinePosition.Line;line<=span.EndLinePosition.Line;line++)if(line<file.Source.Lines.Length&&!string.IsNullOrWhiteSpace(file.Source.Lines[line]))file.DuplicateLines.Add(line+1);
                    }
                }
            }
        }
        stats.DuplicatedLines=stats.Files.Sum(f=>f.DuplicateLines.Count);return stats;
    }
    private static bool SameWindow(string[] left,int li,string[] right,int ri,int length){for(int i=0;i<length;i++)if(left[li+i]!=right[ri+i])return false;return true;}
    private static List<int[]> Ranges(IEnumerable<int> lines){var result=new List<int[]>();foreach(int line in lines.Order()){if(result.Count==0||line>result[^1][1]+1)result.Add(new[]{line,line});else result[^1][1]=line;}return result;}
    private static Report Duplication(string baseline,string head)
    {
        var oldSources=Sources(baseline,true);var newSources=Sources(head,true);var report=ParseCheck(oldSources.Concat(newSources));if(report.status!="ok")return report;
        var before=CloneMeasure(oldSources);var after=CloneMeasure(newSources);
        report.metrics["scope"]="Production C# under src/, excluding src/Tests and tests/, bin/obj and generated-name files";
        report.metrics["baseline_density_percent"]=before.Density;report.metrics["head_density_percent"]=after.Density;report.metrics["density_delta_percentage_points"]=after.Density-before.Density;
        report.metrics["baseline_duplicated_lines"]=before.DuplicatedLines;report.metrics["head_duplicated_lines"]=after.DuplicatedLines;report.metrics["baseline_source_nonblank_lines"]=before.SourceLines;report.metrics["head_source_nonblank_lines"]=after.SourceLines;
        report.metrics["head_duplicate_window_groups"]=after.SeedGroups;report.metrics["threshold_percent"]=3.0;report.metrics["minimum_exact_tokens"]=50;report.metrics["baseline_already_exceeds_threshold"]=before.Density>3;
        report.metrics["definition"]="Exact contiguous C# token sequences of at least 50 tokens. Raw kind and token text must match. Trivia ignored, identifiers/literals not normalized. Occurrences within a seed group are selected in path/token order and must not overlap in the same file. Union of nonblank physical lines occupied by duplicate tokens divided by all nonblank production C# source lines in the declared scope. Whole-snapshot 3% budget is reported even if baseline already exceeds it. This custom measure is not SonarQube duplication density.";
        if(after.Density>3) foreach(var file in after.Files.Where(f=>f.DuplicateLines.Count>0))report.findings.Add(Issue("exact_token_duplication",file.Source.Path,file.DuplicateLines.Min(),"Duplicated token spans contribute to a whole-snapshot density above 3%",new{duplicated_lines=file.DuplicateLines.Count,line_ranges=Ranges(file.DuplicateLines),snapshot_density_percent=after.Density,limit_percent=3,preexisting_budget_exceedance=before.Density>3}));
        return report;
    }

    private sealed class ProjectInfo { public string Relative {get;set;}="";public string Full {get;set;}="";public string Name {get;set;}="";public string Namespace {get;set;}="";public string Layer {get;set;}="";public XDocument Xml {get;set;}=null!; }
    private static List<ProjectInfo> Projects(string root)=>Files(root,p=>p.EndsWith(".csproj",StringComparison.OrdinalIgnoreCase)).Select(kv=>{var xml=XDocument.Load(kv.Value,LoadOptions.SetLineInfo);string name=Path.GetFileNameWithoutExtension(kv.Value);return new ProjectInfo{Relative=kv.Key,Full=kv.Value,Name=name,Namespace=xml.Descendants().FirstOrDefault(e=>e.Name.LocalName=="RootNamespace")?.Value??name,Layer=IdentifyLayer(kv.Key),Xml=xml};}).ToList();
    private static string IdentifyLayer(string path){foreach(string layer in new[]{"Domain","Application","Infrastructure","Api","Tests"})if(path.Split('/','\\').Any(p=>p.Equals(layer,StringComparison.OrdinalIgnoreCase)))return layer;return "Other";}
    private static bool Forbidden(string from,string to)=>from=="Domain"&&to is "Application" or "Infrastructure" or "Api" || from=="Application"&&to is "Infrastructure" or "Api";
    private static List<Finding> ArchitecturalFindings(string root,List<Source> sources)
    {
        var projects=Projects(root);var findings=new List<Finding>();
        foreach(var project in projects)
        {
            foreach(var reference in project.Xml.Descendants().Where(e=>e.Name.LocalName=="ProjectReference"))
            {
                string? include=reference.Attribute("Include")?.Value;if(include==null)continue;string full=Path.GetFullPath(Path.Combine(Path.GetDirectoryName(project.Full)!,include.Replace('\\',Path.DirectorySeparatorChar)));
                var target=projects.FirstOrDefault(p=>p.Full==full);string layer=target?.Layer??IdentifyLayer(include);
                if(Forbidden(project.Layer,layer))findings.Add(Issue("forbidden_project_reference",project.Relative,((System.Xml.IXmlLineInfo)reference).LineNumber,$"{project.Layer} must not reference {layer}",new{target=target?.Relative??include,from_layer=project.Layer,to_layer=layer}));
            }
        }
        foreach(var source in sources)
        {
            var owner=projects.Where(p=>source.Path.StartsWith(Path.GetDirectoryName(p.Relative)!.Replace('\\','/')+"/",StringComparison.Ordinal)).OrderByDescending(p=>p.Relative.Length).FirstOrDefault();if(owner==null)continue;
            var seen=new HashSet<string>();
            foreach(var node in source.Root.DescendantNodes().Where(n=>n is UsingDirectiveSyntax || n is QualifiedNameSyntax && n.Parent is not QualifiedNameSyntax && !n.Ancestors().Any(a=>a is BaseNamespaceDeclarationSyntax ns && ns.Name.Span.Contains(n.Span)) && !n.Ancestors().Any(a=>a is UsingDirectiveSyntax)))
            {
                string name=(node is UsingDirectiveSyntax u?u.Name?.ToString()??"":node.ToString()).Replace("global::","");
                foreach(var target in projects.Where(p=>Forbidden(owner.Layer,p.Layer)))
                {
                    if(name!=target.Namespace&&!name.StartsWith(target.Namespace+".",StringComparison.Ordinal))continue;int line=node.GetLocation().GetLineSpan().StartLinePosition.Line+1;
                    if(seen.Add(target.Layer+":"+line))findings.Add(Issue("forbidden_namespace_reference",source.Path,line,$"{owner.Layer} source names forbidden namespace {target.Namespace}",new{namespace_text=name,from_layer=owner.Layer,to_layer=target.Layer,scope="syntax-level namespace reference, not full semantic compilation"}));
                }
            }
        }
        return findings;
    }
    private static Report Architecture(string baseline,string head)
    {
        var oldSources=Sources(baseline);var newSources=Sources(head);var report=ParseCheck(oldSources.Concat(newSources));if(report.status!="ok")return report;
        var previous=ArchitecturalFindings(baseline,oldSources);report.findings=ArchitecturalFindings(head,newSources);
        report.metrics["baseline_violation_count"]=previous.Count;report.metrics["head_violation_count"]=report.findings.Count;report.metrics["project_count"]=Projects(head).Count;
        report.metrics["rules"]=new[]{"Domain -> Application/Infrastructure/Api forbidden","Application -> Infrastructure/Api forbidden"};
        report.metrics["definition"]="Parse ProjectReference XML and C# namespace-use syntax for named layers. Checks project dependency edges and explicit namespace references only. Does not prove architectural behavior, resolve runtime/reflection dependencies, evaluate all MSBuild conditions, or substitute for compilation and executable invariant tests. All project-reference items including conditioned entries are conservatively inspected.";
        return report;
    }
    private static Dictionary<string,string> Packages(string path)
    {
        var result=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);var xml=XDocument.Load(path);
        foreach(var e in xml.Descendants().Where(e=>e.Name.LocalName=="PackageReference"||e.Name.LocalName=="PackageVersion"))
        {string id=e.Attribute("Include")?.Value??e.Attribute("Update")?.Value??"<missing>";string key=id+"|condition="+(e.Attribute("Condition")?.Value??"");result[key]=e.ToString(SaveOptions.DisableFormatting);}
        return result;
    }
    private static Report Dependencies(string baseline,string head)
    {
        var old=Files(baseline);var current=Files(head);var report=new Report();int manifests=0;
        foreach(string path in old.Keys.Union(current.Keys,StringComparer.Ordinal).Order())
        {
            bool hasOld=old.TryGetValue(path,out var oldPath),hasNew=current.TryGetValue(path,out var newPath);string oldText=hasOld?File.ReadAllText(oldPath!):"",newText=hasNew?File.ReadAllText(newPath!):"";if(oldText==newText)continue;
            string name=Path.GetFileName(path);bool project=path.EndsWith(".csproj",StringComparison.OrdinalIgnoreCase)||name.Equals("Directory.Packages.props",StringComparison.OrdinalIgnoreCase);
            if(project)
            {
                manifests++;var oldPackages=hasOld?Packages(oldPath!):new Dictionary<string,string>();var newPackages=hasNew?Packages(newPath!):new Dictionary<string,string>();
                foreach(var id in oldPackages.Keys.Union(newPackages.Keys,StringComparer.OrdinalIgnoreCase))
                {
                    oldPackages.TryGetValue(id,out string? prior);newPackages.TryGetValue(id,out string? now);if(prior==now)continue;
                    report.findings.Add(Issue("package_reference_change",path,1,$"Package policy review required: {id}",new{package=id,change=prior==null?"added":now==null?"removed":"changed",baseline=prior,head=now},"review_required"));
                }
                // Build and restore instructions are executable supply-chain configuration even without package changes.
                if(!report.findings.Any(f=>f.path==path))report.findings.Add(Issue("project_manifest_change",path,1,"Project/build manifest changed and requires policy review",new{baseline_present=hasOld,head_present=hasNew},"review_required"));
            }
            else if(name.Equals("global.json",StringComparison.OrdinalIgnoreCase)||name.Equals("packages.lock.json",StringComparison.OrdinalIgnoreCase)||name.Equals("packages.config",StringComparison.OrdinalIgnoreCase)||name.Equals("NuGet.Config",StringComparison.OrdinalIgnoreCase)||name.StartsWith("Directory.Build.",StringComparison.OrdinalIgnoreCase)||path.StartsWith(".github/workflows/",StringComparison.OrdinalIgnoreCase))
            {manifests++;report.findings.Add(Issue("supply_chain_configuration_change",path,1,"SDK, restore, lockfile or build/CI configuration changed and requires policy review",new{baseline_present=hasOld,head_present=hasNew,baseline_sha256=hasOld?Digest(oldText):null,head_sha256=hasNew?Digest(newText):null},"review_required"));}
        }
        report.metrics["changed_manifests"]=manifests;report.metrics["definition"]="Manifest/lockfile/configuration change detector only. PackageReference and PackageVersion additions/removals/metadata changes require review. No vulnerability feed, dependency resolution, license analysis or exploitability conclusion is supplied by this gate.";return report;
    }
    private static (int Add,int Delete) DiffLines(string? oldPath,string? newPath)
    {
        if(oldPath==null)return(File.ReadLines(newPath!).Count(),0);if(newPath==null)return(0,File.ReadLines(oldPath).Count());
        var start=new ProcessStartInfo("git"){RedirectStandardOutput=true,RedirectStandardError=true,UseShellExecute=false};foreach(string value in new[]{"diff","--no-index","--numstat","--",oldPath,newPath})start.ArgumentList.Add(value);
        using var process=Process.Start(start)??throw new InvalidOperationException("Could not run git diff");string stdout=process.StandardOutput.ReadToEnd(),stderr=process.StandardError.ReadToEnd();process.WaitForExit();if(process.ExitCode>1)throw new InvalidOperationException("git diff failed: "+stderr);
        int add=0,delete=0;foreach(var row in stdout.Split('\n',StringSplitOptions.RemoveEmptyEntries)){string[] columns=row.Split('\t');if(columns.Length<3||!int.TryParse(columns[0],out int a)||!int.TryParse(columns[1],out int d))throw new InvalidOperationException("Binary/unparseable scoped change cannot use LOC cap");add+=a;delete+=d;}return(add,delete);
    }
    private static Report Size(string baseline,string head)
    {
        var old=Files(baseline).Where(kv=>IsSourceScope(kv.Key)).ToDictionary(kv=>kv.Key,kv=>kv.Value);var current=Files(head).Where(kv=>IsSourceScope(kv.Key)).ToDictionary(kv=>kv.Key,kv=>kv.Value);var report=new Report();var changes=new List<object>();int totalAdd=0,totalDelete=0;
        foreach(string path in old.Keys.Union(current.Keys,StringComparer.Ordinal).Order())
        {
            old.TryGetValue(path,out string? oldPath);current.TryGetValue(path,out string? newPath);if(oldPath!=null&&newPath!=null&&File.ReadAllBytes(oldPath).SequenceEqual(File.ReadAllBytes(newPath)))continue;
            var (add,delete)=DiffLines(oldPath,newPath);totalAdd+=add;totalDelete+=delete;changes.Add(new{path,added_lines=add,deleted_lines=delete});
        }
        if(totalAdd+totalDelete>150)report.findings.Add(Issue("changed_line_cap","",0,"Source/test change exceeds 150 added plus deleted physical lines",new{added_lines=totalAdd,deleted_lines=totalDelete,changed_lines=totalAdd+totalDelete,limit=150}));
        if(changes.Count>4)report.findings.Add(Issue("changed_file_cap","",0,"Source/test change exceeds four files",new{changed_files=changes.Count,limit=4}));
        report.metrics["added_lines"]=totalAdd;report.metrics["deleted_lines"]=totalDelete;report.metrics["changed_lines"]=totalAdd+totalDelete;report.metrics["changed_files"]=changes.Count;report.metrics["files"]=changes;
        report.metrics["definition"]="git diff --no-index --numstat on differing files under src/ or tests/, added/deleted files counted by physical lines. Added+deleted lines, not net growth. File renames count as removal+addition. Generated-name and bin/obj exclusions match other gates. Root SDK and lockfile changes are assessed by dependencies gate, not this scoped diff cap.";return report;
    }
    private sealed class Report
    {
        public string status {get;set;}="ok";public string verdict {get;set;}="pass";public string gate {get;set;}="";public string tool_version {get;set;}="";
        public int finding_count {get;set;}public List<string> finding_ids {get;set;}=new();public List<Finding> findings {get;set;}=new();public Dictionary<string,object?> metrics {get;set;}=new();
    }
    private sealed class Finding
    {
        public string id {get;set;}="";public string type {get;set;}="";public string severity {get;set;}="";public string path {get;set;}="";public int line {get;set;}public string message {get;set;}="";public object? evidence {get;set;}
    }
}
