# CAI research gate tool, version 1.0.0

This package-free .NET 8 console program provides five report-only checks for the
bounded feasibility experiment. It uses the C# parser distributed with the pinned
.NET SDK. It is a research implementation, not a validated security product and
not SonarQube. SDK security analyzers supply a separate sixth gate outside this
program.

## Build and invocation

```
dotnet build GateTool.csproj -c Release --configfile NuGet.Config
dotnet bin/Release/net8.0/GateTool.dll --version
dotnet bin/Release/net8.0/GateTool.dll --gate complexity --base /canonical/parent --head /candidate/tree --output /results/complexity.json
```

Gate IDs are `complexity`, `duplication`, `architecture`, `dependencies` and `size`.
Both input trees must exist. Parent comparison uses the same parent for `--base`
and `--head`. Exit 0 means analysis completed, including policy findings. Exit 2
means analysis failed or could not be evaluated. JSON `status` and `verdict` are
authoritative. The program makes no merge decision and does not modify either
input tree.

## Operational definitions

- Complexity covers production C# under `src`, excluding `src/Tests`, `tests`,
  `bin`, `obj` and generated-name files. Callable complexity is one plus each
  `if`, loop, `catch`, non-default switch label or switch-expression arm,
  conditional expression, `when` guard, `&&`, `||` and `??`. This is a stated
  syntactic operationalization, not an equivalence claim about other analyzers.
  Nested callables are measured independently. Body-bearing methods,
  constructors, destructors, operators, accessors, expression properties, local
  functions and lambdas contribute. Top-level code is a synthetic callable.
  Partial declarations are aggregated by project and qualified type name.
  Changed existing classes with nonzero baseline summed callable complexity are
  flagged above a 10% increase. Changed/new callables are flagged above 15.
  No relative delta is evaluated against a zero baseline. Removal-only changes
  cannot increase the budget. Token identity determines callable edits, so
  whitespace/comment-only edits do not newly trigger the ceiling.
- Duplication uses the same production scope. An exact contiguous token sequence
  must contain at least 50 tokens. Raw C# kind and token text must match.
  Identifiers and literals are not normalized. Rolling hashes locate candidates,
  and exact comparisons verify them. Within each matching seed group, occurrences
  are selected deterministically in file/token order without overlap in one file.
  The numerator is the union of nonblank physical lines occupied by repeated
  tokens. The denominator is all nonblank production C# lines in scope.
  A whole-snapshot density above 3% is reported even when the parent already
  exceeds that threshold. Parent density and this preexisting condition are
  explicit. Token windows are not independent defects. Findings aggregate
  duplicate lines by file, and are not clone-family prevalence estimates.
- Architecture parses `ProjectReference` XML and explicit namespace-reference
  syntax. Domain may not reference Application, Infrastructure or Api.
  Application may not reference Infrastructure or Api. Project edges include
  conditioned items conservatively without evaluating all MSBuild configurations.
  Namespace checks use the projects' root namespaces or assembly names.
  These checks do not establish semantic architectural correctness, runtime
  dependency freedom or reflection behavior. Compilation and executable tests
  remain separate evidence.
- Dependencies flags package-reference additions/removals/metadata changes and
  project, SDK, restore, lockfile or build/CI configuration changes. It does not
  download vulnerability feeds, infer exploitability or perform license auditing.
  Every finding is a request for policy review, not a confirmed vulnerability.
- Size uses `git diff --no-index --numstat` for modified files and physical-line
  counts for added/deleted files under `src` or `tests`. It includes test files
  and project files, excludes `bin`, `obj` and generated-name files, and flags more
  than 150 added-plus-deleted lines or more than four files. Renames count as an
  add/remove pair. Root configuration changes are covered by Dependencies.

Generated-name exclusions are `.g.cs`, `.generated.cs` and `.designer.cs`.
An attacker-controlled filename can evade this scope, so enforcing generation
provenance would be a separate production requirement. Syntactic parse errors
yield `not_evaluable` in the structural/architecture checks. Preprocessor symbols
use the default C#12 parser configuration, so inactive branches are not measured.
These scope limits must be reported rather than represented as complete coverage.

## Verification

`python test_gate_tool.py` checks unchanged baselines, positive policy fixtures,
nested and top-level decisions, partial types, exact clones, layer violations,
package-review triggers, scope exclusions, size arithmetic and parse failures.
The fixtures verify implementation behavior only. They do not establish accuracy
on human-adjudicated defects, production throughput or external validity.

Freeze the source and binary hashes before the measured runs. The experiment
orchestrator records tool/configuration, parent/head and result hashes and raw
timings. Metrics in output describe the policy implementation above. They must
not be relabeled as SonarQube values or as adjudicated defect counts.
